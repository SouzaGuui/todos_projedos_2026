<?php
session_start();

// Se não está logado, mostrar tela de login
$isLoggedIn = isset($_SESSION['admin_id']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Admin - Interclasse 2026</title>
    <link rel="icon" type="image/png" href="../assets/img/sesi-logo.png">
    <link rel="stylesheet" href="assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Bebas+Neue&display=swap" rel="stylesheet">
</head>
<body class="<?php echo $isLoggedIn ? 'admin-body' : 'login-body'; ?>">

<?php if (!$isLoggedIn): ?>
<!-- ==================== TELA DE LOGIN ==================== -->
<div class="login-container">
    <div class="login-card">
        <div class="login-header">
            <div class="login-icon">
                <img src="../assets/img/sesi-logo.png" alt="SESI" style="width: 60px; height: 60px; object-fit: contain;">
            </div>
            <h1>INTERCLASSE <span>2026</span></h1>
            <p>Painel Administrativo</p>
        </div>
        <form id="loginForm" class="login-form">
            <div class="login-field">
                <label><i class="fas fa-user"></i> Usuário</label>
                <input type="text" id="loginUsuario" placeholder="Digite seu usuário" required>
            </div>
            <div class="login-field">
                <label><i class="fas fa-lock"></i> Senha</label>
                <input type="password" id="loginSenha" placeholder="Digite sua senha" required>
            </div>
            <div class="login-error" id="loginError" style="display: none;">
                <i class="fas fa-exclamation-triangle"></i>
                <span id="loginErrorMsg"></span>
            </div>
            <button type="submit" class="login-btn" id="loginBtn">
                <i class="fas fa-sign-in-alt"></i> Entrar
            </button>
        </form>
        <div class="login-footer">
            <a href="../index.php"><i class="fas fa-arrow-left"></i> Voltar ao site</a>
        </div>
    </div>
</div>

<?php else: ?>
<!-- ==================== PAINEL ADMINISTRATIVO ==================== -->

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
            <div class="sidebar-brand">
                <img src="../assets/img/sesi-logo.png" alt="SESI" class="sidebar-logo">
                <span>INTERCLASSE <strong>2026</strong></span>
        </div>
        <button class="sidebar-close" id="sidebarClose">
            <i class="fas fa-times"></i>
        </button>
    </div>

    <nav class="sidebar-nav">
        <a href="#" class="nav-item active" data-page="dashboard">
            <i class="fas fa-chart-pie"></i>
            <span>Dashboard</span>
        </a>
        <a href="#" class="nav-item" data-page="alunos">
            <i class="fas fa-users"></i>
            <span>Alunos Cadastrados</span>
        </a>
        <a href="#" class="nav-item" data-page="modalidades">
            <i class="fas fa-futbol"></i>
            <span>Modalidades</span>
        </a>
        <a href="#" class="nav-item" data-page="tabela">
            <i class="fas fa-table-columns"></i>
            <span>Tabela dos Jogos</span>
        </a>
        <a href="#" class="nav-item" data-page="escalacao">
            <i class="fas fa-clipboard-list"></i>
            <span>Escalação</span>
        </a>
        <a href="#" class="nav-item" data-page="estatisticas">
            <i class="fas fa-chart-bar"></i>
            <span>Estatísticas</span>
        </a>
        <a href="#" class="nav-item" data-page="lixeira">
            <i class="fas fa-trash"></i>
            <span>Lixeira</span>
        </a>
        <a href="#" class="nav-item" data-page="perfil">
            <i class="fas fa-user-circle"></i>
            <span>Perfil</span>
        </a>
        <a href="#" class="nav-item" data-page="configuracoes">
            <i class="fas fa-cog"></i>
            <span>Configurações</span>
        </a>
    </nav>

    <div class="sidebar-footer">
        <a href="#" class="nav-item logout-item" id="btnLogout">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</aside>

<!-- Main Content -->
<main class="main-content" id="mainContent">
    <!-- Top Bar -->
    <header class="topbar">
        <div class="topbar-left">
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            <h2 class="page-title" id="pageTitle">Dashboard</h2>
        </div>
        <div class="topbar-right">
            <div class="topbar-user">
                <i class="fas fa-user-circle"></i>
                <span><?php echo htmlspecialchars($_SESSION['admin_nome'] ?? 'Admin'); ?></span>
            </div>
        </div>
    </header>

    <!-- Page Content -->
    <div class="page-content" id="pageContent">
        <!-- Dashboard será carregado via JS -->
    </div>
</main>

<!-- Modal para visualizar/editar aluno -->
<div class="modal-overlay" id="modalOverlay" style="display: none;">
    <div class="modal-content" id="modalContent">
        <!-- Conteúdo dinâmico -->
    </div>
</div>

<?php endif; ?>

<!-- Toast -->
<div class="toast-container" id="toastContainer"></div>

<!-- Scripts -->
<script src="assets/js/admin.js"></script>
</body>
</html>
