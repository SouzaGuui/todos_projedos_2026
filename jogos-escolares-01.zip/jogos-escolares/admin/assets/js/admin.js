/* =====================================================
   INTERCLASSE 2026 - Painel Administrativo JavaScript
   ===================================================== */

const API_BASE = '../backend';
let currentPage = 'dashboard';
let alunosData = [];
let currentPageNum = 1;
const perPage = 10;

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', function() {
    // Login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Admin Panel
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        initAdminPanel();
    }
});

// ==================== LOGIN ====================
async function handleLogin(e) {
    e.preventDefault();

    const usuario = document.getElementById('loginUsuario').value.trim();
    const senha = document.getElementById('loginSenha').value;
    const btn = document.getElementById('loginBtn');
    const errorDiv = document.getElementById('loginError');
    const errorMsg = document.getElementById('loginErrorMsg');

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
    errorDiv.style.display = 'none';

    try {
        const response = await fetch(`${API_BASE}/login.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ usuario, senha })
        });

        const result = await response.json();

        if (result.sucesso) {
            showToast('Login realizado com sucesso!', 'success');
            setTimeout(() => window.location.reload(), 500);
        } else {
            errorDiv.style.display = 'flex';
            errorMsg.textContent = result.erro || 'Usuário ou senha inválidos';
        }
    } catch (error) {
        errorDiv.style.display = 'flex';
        errorMsg.textContent = 'Erro de conexão com o servidor';
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Entrar';
    }
}

// ==================== ADMIN PANEL ====================
function initAdminPanel() {
    // Sidebar navigation
    document.querySelectorAll('.nav-item[data-page]').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.dataset.page;
            navigateTo(page);
        });
    });

    // Sidebar toggle (mobile)
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarClose = document.getElementById('sidebarClose');
    const sidebar = document.getElementById('sidebar');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => sidebar.classList.add('active'));
    }
    if (sidebarClose) {
        sidebarClose.addEventListener('click', () => sidebar.classList.remove('active'));
    }

    // Logout
    document.getElementById('btnLogout').addEventListener('click', function(e) {
        e.preventDefault();
        handleLogout();
    });

    // Modal close
    const modalOverlay = document.getElementById('modalOverlay');
    if (modalOverlay) {
        modalOverlay.addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });
    }

    // Load dashboard
    loadDashboard();
}

function navigateTo(page) {
    currentPage = page;
    document.getElementById('pageTitle').textContent = getPageTitle(page);

    // Update active nav item
    document.querySelectorAll('.nav-item[data-page]').forEach(item => {
        item.classList.toggle('active', item.dataset.page === page);
    });

    // Close mobile sidebar
    document.getElementById('sidebar').classList.remove('active');

    // Load page content
    switch (page) {
        case 'dashboard': loadDashboard(); break;
        case 'alunos': loadAlunos(); break;
        case 'modalidades': loadModalidades(); break;
        case 'tabela': loadTabela(); break;
        case 'escalacao': loadEscalacao(); break;
        case 'estatisticas': loadEstatisticas(); break;
        case 'lixeira': loadLixeira(); break;
        case 'perfil': loadPerfil(); break;
        case 'configuracoes': loadConfiguracoes(); break;
        default: loadDashboard();
    }
}

function getPageTitle(page) {
    const titles = {
        dashboard: 'Dashboard',
        alunos: 'Alunos Cadastrados',
        modalidades: 'Modalidades',
        tabela: 'Tabela dos Jogos',
        escalacao: 'Escalação - Titulares e Reservas',
        estatisticas: 'Estatísticas',
        lixeira: 'Lixeira',
        perfil: 'Perfil',
        configuracoes: 'Configurações'
    };
    return titles[page] || 'Dashboard';
}

// ==================== DASHBOARD ====================
async function loadDashboard() {
    const content = document.getElementById('pageContent');
    content.innerHTML = '<div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Carregando...</p></div>';

    try {
        const [dashRes, classRes] = await Promise.all([
            fetch(`${API_BASE}/dashboard.php`),
            fetch(`${API_BASE}/classificacao.php`)
        ]);
        const data = await dashRes.json();
        const classData = await classRes.json();

        const totalAlunos = data.total || 0;
        const modalidades = data.por_modalidade || [];
        const series = data.por_serie || [];
        const equipes = data.total_equipes || 0;
        const recentes = data.recentes || [];

        const stats = classData.estatisticas || {};
        const proximas = classData.proximas_partidas || [];
        const resultados = classData.resultados_recentes || [];

        content.innerHTML = `
            <!-- Painel do Campeonato - Stat Cards -->
            <div class="camp-stats-grid">
                <div class="camp-stat-card camp-stat-blue">
                    <div class="camp-stat-icon"><i class="fas fa-users"></i></div>
                    <div class="camp-stat-info">
                        <div class="camp-stat-value">${stats.total_inscritos || totalAlunos}</div>
                        <div class="camp-stat-label">Total Inscritos</div>
                    </div>
                </div>
                <div class="camp-stat-card camp-stat-green">
                    <div class="camp-stat-icon"><i class="fas fa-futbol"></i></div>
                    <div class="camp-stat-info">
                        <div class="camp-stat-value">${stats.modalidade_popular || '-'}</div>
                        <div class="camp-stat-label">Modalidade Popular</div>
                    </div>
                </div>
                <div class="camp-stat-card camp-stat-orange">
                    <div class="camp-stat-icon"><i class="fas fa-star"></i></div>
                    <div class="camp-stat-info">
                        <div class="camp-stat-value">${stats.turma_destaque || '-'}</div>
                        <div class="camp-stat-label">Turma Destaque</div>
                    </div>
                </div>
                <div class="camp-stat-card camp-stat-purple">
                    <div class="camp-stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="camp-stat-info">
                        <div class="camp-stat-value">${stats.jogos_encerrados || 0}</div>
                        <div class="camp-stat-label">Jogos Realizados</div>
                    </div>
                </div>
                <div class="camp-stat-card camp-stat-cyan">
                    <div class="camp-stat-icon"><i class="fas fa-calendar-alt"></i></div>
                    <div class="camp-stat-info">
                        <div class="camp-stat-value">${stats.jogos_agendados || 0}</div>
                        <div class="camp-stat-label">Próximos Jogos</div>
                    </div>
                </div>
                <div class="camp-stat-card camp-stat-red">
                    <div class="camp-stat-icon"><i class="fas fa-broadcast-tower"></i></div>
                    <div class="camp-stat-info">
                        <div class="camp-stat-value">${stats.jogos_ao_vivo || 0}</div>
                        <div class="camp-stat-label">Ao Vivo Agora</div>
                    </div>
                </div>
            </div>

            <!-- Próximas Partidas & Resultados Recentes -->
            <div class="camp-grid-two">
                <div class="dash-card">
                    <div class="dash-card-header">
                        <div class="dash-card-title"><i class="fas fa-calendar-alt"></i> Próximas Partidas</div>
                    </div>
                    <div class="camp-matches-list" id="campProximas"></div>
                </div>
                <div class="dash-card">
                    <div class="dash-card-header">
                        <div class="dash-card-title"><i class="fas fa-flag-checkered"></i> Resultados Recentes</div>
                    </div>
                    <div class="camp-matches-list" id="campResultados"></div>
                </div>
            </div>

            <!-- Charts and Lists -->
            <div class="dashboard-grid">
                <div class="dash-card">
                    <div class="dash-card-header">
                        <div class="dash-card-title"><i class="fas fa-chart-bar"></i> Alunos por Modalidade</div>
                    </div>
                    <div class="chart-container" id="chartModalidades"></div>
                </div>
                <div class="dash-card">
                    <div class="dash-card-header">
                        <div class="dash-card-title"><i class="fas fa-list"></i> Por Série</div>
                    </div>
                    <div class="stats-list" id="listSeries"></div>
                </div>
            </div>

            <!-- Recent Students -->
            <div class="dash-card">
                <div class="dash-card-header">
                    <div class="dash-card-title"><i class="fas fa-clock"></i> Últimos Alunos Cadastrados</div>
                </div>
                <div style="overflow-x: auto;">
                    <table class="recent-table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Série</th>
                                <th>Turma</th>
                                <th>Modalidade</th>
                                <th>Data</th>
                            </tr>
                        </thead>
                        <tbody id="recentTableBody"></tbody>
                    </table>
                </div>
            </div>
        `;

        // Render chart and lists
        renderChart(modalidades);
        renderSeriesList(series);
        renderRecentTable(recentes);
        renderCampProximas(proximas);
        renderCampResultados(resultados);

    } catch (error) {
        content.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro ao carregar</h3><p>Não foi possível conectar ao servidor</p></div>';
    }
}

function renderChart(modalidades) {
    const container = document.getElementById('chartModalidades');
    if (!container || !modalidades.length) {
        if (container) container.innerHTML = '<div class="empty-state"><p>Nenhum dado disponível</p></div>';
        return;
    }

    const maxValue = Math.max(...modalidades.map(m => m.total));
    const colors = ['var(--primary)', 'var(--blue)', 'var(--green)', 'var(--gold)', 'var(--purple)'];

    container.innerHTML = modalidades.map((m, i) => `
        <div class="chart-bar-group">
            <div class="chart-bar" style="height: ${maxValue > 0 ? (m.total / maxValue) * 200 : 10}px; background: ${colors[i % colors.length]};">
                <span class="chart-bar-value">${m.total}</span>
            </div>
            <span class="chart-bar-label">${m.modalidade.replace('Handebol ', 'Hand. ')}</span>
        </div>
    `).join('');
}

function renderSeriesList(series) {
    const container = document.getElementById('listSeries');
    if (!container) return;

    if (!series.length) {
        container.innerHTML = '<div class="empty-state"><p>Nenhum dado</p></div>';
        return;
    }

    container.innerHTML = series.map(s => `
        <div class="stats-list-item">
            <span class="stats-list-item-label">${s.serie}</span>
            <span class="stats-list-item-value">${s.total} alunos</span>
        </div>
    `).join('');
}

function renderRecentTable(recentes) {
    const tbody = document.getElementById('recentTableBody');
    if (!tbody) return;

    if (!recentes.length) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color: var(--gray);">Nenhum aluno cadastrado</td></tr>';
        return;
    }

    tbody.innerHTML = recentes.map(a => `
        <tr>
            <td>${a.nome}</td>
            <td><span class="badge badge-blue">${a.serie}</span></td>
            <td>${a.turma}</td>
            <td><span class="badge badge-red">${a.modalidade}</span></td>
            <td>${formatDate(a.data_cadastro)}</td>
        </tr>
    `).join('');
}

// ==================== CAMP DASHBOARD HELPERS ====================
function renderCampProximas(proximas) {
    const container = document.getElementById('campProximas');
    if (!container) return;

    if (!proximas || !proximas.length) {
        container.innerHTML = '<div class="camp-match-empty"><i class="fas fa-calendar-check"></i><br>Nenhuma partida agendada</div>';
        return;
    }

    container.innerHTML = proximas.map(p => {
        const dataFormatada = p.data_jogo ? formatDataShort(p.data_jogo) : '';
        const statusBadge = p.status === 'ao_vivo' ? '<span class="camp-badge-live">AO VIVO</span>' : '';
        return `
            <div class="camp-match-item">
                <div class="camp-match-teams">
                    <span class="camp-team">${p.equipe1}</span>
                    <span class="camp-vs">VS</span>
                    <span class="camp-team">${p.equipe2}</span>
                    ${statusBadge}
                </div>
                <div class="camp-match-meta">
                    <span><i class="fas fa-futbol"></i> ${p.modalidade}</span>
                    <span><i class="fas fa-clock"></i> ${dataFormatada} ${p.horario}</span>
                </div>
            </div>`;
    }).join('');
}

function renderCampResultados(resultados) {
    const container = document.getElementById('campResultados');
    if (!container) return;

    if (!resultados || !resultados.length) {
        container.innerHTML = '<div class="camp-match-empty"><i class="fas fa-flag-checkered"></i><br>Nenhum resultado ainda</div>';
        return;
    }

    container.innerHTML = resultados.map(r => {
        const dataFormatada = r.data_jogo ? formatDataShort(r.data_jogo) : '';
        const winner1 = r.vencedor === r.equipe1 ? ' camp-team-winner' : '';
        const winner2 = r.vencedor === r.equipe2 ? ' camp-team-winner' : '';
        return `
            <div class="camp-match-item camp-result-item">
                <div class="camp-match-teams">
                    <span class="camp-team${winner1}">${r.equipe1}</span>
                    <span class="camp-score">${r.placar1} - ${r.placar2}</span>
                    <span class="camp-team${winner2}">${r.equipe2}</span>
                </div>
                <div class="camp-match-meta">
                    <span><i class="fas fa-futbol"></i> ${r.modalidade}</span>
                    <span><i class="fas fa-clock"></i> ${dataFormatada} ${r.horario}</span>
                </div>
            </div>`;
    }).join('');
}

function formatDataShort(dateStr) {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}`;
    return dateStr;
}

// ==================== ALUNOS ====================
async function loadAlunos() {
    const content = document.getElementById('pageContent');
    content.innerHTML = `
        <!-- Actions -->
        <div class="page-actions">
            <div class="search-box">
                <div class="search-wrapper">
                    <i class="fas fa-search"></i>
                    <input type="text" class="search-input" id="searchAlunos" placeholder="Pesquisar por nome...">
                </div>
            </div>
            <div class="filter-group">
                <select class="filter-select" id="filterSerie">
                    <option value="">Todas as séries</option>
                    <option value="6º Ano">6º Ano</option>
                    <option value="7º Ano">7º Ano</option>
                    <option value="8º Ano">8º Ano</option>
                    <option value="9º Ano">9º Ano</option>
                </select>
                <select class="filter-select" id="filterModalidade">
                    <option value="">Todas modalidades</option>
                    <option value="Handebol Masculino">Handebol Masculino</option>
                    <option value="Handebol Feminino">Handebol Feminino</option>
                    <option value="Vôlei Misto">Vôlei Misto</option>
                </select>
                <button class="btn-action btn-export" id="btnExportar">
                    <i class="fas fa-file-csv"></i> Exportar CSV
                </button>
            </div>
        </div>

        <!-- Table -->
        <div class="data-table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID <i class="fas fa-sort"></i></th>
                        <th>Nome <i class="fas fa-sort"></i></th>
                        <th>Idade</th>
                        <th>Série</th>
                        <th>Turma</th>
                        <th>Gênero</th>
                        <th>Modalidade</th>
                        <th>Dia Jogo</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="alunosTableBody">
                    <tr><td colspan="9" style="text-align:center; padding:40px; color: var(--gray);"><i class="fas fa-spinner fa-spin"></i> Carregando...</td></tr>
                </tbody>
            </table>
            <div class="pagination" id="paginationContainer"></div>
        </div>
    `;

    // Event listeners
    document.getElementById('searchAlunos').addEventListener('input', debounce(fetchAlunos, 300));
    document.getElementById('filterSerie').addEventListener('change', fetchAlunos);
    document.getElementById('filterModalidade').addEventListener('change', fetchAlunos);
    document.getElementById('btnExportar').addEventListener('click', exportarCSV);

    fetchAlunos();
}

async function fetchAlunos() {
    const busca = document.getElementById('searchAlunos')?.value || '';
    const serie = document.getElementById('filterSerie')?.value || '';
    const modalidade = document.getElementById('filterModalidade')?.value || '';

    let url = `${API_BASE}/listar.php?`;
    if (busca) url += `busca=${encodeURIComponent(busca)}&`;
    if (serie) url += `serie=${encodeURIComponent(serie)}&`;
    if (modalidade) url += `modalidade=${encodeURIComponent(modalidade)}&`;

    try {
        const response = await fetch(url);
        const data = await response.json();
        alunosData = data.alunos || [];
        currentPageNum = 1;
        renderAlunosTable();
    } catch (error) {
        const tbody = document.getElementById('alunosTableBody');
        if (tbody) tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; color: var(--gray);">Erro ao carregar dados</td></tr>';
    }
}

function renderAlunosTable() {
    const tbody = document.getElementById('alunosTableBody');
    const pagination = document.getElementById('paginationContainer');
    if (!tbody) return;

    const start = (currentPageNum - 1) * perPage;
    const end = start + perPage;
    const pageData = alunosData.slice(start, end);
    const totalPages = Math.ceil(alunosData.length / perPage);

    if (!pageData.length) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align:center; padding:40px; color: var(--gray);"><i class="fas fa-inbox"></i><br>Nenhum aluno encontrado</td></tr>';
        pagination.innerHTML = '';
        return;
    }

    tbody.innerHTML = pageData.map(a => `
        <tr>
            <td>#${a.id}</td>
            <td><strong>${a.nome}</strong></td>
            <td>${a.idade}</td>
            <td><span class="badge badge-blue">${a.serie}</span></td>
            <td>${a.turma}</td>
            <td>${a.genero}</td>
            <td><span class="badge badge-red">${a.modalidade}</span></td>
            <td>${a.dia_jogo}</td>
            <td>
                <div class="table-actions">
                    <button class="btn-icon btn-view" onclick="viewAluno(${a.id})" title="Visualizar">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn-icon btn-delete" onclick="deleteAluno(${a.id}, '${a.nome.replace(/'/g, "\\'")}')" title="Excluir">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    // Pagination
    if (totalPages > 1) {
        let paginationHTML = `<span class="pagination-info">Mostrando ${start + 1}-${Math.min(end, alunosData.length)} de ${alunosData.length}</span>`;
        paginationHTML += '<div class="pagination-buttons">';
        paginationHTML += `<button class="pagination-btn" onclick="goToPage(${currentPageNum - 1})" ${currentPageNum === 1 ? 'disabled' : ''}><i class="fas fa-chevron-left"></i></button>`;

        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPageNum - 1 && i <= currentPageNum + 1)) {
                paginationHTML += `<button class="pagination-btn ${i === currentPageNum ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
            } else if (i === currentPageNum - 2 || i === currentPageNum + 2) {
                paginationHTML += '<span style="color: var(--gray); padding: 0 4px;">...</span>';
            }
        }

        paginationHTML += `<button class="pagination-btn" onclick="goToPage(${currentPageNum + 1})" ${currentPageNum === totalPages ? 'disabled' : ''}><i class="fas fa-chevron-right"></i></button>`;
        paginationHTML += '</div>';
        pagination.innerHTML = paginationHTML;
    } else {
        pagination.innerHTML = `<span class="pagination-info">${alunosData.length} aluno(s) encontrado(s)</span><div></div>`;
    }
}

function goToPage(page) {
    const totalPages = Math.ceil(alunosData.length / perPage);
    if (page < 1 || page > totalPages) return;
    currentPageNum = page;
    renderAlunosTable();
}

function viewAluno(id) {
    const aluno = alunosData.find(a => a.id == id);
    if (!aluno) return;

    const modal = document.getElementById('modalOverlay');
    const content = document.getElementById('modalContent');

    content.innerHTML = `
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-user"></i> Detalhes do Aluno</div>
            <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <div class="modal-field"><label>ID</label><span>#${aluno.id}</span></div>
            <div class="modal-field"><label>Nome Completo</label><span>${aluno.nome}</span></div>
            <div class="modal-field"><label>Idade</label><span>${aluno.idade} anos</span></div>
            <div class="modal-field"><label>Série</label><span>${aluno.serie}</span></div>
            <div class="modal-field"><label>Turma</label><span>${aluno.turma}</span></div>
            <div class="modal-field"><label>Gênero</label><span>${aluno.genero}</span></div>
            <div class="modal-field"><label>Modalidade</label><span>${aluno.modalidade}</span></div>
            <div class="modal-field"><label>Dia do Jogo</label><span>${aluno.dia_jogo}</span></div>
            <div class="modal-field"><label>Data de Cadastro</label><span>${formatDate(aluno.data_cadastro)}</span></div>
        </div>
        <div class="modal-actions">
            <button class="btn-modal btn-modal-secondary" onclick="closeModal()">Fechar</button>
        </div>
    `;

    modal.style.display = 'flex';
}

function editAluno(id) {
    const aluno = alunosData.find(a => a.id == id);
    if (!aluno) return;

    const modal = document.getElementById('modalOverlay');
    const content = document.getElementById('modalContent');

    content.innerHTML = `
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-pen"></i> Editar Aluno</div>
            <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
            <div class="modal-field">
                <label>Nome Completo</label>
                <input type="text" id="editNome" value="${aluno.nome}">
            </div>
            <div class="modal-field">
                <label>Idade</label>
                <input type="number" id="editIdade" value="${aluno.idade}" min="9" max="18">
            </div>
            <div class="modal-field">
                <label>Série</label>
                <select id="editSerie">
                    <option value="6º Ano" ${aluno.serie === '6º Ano' ? 'selected' : ''}>6º Ano</option>
                    <option value="7º Ano" ${aluno.serie === '7º Ano' ? 'selected' : ''}>7º Ano</option>
                    <option value="8º Ano" ${aluno.serie === '8º Ano' ? 'selected' : ''}>8º Ano</option>
                    <option value="9º Ano" ${aluno.serie === '9º Ano' ? 'selected' : ''}>9º Ano</option>
                </select>
            </div>
            <div class="modal-field">
                <label>Turma</label>
                <select id="editTurma">
                    <option value="A" ${aluno.turma === 'A' ? 'selected' : ''}>Turma A</option>
                    <option value="B" ${aluno.turma === 'B' ? 'selected' : ''}>Turma B</option>
                </select>
            </div>
            <div class="modal-field">
                <label>Gênero</label>
                <select id="editGenero">
                    <option value="Masculino" ${aluno.genero === 'Masculino' ? 'selected' : ''}>Masculino</option>
                    <option value="Feminino" ${aluno.genero === 'Feminino' ? 'selected' : ''}>Feminino</option>
                </select>
            </div>
            <div class="modal-field">
                <label>Modalidade</label>
                <select id="editModalidade">
                    <option value="Handebol Masculino" ${aluno.modalidade === 'Handebol Masculino' ? 'selected' : ''}>Handebol Masculino</option>
                    <option value="Handebol Feminino" ${aluno.modalidade === 'Handebol Feminino' ? 'selected' : ''}>Handebol Feminino</option>
                    <option value="Vôlei Misto" ${aluno.modalidade === 'Vôlei Misto' ? 'selected' : ''}>Vôlei Misto</option>
                </select>
            </div>
        </div>
        <div class="modal-actions">
            <button class="btn-modal btn-modal-secondary" onclick="closeModal()">Cancelar</button>
            <button class="btn-modal btn-modal-primary" onclick="saveEditAluno(${aluno.id})">
                <i class="fas fa-save"></i> Salvar
            </button>
        </div>
    `;

    modal.style.display = 'flex';
}

async function saveEditAluno(id) {
    const dados = {
        id: id,
        nome: document.getElementById('editNome').value.trim(),
        idade: parseInt(document.getElementById('editIdade').value),
        serie: document.getElementById('editSerie').value,
        turma: document.getElementById('editTurma').value,
        genero: document.getElementById('editGenero').value,
        modalidade: document.getElementById('editModalidade').value
    };

    try {
        const response = await fetch(`${API_BASE}/editar.php`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });

        const result = await response.json();

        if (result.sucesso) {
            showToast('Aluno atualizado com sucesso!', 'success');
            closeModal();
            fetchAlunos();
        } else {
            showToast(result.erro || 'Erro ao atualizar', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

async function deleteAluno(id, nome) {
    if (!confirm(`Tem certeza que deseja excluir o aluno "${nome}"?`)) return;

    try {
        const response = await fetch(`${API_BASE}/excluir.php`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        });

        const result = await response.json();

        if (result.sucesso) {
            showToast('Aluno excluído com sucesso!', 'success');
            fetchAlunos();
        } else {
            showToast(result.erro || 'Erro ao excluir', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

function exportarCSV() {
    const serie = document.getElementById('filterSerie')?.value || '';
    const modalidade = document.getElementById('filterModalidade')?.value || '';

    let url = `${API_BASE}/exportar.php?`;
    if (serie) url += `serie=${encodeURIComponent(serie)}&`;
    if (modalidade) url += `modalidade=${encodeURIComponent(modalidade)}&`;

    window.open(url, '_blank');
}

// ==================== EQUIPES ====================
// Função removida - seção Equipes foi desativada

// ==================== LIXEIRA ====================
async function loadLixeira() {
    const content = document.getElementById('pageContent');
    content.innerHTML = '<div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Carregando...</p></div>';

    try {
        const [partidasResponse, escalacoesResponse] = await Promise.all([
            fetch(`${API_BASE}/partidas.php`),
            fetch(`${API_BASE}/escalacoes.php`)
        ]);
        
        const partidasData = await partidasResponse.json();
        const escalacoesData = await escalacoesResponse.json();
        
        const partidas = partidasData.partidas || [];
        const escalacoes = escalacoesData.escalacoes || [];

        let html = `
            <div class="page-actions">
                <h3 style="font-size: 1rem; color: var(--gray-light);">Gerenciar Dados Excluídos</h3>
                <p style="color: var(--gray); font-size: 0.85rem; margin: 0;">Visualize e restaure tabelas de jogos e escalações excluídas</p>
            </div>
            
            <div class="lixeira-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="dash-card">
                    <div class="dash-card-header">
                        <div class="dash-card-title">
                            <i class="fas fa-table-columns" style="color: var(--primary); margin-right: 8px;"></i>
                            Tabelas de Jogos
                        </div>
                    </div>
                    <div class="dash-card-body">
                        <div class="stats-list">
                            <div class="stats-list-item">
                                <span class="stats-list-item-label">Total de Partidas</span>
                                <span class="stats-list-item-value">${partidas.length}</span>
                            </div>
                            <div class="stats-list-item">
                                <span class="stats-list-item-label">Módulo I</span>
                                <span class="stats-list-item-value">${partidas.filter(p => p.modulo == 1).length}</span>
                            </div>
                            <div class="stats-list-item">
                                <span class="stats-list-item-label">Módulo II</span>
                                <span class="stats-list-item-value">${partidas.filter(p => p.modulo == 2).length}</span>
                            </div>
                        </div>
                        <div style="margin-top: 16px; display: flex; gap: 8px;">
                            <button class="btn-action" onclick="limparTabelasJogos()" style="background: rgba(220, 38, 38, 0.15); color: var(--primary); border-color: rgba(220, 38, 38, 0.3);">
                                <i class="fas fa-trash"></i> Limpar Tabelas
                            </button>
                            <button class="btn-action" onclick="exportarTabelasJogos()" style="background: rgba(59, 130, 246, 0.15); color: #93c5fd; border-color: rgba(59, 130, 246, 0.3);">
                                <i class="fas fa-download"></i> Exportar
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="dash-card">
                    <div class="dash-card-header">
                        <div class="dash-card-title">
                            <i class="fas fa-clipboard-list" style="color: var(--green); margin-right: 8px;"></i>
                            Escalações
                        </div>
                    </div>
                    <div class="dash-card-body">
                        <div class="stats-list">
                            <div class="stats-list-item">
                                <span class="stats-list-item-label">Total de Escalações</span>
                                <span class="stats-list-item-value">${escalacoes.length}</span>
                            </div>
                            <div class="stats-list-item">
                                <span class="stats-list-item-label">Jogadores Escalados</span>
                                <span class="stats-list-item-value">${escalacoes.reduce((total, esc) => total + (esc.titulares?.length || 0) + (esc.reservas?.length || 0), 0)}</span>
                            </div>
                        </div>
                        <div style="margin-top: 16px; display: flex; gap: 8px;">
                            <button class="btn-action" onclick="limparEscalacoes()" style="background: rgba(220, 38, 38, 0.15); color: var(--primary); border-color: rgba(220, 38, 38, 0.3);">
                                <i class="fas fa-trash"></i> Limpar Escalações
                            </button>
                            <button class="btn-action" onclick="exportarEscalacoes()" style="background: rgba(59, 130, 246, 0.15); color: #93c5fd; border-color: rgba(59, 130, 246, 0.3);">
                                <i class="fas fa-download"></i> Exportar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        content.innerHTML = html;
    } catch (error) {
        content.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro ao carregar</h3></div>';
    }
}

async function limparTabelasJogos() {
    if (!confirm('Tem certeza que deseja limpar todas as tabelas de jogos? Esta ação não pode ser desfeita.')) return;
    
    try {
        const response = await fetch(`${API_BASE}/limpar-tabelas.php`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        if (result.sucesso) {
            showToast('Tabelas de jogos limpas com sucesso!', 'success');
            loadLixeira();
        } else {
            showToast(result.erro || 'Erro ao limpar tabelas', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

async function limparEscalacoes() {
    if (!confirm('Tem certeza que deseja limpar todas as escalações? Esta ação não pode ser desfeita.')) return;
    
    try {
        const response = await fetch(`${API_BASE}/limpar-escalacoes.php`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        if (result.sucesso) {
            showToast('Escalações limpas com sucesso!', 'success');
            loadLixeira();
        } else {
            showToast(result.erro || 'Erro ao limpar escalações', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

async function exportarTabelasJogos() {
    try {
        const response = await fetch(`${API_BASE}/exportar-tabelas.php`);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `tabelas-jogos-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        showToast('Tabelas exportadas com sucesso!', 'success');
    } catch (error) {
        showToast('Erro ao exportar tabelas', 'error');
    }
}

async function exportarEscalacoes() {
    try {
        const response = await fetch(`${API_BASE}/exportar-escalacoes.php`);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `escalacoes-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        showToast('Escalações exportadas com sucesso!', 'success');
    } catch (error) {
        showToast('Erro ao exportar escalações', 'error');
    }
}

// ==================== MODALIDADES ====================
function loadModalidades() {
    const content = document.getElementById('pageContent');
    content.innerHTML = `
        <div class="modalidades-info-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
            <div class="dash-card">
                <div style="text-align: center; padding: 20px;">
                    <div style="width: 70px; height: 70px; background: rgba(220, 38, 38, 0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 1.8rem; color: var(--primary);">
                        <i class="fas fa-hand-back-fist"></i>
                    </div>
                    <h3 style="margin-bottom: 8px;">Handebol Masculino</h3>
                    <p style="color: var(--gray); font-size: 0.85rem;">Exclusivo para alunos do gênero masculino</p>
                    <span class="badge badge-blue" style="margin-top: 12px; display: inline-block;">Masculino</span>
                </div>
            </div>
            <div class="dash-card">
                <div style="text-align: center; padding: 20px;">
                    <div style="width: 70px; height: 70px; background: rgba(236, 72, 153, 0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 1.8rem; color: #f9a8d4;">
                        <i class="fas fa-hand-back-fist"></i>
                    </div>
                    <h3 style="margin-bottom: 8px;">Handebol Feminino</h3>
                    <p style="color: var(--gray); font-size: 0.85rem;">Exclusivo para alunas do gênero feminino</p>
                    <span class="badge badge-purple" style="margin-top: 12px; display: inline-block;">Feminino</span>
                </div>
            </div>
            <div class="dash-card">
                <div style="text-align: center; padding: 20px;">
                    <div style="width: 70px; height: 70px; background: rgba(16, 185, 129, 0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 1.8rem; color: #6ee7b7;">
                        <i class="fas fa-volleyball"></i>
                    </div>
                    <h3 style="margin-bottom: 8px;">Vôlei Misto</h3>
                    <p style="color: var(--gray); font-size: 0.85rem;">Aberto para todos os gêneros</p>
                    <span class="badge badge-green" style="margin-top: 12px; display: inline-block;">Misto</span>
                </div>
            </div>
        </div>

        <div class="dash-card" style="margin-top: 24px;">
            <div class="dash-card-header">
                <div class="dash-card-title"><i class="fas fa-info-circle"></i> Regras de Inscrição</div>
            </div>
            <div class="stats-list">
                <div class="stats-list-item">
                    <span class="stats-list-item-label"><i class="fas fa-mars" style="color: var(--blue); margin-right: 8px;"></i> Gênero Masculino</span>
                    <span class="stats-list-item-value" style="color: var(--gray-light);">Handebol Masc. + Vôlei Misto</span>
                </div>
                <div class="stats-list-item">
                    <span class="stats-list-item-label"><i class="fas fa-venus" style="color: #f9a8d4; margin-right: 8px;"></i> Gênero Feminino</span>
                    <span class="stats-list-item-value" style="color: var(--gray-light);">Handebol Fem. + Vôlei Misto</span>
                </div>
                <div class="stats-list-item">
                    <span class="stats-list-item-label"><i class="fas fa-calendar" style="color: var(--gold); margin-right: 8px;"></i> 8º e 9º Ano</span>
                    <span class="stats-list-item-value" style="color: var(--gold);">Jogos em 19/05/2026</span>
                </div>
                <div class="stats-list-item">
                    <span class="stats-list-item-label"><i class="fas fa-calendar" style="color: var(--green); margin-right: 8px;"></i> 6º e 7º Ano</span>
                    <span class="stats-list-item-value" style="color: var(--green);">Jogos em 20/05/2026</span>
                </div>
            </div>
        </div>
    `;
}

// ==================== TABELA DOS JOGOS ====================
let partidasData = [];

async function loadTabela() {
    const content = document.getElementById('pageContent');
    content.innerHTML = '<div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Carregando...</p></div>';

    try {
        const response = await fetch(`${API_BASE}/partidas.php`);
        const data = await response.json();

        if (data.sucesso) {
            partidasData = data.partidas || [];
            renderTabelaAdmin();
        } else {
            content.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro ao carregar</h3></div>';
        }
    } catch (error) {
        content.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro de conexão</h3></div>';
    }
}

function renderTabelaAdmin() {
    const content = document.getElementById('pageContent');

    const modulo1 = partidasData.filter(p => p.modulo == 1);
    const modulo2 = partidasData.filter(p => p.modulo == 2);

    content.innerHTML = `
        <div class="tabela-admin-info" style="background: rgba(220, 38, 38, 0.1); border: 1px solid rgba(220, 38, 38, 0.3); border-radius: var(--radius); padding: 16px; margin-bottom: 24px; display: flex; align-items: center; gap: 12px;">
            <i class="fas fa-info-circle" style="color: var(--primary); font-size: 1.2rem;"></i>
            <p style="color: var(--gray-light); font-size: 0.9rem; margin: 0;">Edite as equipes, placares e vencedores de cada partida. As alterações serão refletidas na tabela pública do site.</p>
        </div>

        <div class="tabela-admin-tabs" style="display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap;">
            <button class="btn-action" onclick="showModuloAdmin(1)" id="tabModulo1Btn" style="background: var(--primary); color: white;">
                <i class="fas fa-star"></i> Módulo I - 6º/7º Anos
            </button>
            <button class="btn-action" onclick="showModuloAdmin(2)" id="tabModulo2Btn">
                <i class="fas fa-star"></i> Módulo II - 8º/9º Anos
            </button>
            <button class="btn-action" onclick="showAdicionarJogoModal()" style="background: rgba(59, 130, 246, 0.15); color: #93c5fd; border-color: rgba(59, 130, 246, 0.3); margin-left: auto;">
                <i class="fas fa-plus"></i> Adicionar Jogo
            </button>
        </div>

        <div id="tabelaModulo1Content">
            ${renderModuloAdmin(modulo1, 1)}
        </div>
        <div id="tabelaModulo2Content" style="display: none;">
            ${renderModuloAdmin(modulo2, 2)}
        </div>
    `;
}

function showModuloAdmin(modulo) {
    document.getElementById('tabelaModulo1Content').style.display = modulo === 1 ? 'block' : 'none';
    document.getElementById('tabelaModulo2Content').style.display = modulo === 2 ? 'block' : 'none';
    document.getElementById('tabModulo1Btn').style.background = modulo === 1 ? 'var(--primary)' : '';
    document.getElementById('tabModulo1Btn').style.color = modulo === 1 ? 'white' : '';
    document.getElementById('tabModulo2Btn').style.background = modulo === 2 ? 'var(--primary)' : '';
    document.getElementById('tabModulo2Btn').style.color = modulo === 2 ? 'white' : '';
}

function renderModuloAdmin(partidas, modulo) {
    const modalidades = {};
    partidas.forEach(p => {
        if (!modalidades[p.modalidade]) modalidades[p.modalidade] = [];
        modalidades[p.modalidade].push(p);
    });

    let html = '';
    Object.keys(modalidades).forEach(modalidade => {
        const jogos = modalidades[modalidade];
        const semis = jogos.filter(j => j.fase === 'semifinal').sort((a, b) => a.numero_jogo - b.numero_jogo);
        const final = jogos.find(j => j.fase === 'final');

        const headerClass = modulo === 1 ? 'background: linear-gradient(135deg, #1e40af, #3b82f6);' : 'background: linear-gradient(135deg, #d97706, #f59e0b);';

        html += `
            <div class="dash-card" style="margin-bottom: 20px; overflow: hidden;">
                <div style="${headerClass} padding: 14px 20px; margin: -20px -20px 20px -20px;">
                    <h3 style="color: white; font-size: 1rem; font-weight: 700; margin: 0;">${modalidade}</h3>
                    <p style="color: rgba(255,255,255,0.8); font-size: 0.8rem; margin: 4px 0 0 0;">Módulo ${modulo === 1 ? 'I - 6º/7º Anos' : 'II - 8º/9º Anos'}</p>
                </div>

                <h4 style="font-size: 0.85rem; color: var(--primary); margin-bottom: 12px; text-transform: uppercase; letter-spacing: 1px;">Semifinais</h4>
        `;

        semis.forEach(s => {
            html += renderPartidaForm(s);
        });

        if (final) {
            html += `<h4 style="font-size: 0.85rem; color: var(--gold); margin: 20px 0 12px; text-transform: uppercase; letter-spacing: 1px; border-top: 1px solid var(--glass-border); padding-top: 16px;">Final</h4>`;
            html += renderPartidaForm(final);

            html += `
                <div style="margin-top: 16px; padding: 12px 16px; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: var(--radius);">
                    <label style="font-size: 0.8rem; font-weight: 700; color: var(--gold); display: block; margin-bottom: 6px;">
                        <i class="fas fa-trophy"></i> CAMPEÃO
                    </label>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <input type="text" class="search-input" value="${final.campeao || ''}" id="campeao-${final.id}" placeholder="Nome do campeão" style="flex: 1; padding: 8px 12px; font-size: 0.85rem;">
                        <button class="btn-action" onclick="salvarCampeao(${final.id})" style="background: var(--gold); color: #000; font-weight: 700; padding: 8px 16px;">
                            <i class="fas fa-crown"></i> Salvar
                        </button>
                    </div>
                </div>
            `;
        }

        html += `</div>`;
    });

    return html;
}

function renderPartidaForm(partida) {
    const jogoLabel = partida.fase === 'final' ? 'Final' : `Jogo ${partida.numero_jogo}`;
    return `
        <div style="background: var(--dark-600); border-radius: var(--radius); padding: 16px 20px; margin-bottom: 14px; border: 1px solid var(--glass-border);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
                <span style="font-size: 0.82rem; font-weight: 700; color: var(--gray); text-transform: uppercase; letter-spacing: 0.5px;">${jogoLabel}</span>
                <span style="font-size: 0.75rem; color: var(--primary-light); background: rgba(220,38,38,0.1); padding: 3px 10px; border-radius: 4px;">${partida.horario}</span>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 30px 1fr; gap: 10px; align-items: end; margin-bottom: 14px;">
                <div>
                    <label style="font-size: 0.72rem; color: var(--gray); display: block; margin-bottom: 4px; font-weight: 600;">Equipe 1</label>
                    <input type="text" class="search-input" value="${partida.equipe1 || ''}" id="eq1-${partida.id}" placeholder="Turma/Equipe" style="padding: 10px 12px; font-size: 0.85rem; width: 100%; box-sizing: border-box;">
                </div>
                <span style="color: var(--primary); font-weight: 800; padding-bottom: 10px; text-align: center; font-size: 0.95rem;">X</span>
                <div>
                    <label style="font-size: 0.72rem; color: var(--gray); display: block; margin-bottom: 4px; font-weight: 600;">Equipe 2</label>
                    <input type="text" class="search-input" value="${partida.equipe2 || ''}" id="eq2-${partida.id}" placeholder="Turma/Equipe" style="padding: 10px 12px; font-size: 0.85rem; width: 100%; box-sizing: border-box;">
                </div>
            </div>
            <div style="display: grid; grid-template-columns: 80px 80px 1fr 130px auto; gap: 10px; align-items: end;">
                <div>
                    <label style="font-size: 0.72rem; color: var(--gray); display: block; margin-bottom: 4px; font-weight: 600;">Placar 1</label>
                    <input type="text" class="search-input" value="${partida.placar1 || ''}" id="p1-${partida.id}" placeholder="0" style="padding: 10px 12px; font-size: 0.85rem; text-align: center; width: 100%; box-sizing: border-box;">
                </div>
                <div>
                    <label style="font-size: 0.72rem; color: var(--gray); display: block; margin-bottom: 4px; font-weight: 600;">Placar 2</label>
                    <input type="text" class="search-input" value="${partida.placar2 || ''}" id="p2-${partida.id}" placeholder="0" style="padding: 10px 12px; font-size: 0.85rem; text-align: center; width: 100%; box-sizing: border-box;">
                </div>
                <div>
                    <label style="font-size: 0.72rem; color: var(--gray); display: block; margin-bottom: 4px; font-weight: 600;">Vencedor</label>
                    <input type="text" class="search-input" value="${partida.vencedor || ''}" id="venc-${partida.id}" placeholder="Vencedor" style="padding: 10px 12px; font-size: 0.85rem; width: 100%; box-sizing: border-box;">
                </div>
                <div>
                    <label style="font-size: 0.72rem; color: var(--gray); display: block; margin-bottom: 4px; font-weight: 600;">Status</label>
                    <select class="search-input" id="status-${partida.id}" style="padding: 10px 12px; font-size: 0.85rem; width: 100%; box-sizing: border-box; background: var(--dark-700); color: var(--white); border: 1px solid var(--glass-border); border-radius: 8px;">
                        <option value="agendado" ${(partida.status || 'agendado') === 'agendado' ? 'selected' : ''}>Agendado</option>
                        <option value="ao_vivo" ${partida.status === 'ao_vivo' ? 'selected' : ''}>Ao Vivo</option>
                        <option value="encerrado" ${partida.status === 'encerrado' ? 'selected' : ''}>Encerrado</option>
                    </select>
                </div>
                <button class="btn-action" onclick="salvarPartida(${partida.id})" style="background: var(--primary); color: white; padding: 10px 16px; white-space: nowrap; font-weight: 600;">
                    <i class="fas fa-save"></i> Salvar
                </button>
            </div>
        </div>
    `;
}

async function salvarPartida(id) {
    const equipe1 = document.getElementById(`eq1-${id}`).value;
    const equipe2 = document.getElementById(`eq2-${id}`).value;
    const placar1 = document.getElementById(`p1-${id}`).value;
    const placar2 = document.getElementById(`p2-${id}`).value;
    const vencedor = document.getElementById(`venc-${id}`).value;
    const status = document.getElementById(`status-${id}`).value;

    try {
        const response = await fetch(`${API_BASE}/partidas.php`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, equipe1, equipe2, placar1, placar2, vencedor, status })
        });

        const result = await response.json();

        if (result.sucesso) {
            showToast('Partida atualizada com sucesso!', 'success');
        } else {
            showToast(result.erro || 'Erro ao salvar', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

async function salvarCampeao(id) {
    const campeao = document.getElementById(`campeao-${id}`).value;

    try {
        const response = await fetch(`${API_BASE}/partidas.php`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, campeao })
        });

        const result = await response.json();

        if (result.sucesso) {
            showToast('Campeão salvo com sucesso!', 'success');
        } else {
            showToast(result.erro || 'Erro ao salvar', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

// ==================== ADICIONAR JOGO MODAL ====================
function showAdicionarJogoModal() {
    const modal = document.getElementById('modalOverlay');
    if (!modal) return;

    modal.innerHTML = `
        <div class="admin-modal-content" style="max-width: 550px;">
            <div class="admin-modal-header">
                <h3><i class="fas fa-plus-circle"></i> Adicionar Novo Jogo</h3>
                <button class="modal-close-btn" onclick="closeModal()"><i class="fas fa-times"></i></button>
            </div>
            <div class="admin-modal-body">
                <div class="form-group">
                    <label>Módulo</label>
                    <select id="novoJogoModulo" class="form-control">
                        <option value="1">Módulo I - 6º/7º Anos</option>
                        <option value="2">Módulo II - 8º/9º Anos</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Modalidade</label>
                    <select id="novoJogoModalidade" class="form-control">
                        <option value="Vôlei Misto">Vôlei Misto</option>
                        <option value="Handebol Feminino">Handebol Feminino</option>
                        <option value="Handebol Masculino">Handebol Masculino</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Fase</label>
                    <select id="novoJogoFase" class="form-control">
                        <option value="jogo">Jogo</option>
                        <option value="semifinal">Semifinal</option>
                        <option value="final">Final</option>
                    </select>
                </div>
                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label>Equipe 1</label>
                        <input type="text" id="novoJogoEq1" class="form-control" placeholder="Ex: 6ºA">
                    </div>
                    <div class="form-group">
                        <label>Equipe 2</label>
                        <input type="text" id="novoJogoEq2" class="form-control" placeholder="Ex: 7ºB">
                    </div>
                </div>
                <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label>Nº do Jogo</label>
                        <input type="number" id="novoJogoNumero" class="form-control" placeholder="Ex: 5" min="1">
                    </div>
                    <div class="form-group">
                        <label>Data do Jogo</label>
                        <input type="date" id="novoJogoData" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select id="novoJogoStatus" class="form-control">
                        <option value="agendado">Agendado</option>
                        <option value="ao_vivo">Ao Vivo</option>
                        <option value="encerrado">Encerrado</option>
                    </select>
                </div>
                <button class="btn-primary" onclick="criarNovoJogo()" style="width: 100%; margin-top: 12px;">
                    <i class="fas fa-save"></i> Criar Jogo
                </button>
            </div>
        </div>
    `;
    modal.style.display = 'flex';
}

async function criarNovoJogo() {
    const dados = {
        modulo: document.getElementById('novoJogoModulo').value,
        modalidade: document.getElementById('novoJogoModalidade').value,
        fase: document.getElementById('novoJogoFase').value,
        equipe1: document.getElementById('novoJogoEq1').value,
        equipe2: document.getElementById('novoJogoEq2').value,
        numero_jogo: document.getElementById('novoJogoNumero').value,
        data_jogo: document.getElementById('novoJogoData').value,
        status: document.getElementById('novoJogoStatus').value
    };

    if (!dados.equipe1 && !dados.equipe2) {
        showToast('Preencha pelo menos uma equipe', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/partidas.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });
        const result = await response.json();

        if (result.sucesso) {
            showToast('Jogo criado com sucesso!', 'success');
            closeModal();
            loadTabela();
        } else {
            showToast(result.erro || 'Erro ao criar jogo', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

async function excluirPartida(id) {
    if (!confirm('Tem certeza que deseja excluir esta partida?')) return;

    try {
        const response = await fetch(`${API_BASE}/partidas.php`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        });
        const result = await response.json();

        if (result.sucesso) {
            showToast('Partida excluída com sucesso!', 'success');
            loadTabela();
        } else {
            showToast(result.erro || 'Erro ao excluir', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

// ==================== ESCALAÇÃO (ADMIN) ====================
let escalacaoPartidas = [];
let escalacaoAtual = null;

async function loadEscalacao() {
    const content = document.getElementById('pageContent');
    content.innerHTML = '<div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Carregando partidas...</p></div>';

    try {
        const response = await fetch(`${API_BASE}/partidas.php`);
        const data = await response.json();

        if (data.sucesso && data.partidas) {
            escalacaoPartidas = data.partidas;
            renderEscalacaoAdmin();
        } else {
            content.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro ao carregar partidas</h3></div>';
        }
    } catch (error) {
        content.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro de conexão</h3></div>';
    }
}

function renderEscalacaoAdmin() {
    const content = document.getElementById('pageContent');

    const modulo1 = escalacaoPartidas.filter(p => p.modulo == 1);
    const modulo2 = escalacaoPartidas.filter(p => p.modulo == 2);

    content.innerHTML = `
        <div class="tabela-admin-info" style="background: rgba(59,130,246,0.1); border: 1px solid rgba(59,130,246,0.3); border-radius: var(--radius); padding: 16px; margin-bottom: 24px; display: flex; align-items: center; gap: 12px;">
            <i class="fas fa-clipboard-list" style="color: #3b82f6; font-size: 1.2rem;"></i>
            <p style="color: var(--gray-light); font-size: 0.9rem; margin: 0;">Gerencie as escalações de cada partida. Defina titulares e reservas, posições e números de camisa dos jogadores.</p>
        </div>

        <div class="escalacao-partidas-grid">
            <h3 style="color: var(--white); margin-bottom: 12px; font-size: 1.1rem;"><i class="fas fa-layer-group" style="color: #3b82f6;"></i> Módulo I - 6º/7º Anos</h3>
            <div class="escalacao-cards-list">
                ${modulo1.map(p => renderEscalacaoCard(p)).join('')}
                ${modulo1.length === 0 ? '<p style="color: var(--gray); font-size: 0.85rem;">Nenhuma partida cadastrada</p>' : ''}
            </div>

            <h3 style="color: var(--white); margin: 24px 0 12px; font-size: 1.1rem;"><i class="fas fa-layer-group" style="color: #f59e0b;"></i> Módulo II - 8º/9º Anos</h3>
            <div class="escalacao-cards-list">
                ${modulo2.map(p => renderEscalacaoCard(p)).join('')}
                ${modulo2.length === 0 ? '<p style="color: var(--gray); font-size: 0.85rem;">Nenhuma partida cadastrada</p>' : ''}
            </div>
        </div>

        <div id="escalacaoDetalhe"></div>
    `;
}

function renderEscalacaoCard(p) {
    const statusColors = { agendado: '#3b82f6', ao_vivo: '#10b981', encerrado: '#6b7280' };
    const statusLabels = { agendado: 'Agendado', ao_vivo: 'Ao Vivo', encerrado: 'Encerrado' };
    const statusColor = statusColors[p.status] || '#6b7280';
    const statusLabel = statusLabels[p.status] || p.status;

    return `
        <div class="escalacao-card-item" onclick="abrirEscalacaoAdmin(${p.id}, '${(p.equipe1||'').replace(/'/g,"\\'")}', '${(p.equipe2||'').replace(/'/g,"\\'")}', '${(p.modalidade||'').replace(/'/g,"\\'")}', '${p.fase}')">
            <div class="escalacao-card-top">
                <span class="escalacao-card-mod">${p.modalidade}</span>
                <span class="escalacao-card-status" style="background: ${statusColor}20; color: ${statusColor}; border: 1px solid ${statusColor}40;">${statusLabel}</span>
            </div>
            <div class="escalacao-card-teams">
                <span>${p.equipe1 || '-'}</span>
                <span style="color: var(--gray); font-size: 0.75rem;">VS</span>
                <span>${p.equipe2 || '-'}</span>
            </div>
            <div class="escalacao-card-fase">${p.fase} • Jogo ${p.numero_jogo || '-'}</div>
            <button class="btn-escalacao-admin"><i class="fas fa-users"></i> Gerenciar Escalação</button>
        </div>
    `;
}

async function abrirEscalacaoAdmin(partidaId, equipe1, equipe2, modalidade, fase) {
    escalacaoAtual = { partidaId, equipe1, equipe2, modalidade, fase };

    const detalhe = document.getElementById('escalacaoDetalhe');
    if (!detalhe) return;

    detalhe.innerHTML = '<div class="empty-state" style="padding: 20px;"><i class="fas fa-spinner fa-spin"></i><p>Carregando escalação...</p></div>';
    detalhe.scrollIntoView({ behavior: 'smooth', block: 'start' });

    try {
        const response = await fetch(`${API_BASE}/escalacoes.php?partida_id=${partidaId}`);
        const data = await response.json();

        const agrupado = (data.sucesso && data.agrupado) ? data.agrupado : {};

        const equipes = [];
        if (equipe1) equipes.push(equipe1);
        if (equipe2) equipes.push(equipe2);

        detalhe.innerHTML = `
            <div class="escalacao-detalhe-box">
                <div class="escalacao-detalhe-header">
                    <h3><i class="fas fa-clipboard-list"></i> Escalação: ${equipe1 || '-'} vs ${equipe2 || '-'}</h3>
                    <p style="color: var(--gray); font-size: 0.85rem;">${modalidade} • ${fase}</p>
                </div>

                ${equipes.map(eq => `
                    <div class="escalacao-equipe-section">
                        <div class="escalacao-equipe-header">
                            <h4><i class="fas fa-shield-halved"></i> ${eq}</h4>
                            <button class="btn-add-jogador" onclick="showAddJogadorForm(${partidaId}, '${eq.replace(/'/g,"\\'")}')">
                                <i class="fas fa-plus"></i> Adicionar Jogador
                            </button>
                        </div>
                        <div id="addJogadorForm-${partidaId}-${eq.replace(/\s/g,'_')}" style="display:none;"></div>
                        ${renderJogadoresAdmin(agrupado[eq], partidaId, eq)}
                    </div>
                `).join('')}
            </div>
        `;
    } catch (error) {
        detalhe.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro ao carregar escalação</h3></div>';
    }
}

function renderJogadoresAdmin(grupo, partidaId, equipe) {
    if (!grupo) {
        return '<p style="color: var(--gray); font-size: 0.85rem; padding: 12px;">Nenhum jogador cadastrado</p>';
    }

    let html = '';

    if (grupo.titulares && grupo.titulares.length > 0) {
        html += '<div class="escalacao-tipo-label titular"><i class="fas fa-star"></i> Titulares</div>';
        html += '<div class="escalacao-jogadores-list">';
        grupo.titulares.forEach(j => {
            html += renderJogadorRow(j, partidaId, equipe);
        });
        html += '</div>';
    }

    if (grupo.reservas && grupo.reservas.length > 0) {
        html += '<div class="escalacao-tipo-label reserva"><i class="fas fa-bench-tree"></i> Reservas</div>';
        html += '<div class="escalacao-jogadores-list">';
        grupo.reservas.forEach(j => {
            html += renderJogadorRow(j, partidaId, equipe);
        });
        html += '</div>';
    }

    if ((!grupo.titulares || grupo.titulares.length === 0) && (!grupo.reservas || grupo.reservas.length === 0)) {
        html += '<p style="color: var(--gray); font-size: 0.85rem; padding: 12px;">Nenhum jogador cadastrado</p>';
    }

    return html;
}

function renderJogadorRow(j, partidaId, equipe) {
    return `
        <div class="escalacao-jogador-row">
            <div class="escalacao-jogador-numero">${j.numero_camisa || '-'}</div>
            <div class="escalacao-jogador-info">
                <span class="escalacao-jogador-nome">${j.jogador_nome}</span>
                <span class="escalacao-jogador-pos">${j.posicao || '-'}</span>
            </div>
            <span class="escalacao-jogador-tipo ${j.tipo}">${j.tipo === 'titular' ? 'Titular' : 'Reserva'}</span>
            <div class="escalacao-jogador-actions">
                <button class="btn-icon-sm edit" onclick="editarJogador(${j.id}, ${partidaId}, '${equipe.replace(/'/g,"\\'")}', '${(j.jogador_nome||'').replace(/'/g,"\\'")}', '${j.posicao||''}', '${j.tipo}', '${j.numero_camisa||''}')">
                    <i class="fas fa-pen"></i>
                </button>
                <button class="btn-icon-sm delete" onclick="excluirJogador(${j.id}, ${partidaId}, '${equipe.replace(/'/g,"\\'")}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `;
}

function showAddJogadorForm(partidaId, equipe) {
    const containerId = `addJogadorForm-${partidaId}-${equipe.replace(/\s/g,'_')}`;
    const container = document.getElementById(containerId);
    if (!container) return;

    if (container.style.display !== 'none') {
        container.style.display = 'none';
        container.innerHTML = '';
        return;
    }

    container.style.display = 'block';
    container.innerHTML = `
        <div class="add-jogador-form">
            <div style="display: grid; grid-template-columns: 60px 1fr 120px 120px; gap: 8px; align-items: end;">
                <div class="form-group" style="margin:0;">
                    <label style="font-size:0.7rem;">Nº</label>
                    <input type="number" id="novoJogadorNum-${partidaId}-${equipe.replace(/\s/g,'_')}" class="form-control" placeholder="#" min="1" max="99">
                </div>
                <div class="form-group" style="margin:0;">
                    <label style="font-size:0.7rem;">Nome do Jogador</label>
                    <input type="text" id="novoJogadorNome-${partidaId}-${equipe.replace(/\s/g,'_')}" class="form-control" placeholder="Nome completo">
                </div>
                <div class="form-group" style="margin:0;">
                    <label style="font-size:0.7rem;">Posição</label>
                    <input type="text" id="novoJogadorPos-${partidaId}-${equipe.replace(/\s/g,'_')}" class="form-control" placeholder="Ex: Levantador">
                </div>
                <div class="form-group" style="margin:0;">
                    <label style="font-size:0.7rem;">Tipo</label>
                    <select id="novoJogadorTipo-${partidaId}-${equipe.replace(/\s/g,'_')}" class="form-control">
                        <option value="titular">Titular</option>
                        <option value="reserva">Reserva</option>
                    </select>
                </div>
            </div>
            <button class="btn-primary" style="margin-top: 8px; width: 100%;" onclick="salvarNovoJogador(${partidaId}, '${equipe.replace(/'/g,"\\'")}')">
                <i class="fas fa-save"></i> Adicionar Jogador
            </button>
        </div>
    `;
}

async function salvarNovoJogador(partidaId, equipe) {
    const prefix = `${partidaId}-${equipe.replace(/\s/g,'_')}`;
    const nome = document.getElementById(`novoJogadorNome-${prefix}`).value.trim();
    const posicao = document.getElementById(`novoJogadorPos-${prefix}`).value.trim();
    const tipo = document.getElementById(`novoJogadorTipo-${prefix}`).value;
    const numero = document.getElementById(`novoJogadorNum-${prefix}`).value;

    if (!nome) {
        showToast('Informe o nome do jogador', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/escalacoes.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                partida_id: partidaId,
                equipe: equipe,
                jogador_nome: nome,
                posicao: posicao,
                tipo: tipo,
                numero_camisa: numero || null
            })
        });
        const result = await response.json();

        if (result.sucesso) {
            showToast('Jogador adicionado!', 'success');
            abrirEscalacaoAdmin(escalacaoAtual.partidaId, escalacaoAtual.equipe1, escalacaoAtual.equipe2, escalacaoAtual.modalidade, escalacaoAtual.fase);
        } else {
            showToast(result.erro || 'Erro ao adicionar', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

function editarJogador(id, partidaId, equipe, nome, posicao, tipo, numero) {
    const modal = document.getElementById('modalOverlay');
    if (!modal) return;

    modal.innerHTML = `
        <div class="admin-modal-content" style="max-width: 450px;">
            <div class="admin-modal-header">
                <h3><i class="fas fa-pen"></i> Editar Jogador</h3>
                <button class="modal-close-btn" onclick="closeModal()"><i class="fas fa-times"></i></button>
            </div>
            <div class="admin-modal-body">
                <div class="form-group">
                    <label>Número da Camisa</label>
                    <input type="number" id="editJogadorNum" class="form-control" value="${numero}" min="1" max="99">
                </div>
                <div class="form-group">
                    <label>Nome do Jogador</label>
                    <input type="text" id="editJogadorNome" class="form-control" value="${nome}">
                </div>
                <div class="form-group">
                    <label>Posição</label>
                    <input type="text" id="editJogadorPos" class="form-control" value="${posicao}">
                </div>
                <div class="form-group">
                    <label>Tipo</label>
                    <select id="editJogadorTipo" class="form-control">
                        <option value="titular" ${tipo === 'titular' ? 'selected' : ''}>Titular</option>
                        <option value="reserva" ${tipo === 'reserva' ? 'selected' : ''}>Reserva</option>
                    </select>
                </div>
                <button class="btn-primary" onclick="salvarEditJogador(${id})" style="width: 100%; margin-top: 12px;">
                    <i class="fas fa-save"></i> Salvar Alterações
                </button>
            </div>
        </div>
    `;
    modal.style.display = 'flex';
}

async function salvarEditJogador(id) {
    const dados = {
        id: id,
        jogador_nome: document.getElementById('editJogadorNome').value.trim(),
        posicao: document.getElementById('editJogadorPos').value.trim(),
        tipo: document.getElementById('editJogadorTipo').value,
        numero_camisa: document.getElementById('editJogadorNum').value || null
    };

    if (!dados.jogador_nome) {
        showToast('Informe o nome do jogador', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/escalacoes.php`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });
        const result = await response.json();

        if (result.sucesso) {
            showToast('Jogador atualizado!', 'success');
            closeModal();
            if (escalacaoAtual) {
                abrirEscalacaoAdmin(escalacaoAtual.partidaId, escalacaoAtual.equipe1, escalacaoAtual.equipe2, escalacaoAtual.modalidade, escalacaoAtual.fase);
            }
        } else {
            showToast(result.erro || 'Erro ao atualizar', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

async function excluirJogador(id, partidaId, equipe) {
    if (!confirm('Tem certeza que deseja remover este jogador da escalação?')) return;

    try {
        const response = await fetch(`${API_BASE}/escalacoes.php`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        });
        const result = await response.json();

        if (result.sucesso) {
            showToast('Jogador removido!', 'success');
            if (escalacaoAtual) {
                abrirEscalacaoAdmin(escalacaoAtual.partidaId, escalacaoAtual.equipe1, escalacaoAtual.equipe2, escalacaoAtual.modalidade, escalacaoAtual.fase);
            }
        } else {
            showToast(result.erro || 'Erro ao remover', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão', 'error');
    }
}

// ==================== ESTATÍSTICAS ====================
async function loadEstatisticas() {
    const content = document.getElementById('pageContent');
    content.innerHTML = '<div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Carregando...</p></div>';

    try {
        const response = await fetch(`${API_BASE}/dashboard.php`);
        const data = await response.json();

        const porGenero = data.por_genero || [];
        const porDia = data.por_dia_jogo || [];
        const porTurma = data.por_turma || [];

        content.innerHTML = `
            <div class="dashboard-grid">
                <div class="dash-card">
                    <div class="dash-card-header">
                        <div class="dash-card-title"><i class="fas fa-venus-mars"></i> Por Gênero</div>
                    </div>
                    <div class="stats-list">
                        ${porGenero.map(g => `
                            <div class="stats-list-item">
                                <span class="stats-list-item-label">${g.genero}</span>
                                <span class="stats-list-item-value">${g.total} alunos</span>
                            </div>
                        `).join('') || '<div class="empty-state"><p>Sem dados</p></div>'}
                    </div>
                </div>
                <div class="dash-card">
                    <div class="dash-card-header">
                        <div class="dash-card-title"><i class="fas fa-calendar-days"></i> Por Dia de Jogo</div>
                    </div>
                    <div class="stats-list">
                        ${porDia.map(d => `
                            <div class="stats-list-item">
                                <span class="stats-list-item-label">${d.dia_jogo}</span>
                                <span class="stats-list-item-value">${d.total} alunos</span>
                            </div>
                        `).join('') || '<div class="empty-state"><p>Sem dados</p></div>'}
                    </div>
                </div>
            </div>
            <div class="dash-card" style="margin-top: 20px;">
                <div class="dash-card-header">
                    <div class="dash-card-title"><i class="fas fa-door-open"></i> Por Turma</div>
                </div>
                <div class="stats-list">
                    ${porTurma.map(t => `
                        <div class="stats-list-item">
                            <span class="stats-list-item-label">Turma ${t.turma}</span>
                            <span class="stats-list-item-value">${t.total} alunos</span>
                        </div>
                    `).join('') || '<div class="empty-state"><p>Sem dados</p></div>'}
                </div>
            </div>
        `;
    } catch (error) {
        content.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><h3>Erro ao carregar</h3></div>';
    }
}

// ==================== PERFIL ====================
function loadPerfil() {
    const content = document.getElementById('pageContent');
    content.innerHTML = `
        <div class="dash-card" style="max-width: 500px;">
            <div style="text-align: center; padding: 20px;">
                <div style="width: 80px; height: 80px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 2rem;">
                    <i class="fas fa-user"></i>
                </div>
                <h3 style="margin-bottom: 4px;">Administrador</h3>
                <p style="color: var(--gray); font-size: 0.85rem;">Administrador do Sistema</p>
            </div>
            <div class="stats-list" style="margin-top: 20px;">
                <div class="stats-list-item">
                    <span class="stats-list-item-label">Usuário</span>
                    <span class="stats-list-item-value" style="color: var(--gray-light);">admin</span>
                </div>
                <div class="stats-list-item">
                    <span class="stats-list-item-label">Cargo</span>
                    <span class="stats-list-item-value" style="color: var(--gray-light);">Administrador</span>
                </div>
                <div class="stats-list-item">
                    <span class="stats-list-item-label">Sistema</span>
                    <span class="stats-list-item-value" style="color: var(--gray-light);">Interclasse 2026</span>
                </div>
            </div>
        </div>
    `;
}

// ==================== CONFIGURAÇÕES ====================
function loadConfiguracoes() {
    const content = document.getElementById('pageContent');
    content.innerHTML = `
        <div class="dash-card" style="max-width: 600px;">
            <div class="dash-card-header">
                <div class="dash-card-title"><i class="fas fa-cog"></i> Configurações do Sistema</div>
            </div>
            <div class="stats-list">
                <div class="stats-list-item">
                    <span class="stats-list-item-label">Nome do Evento</span>
                    <span class="stats-list-item-value" style="color: var(--gray-light);">Interclasse 2026</span>
                </div>
                <div class="stats-list-item">
                    <span class="stats-list-item-label">Data Jogos (8º/9º)</span>
                    <span class="stats-list-item-value" style="color: var(--gold);">19/05/2026</span>
                </div>
                <div class="stats-list-item">
                    <span class="stats-list-item-label">Data Jogos (6º/7º)</span>
                    <span class="stats-list-item-value" style="color: var(--green);">20/05/2026</span>
                </div>
                <div class="stats-list-item">
                    <span class="stats-list-item-label">Versão do Sistema</span>
                    <span class="stats-list-item-value" style="color: var(--gray-light);">2.0.0</span>
                </div>
                <div class="stats-list-item">
                    <span class="stats-list-item-label">Banco de Dados</span>
                    <span class="stats-list-item-value" style="color: var(--green);">MySQL - Conectado</span>
                </div>
            </div>
        </div>
    `;
}

// ==================== LOGOUT ====================
async function handleLogout() {
    try {
        await fetch(`${API_BASE}/logout.php`);
    } catch (e) {}
    window.location.reload();
}

// ==================== UTILITIES ====================
function closeModal() {
    const modal = document.getElementById('modalOverlay');
    if (modal) modal.style.display = 'none';
}

function formatDate(dateStr) {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const icons = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        info: 'fas fa-info-circle'
    };

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <i class="${icons[type] || icons.info}"></i>
        <span>${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}
