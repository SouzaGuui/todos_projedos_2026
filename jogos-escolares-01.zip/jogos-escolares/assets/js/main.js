/* =====================================================
   INTERCLASSE 2026 - JavaScript Principal (Site Público)
   ===================================================== */

const API_BASE = 'backend';

// ==================== NAVBAR ====================
document.addEventListener('DOMContentLoaded', function() {
    const navToggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
        });

        // Fechar menu ao clicar em link
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
            });
        });
    }

    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (navbar) {
            if (window.scrollY > 50) {
                navbar.style.background = 'rgba(10, 10, 10, 0.98)';
            } else {
                navbar.style.background = 'rgba(10, 10, 10, 0.95)';
            }
        }
    });

    // Inicializar funcionalidades
    initCountdown();
    initCarousel();
    initFormLogic();
    initTabelaJogos();
    initClassificacao();
});

// ==================== CONTAGEM REGRESSIVA ====================
function initCountdown() {
    // Data do primeiro jogo: 19/05/2026
    const gameDate = new Date('2026-05-19T08:00:00').getTime();

    function updateCountdown() {
        const now = new Date().getTime();
        const distance = gameDate - now;

        if (distance < 0) {
            document.getElementById('dias').textContent = '00';
            document.getElementById('horas').textContent = '00';
            document.getElementById('minutos').textContent = '00';
            document.getElementById('segundos').textContent = '00';
            return;
        }

        const dias = Math.floor(distance / (1000 * 60 * 60 * 24));
        const horas = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutos = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const segundos = Math.floor((distance % (1000 * 60)) / 1000);

        document.getElementById('dias').textContent = String(dias).padStart(2, '0');
        document.getElementById('horas').textContent = String(horas).padStart(2, '0');
        document.getElementById('minutos').textContent = String(minutos).padStart(2, '0');
        document.getElementById('segundos').textContent = String(segundos).padStart(2, '0');
    }

    updateCountdown();
    setInterval(updateCountdown, 1000);
}

// ==================== LÓGICA DO FORMULÁRIO ====================
function initFormLogic() {
    const generoSelect = document.getElementById('genero');
    const modalidadeSelect = document.getElementById('modalidade');
    const serieSelect = document.getElementById('serie');
    const formCadastro = document.getElementById('formCadastro');

    if (!generoSelect || !modalidadeSelect || !serieSelect || !formCadastro) return;

    // Modalidade dinâmica baseada no gênero
    generoSelect.addEventListener('change', function() {
        const genero = this.value;
        modalidadeSelect.innerHTML = '';

        if (!genero) {
            modalidadeSelect.innerHTML = '<option value="">Selecione o gênero primeiro</option>';
            modalidadeSelect.disabled = true;
            return;
        }

        modalidadeSelect.disabled = false;
        modalidadeSelect.innerHTML = '<option value="">Selecione a modalidade</option>';

        if (genero === 'Masculino') {
            modalidadeSelect.innerHTML += '<option value="Handebol Masculino">Handebol Masculino</option>';
            modalidadeSelect.innerHTML += '<option value="Vôlei Misto">Vôlei Misto</option>';
            modalidadeSelect.innerHTML += '<option value="Os dois esportes">Os dois esportes</option>';
        } else if (genero === 'Feminino') {
            modalidadeSelect.innerHTML += '<option value="Handebol Feminino">Handebol Feminino</option>';
            modalidadeSelect.innerHTML += '<option value="Vôlei Misto">Vôlei Misto</option>';
            modalidadeSelect.innerHTML += '<option value="Os dois esportes">Os dois esportes</option>';
        }
    });

    // Dia do jogo baseado na série
    serieSelect.addEventListener('change', function() {
        const serie = this.value;
        const infoBox = document.getElementById('infoJogos');
        const texto = document.getElementById('diaJogosTexto');

        if (!serie) {
            infoBox.style.display = 'none';
            return;
        }

        infoBox.style.display = 'flex';

        if (serie === '8º Ano' || serie === '9º Ano') {
            texto.textContent = 'Dia dos Jogos: 19/05/2026 (8º e 9º Ano)';
        } else {
            texto.textContent = 'Dia dos Jogos: 20/05/2026 (6º e 7º Ano)';
        }
    });

    // Submissão do formulário
    formCadastro.addEventListener('submit', function(e) {
        e.preventDefault();

        if (!validateForm()) return;

        const dados = {
            nome: document.getElementById('nome').value.trim(),
            email: document.getElementById('email').value.trim(),
            idade: parseInt(document.getElementById('idade').value),
            serie: document.getElementById('serie').value,
            turma: document.getElementById('turma').value,
            genero: document.getElementById('genero').value,
            modalidade: document.getElementById('modalidade').value
        };

        const alunoId = document.getElementById('alunoId').value;

        if (alunoId) {
            editarAluno(alunoId, dados);
        } else {
            cadastrarAluno(dados);
        }
    });
}

// ==================== VALIDAÇÃO ====================
function validateForm() {
    let valid = true;

    const nome = document.getElementById('nome');
    const email = document.getElementById('email');
    const idade = document.getElementById('idade');
    const serie = document.getElementById('serie');
    const turma = document.getElementById('turma');
    const genero = document.getElementById('genero');
    const modalidade = document.getElementById('modalidade');

    // Reset errors
    clearErrors();

    if (!nome.value.trim() || nome.value.trim().length < 3) {
        showFieldError('erroNome', 'Nome deve ter pelo menos 3 caracteres');
        nome.classList.add('error');
        valid = false;
    }

    if (!email.value.trim()) {
        showFieldError('erroEmail', 'E-mail educacional SESI é obrigatório');
        email.classList.add('error');
        valid = false;
    } else {
        const emailVal = email.value.trim().toLowerCase();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailVal)) {
            showFieldError('erroEmail', 'Formato de e-mail inválido');
            email.classList.add('error');
            valid = false;
        } else if (!emailVal.includes('sesi')) {
            showFieldError('erroEmail', 'Utilize seu e-mail educacional SESI (deve conter "sesi")');
            email.classList.add('error');
            valid = false;
        }
    }

    if (!idade.value || idade.value < 9 || idade.value > 18) {
        showFieldError('erroIdade', 'Idade deve ser entre 9 e 18 anos');
        idade.classList.add('error');
        valid = false;
    }

    if (!serie.value) {
        showFieldError('erroSerie', 'Selecione a série');
        serie.classList.add('error');
        valid = false;
    }

    if (!turma.value) {
        showFieldError('erroTurma', 'Selecione a turma');
        turma.classList.add('error');
        valid = false;
    }

    if (!genero.value) {
        showFieldError('erroGenero', 'Selecione o gênero');
        genero.classList.add('error');
        valid = false;
    }

    if (!modalidade.value) {
        showFieldError('erroModalidade', 'Selecione a modalidade');
        modalidade.classList.add('error');
        valid = false;
    }

    return valid;
}

function showFieldError(id, msg) {
    const el = document.getElementById(id);
    if (el) el.textContent = msg;
}

function clearErrors() {
    document.querySelectorAll('.error-msg').forEach(el => el.textContent = '');
    document.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
}

// ==================== API CALLS ====================
async function cadastrarAluno(dados) {
    try {
        const btn = document.getElementById('btnCadastrar');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cadastrando...';

        const response = await fetch(`${API_BASE}/cadastrar.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });

        const result = await response.json();

        if (result.sucesso) {
            showToast('Inscrição realizada com sucesso!', 'success');
            document.getElementById('formCadastro').reset();
            document.getElementById('modalidade').disabled = true;
            document.getElementById('modalidade').innerHTML = '<option value="">Selecione o gênero primeiro</option>';
            document.getElementById('infoJogos').style.display = 'none';
        } else {
            showToast(result.erro || 'Erro ao realizar inscrição', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão com o servidor', 'error');
        console.error('Erro:', error);
    } finally {
        const btn = document.getElementById('btnCadastrar');
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-paper-plane"></i> Realizar Inscrição';
    }
}

async function editarAluno(id, dados) {
    try {
        const btn = document.getElementById('btnCadastrar');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Atualizando...';

        const response = await fetch(`${API_BASE}/editar.php`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: parseInt(id), ...dados })
        });

        const result = await response.json();

        if (result.sucesso) {
            showToast('Aluno atualizado com sucesso!', 'success');
            document.getElementById('formCadastro').reset();
            document.getElementById('alunoId').value = '';
            document.getElementById('modalidade').disabled = true;
            document.getElementById('modalidade').innerHTML = '<option value="">Selecione o gênero primeiro</option>';
            document.getElementById('infoJogos').style.display = 'none';
            document.getElementById('btnCadastrar').innerHTML = '<i class="fas fa-paper-plane"></i> Realizar Inscrição';
        } else {
            showToast(result.erro || 'Erro ao atualizar aluno', 'error');
        }
    } catch (error) {
        showToast('Erro de conexão com o servidor', 'error');
        console.error('Erro:', error);
    } finally {
        const btn = document.getElementById('btnCadastrar');
        btn.disabled = false;
    }
}

// ==================== TABELA DOS JOGOS ====================
function initTabelaJogos() {
    const tabs = document.querySelectorAll('.tab-btn');
    const modulos = document.querySelectorAll('.tabela-modulo');

    if (!tabs.length) return;

    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            tabs.forEach(t => t.classList.remove('active'));
            modulos.forEach(m => m.classList.remove('active'));

            this.classList.add('active');
            const modulo = this.getAttribute('data-modulo');
            document.getElementById('modulo' + modulo).classList.add('active');
        });
    });

    carregarPartidas();
}

async function carregarPartidas() {
    try {
        const response = await fetch(`${API_BASE}/partidas.php`);
        const data = await response.json();

        if (data.sucesso && data.partidas) {
            partidasDataPublic = data.partidas;
            preencherBrackets(data.partidas);
        }
    } catch (error) {
        console.error('Erro ao carregar partidas:', error);
    }
}

function preencherBrackets(partidas) {
    const mapeamento = {
        '1': {
            'Vôlei Misto': { prefix: 'm1-v', semis: [] , final: null },
            'Handebol Feminino': { prefix: 'm1-hf', semis: [], final: null },
            'Handebol Masculino': { prefix: 'm1-hm', semis: [], final: null }
        },
        '2': {
            'Vôlei Misto': { prefix: 'm2-v', semis: [], final: null },
            'Handebol Feminino': { prefix: 'm2-hf', semis: [], final: null },
            'Handebol Masculino': { prefix: 'm2-hm', semis: [], final: null }
        }
    };

    partidas.forEach(p => {
        const modulo = String(p.modulo);
        const modalidade = p.modalidade;
        if (mapeamento[modulo] && mapeamento[modulo][modalidade]) {
            if (p.fase === 'semifinal') {
                mapeamento[modulo][modalidade].semis.push(p);
            } else if (p.fase === 'final') {
                mapeamento[modulo][modalidade].final = p;
            }
        }
    });

    Object.keys(mapeamento).forEach(modulo => {
        Object.keys(mapeamento[modulo]).forEach(modalidade => {
            const info = mapeamento[modulo][modalidade];
            const prefix = info.prefix;

            info.semis.sort((a, b) => a.numero_jogo - b.numero_jogo);

            if (info.semis[0]) {
                setTextIfExists(`${prefix}-s1-eq1`, info.semis[0].equipe1 || '-');
                setTextIfExists(`${prefix}-s1-eq2`, info.semis[0].equipe2 || '-');
                setTextIfExists(`${prefix}-s1-p1`, info.semis[0].placar1 || '-');
                setTextIfExists(`${prefix}-s1-p2`, info.semis[0].placar2 || '-');
                addEscalacaoBtn(`${prefix}-s1`, info.semis[0]);
            }

            if (info.semis[1]) {
                setTextIfExists(`${prefix}-s2-eq1`, info.semis[1].equipe1 || '-');
                setTextIfExists(`${prefix}-s2-eq2`, info.semis[1].equipe2 || '-');
                setTextIfExists(`${prefix}-s2-p1`, info.semis[1].placar1 || '-');
                setTextIfExists(`${prefix}-s2-p2`, info.semis[1].placar2 || '-');
                addEscalacaoBtn(`${prefix}-s2`, info.semis[1]);
            }

            if (info.final) {
                const f = info.final;
                setTextIfExists(`${prefix}-f-eq1`, f.equipe1 || 'Vencedor Jogo ' + (info.semis[0] ? info.semis[0].numero_jogo : '?'));
                setTextIfExists(`${prefix}-f-eq2`, f.equipe2 || 'Vencedor Jogo ' + (info.semis[1] ? info.semis[1].numero_jogo : '?'));
                setTextIfExists(`${prefix}-f-p1`, f.placar1 || '-');
                setTextIfExists(`${prefix}-f-p2`, f.placar2 || '-');
                setTextIfExists(`${prefix}-campeao`, f.campeao || '-');
                addEscalacaoBtn(`${prefix}-f`, f);
            }
        });
    });
}

function addEscalacaoBtn(prefix, partida) {
    const eqEl = document.getElementById(`${prefix}-eq1`);
    if (!eqEl) return;
    const jogoContainer = eqEl.closest('.bracket-jogo');
    if (!jogoContainer) return;
    if (jogoContainer.querySelector('.btn-escalacao')) return;

    const btn = document.createElement('button');
    btn.className = 'btn-escalacao';
    btn.innerHTML = '<i class="fas fa-clipboard-list"></i> Escalação';
    btn.onclick = function(e) {
        e.stopPropagation();
        abrirModalEscalacao(partida.id, partida.equipe1, partida.equipe2, partida.modalidade);
    };
    jogoContainer.appendChild(btn);
}

function setTextIfExists(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
}

// ==================== CAROUSEL ====================
function initCarousel() {
    const slides = document.querySelectorAll('.carousel-slide');
    const dots = document.querySelectorAll('.carousel-dots .dot');
    const prevBtn = document.getElementById('carouselPrev');
    const nextBtn = document.getElementById('carouselNext');

    if (!slides.length) return;

    let current = 0;
    let autoTimer = null;

    function goToSlide(index) {
        slides.forEach(s => s.classList.remove('active'));
        dots.forEach(d => d.classList.remove('active'));
        current = (index + slides.length) % slides.length;
        slides[current].classList.add('active');
        if (dots[current]) dots[current].classList.add('active');
    }

    function startAuto() {
        autoTimer = setInterval(() => goToSlide(current + 1), 5000);
    }

    function resetAuto() {
        clearInterval(autoTimer);
        startAuto();
    }

    if (prevBtn) prevBtn.addEventListener('click', () => { goToSlide(current - 1); resetAuto(); });
    if (nextBtn) nextBtn.addEventListener('click', () => { goToSlide(current + 1); resetAuto(); });

    dots.forEach(dot => {
        dot.addEventListener('click', function() {
            goToSlide(parseInt(this.getAttribute('data-slide')));
            resetAuto();
        });
    });

    startAuto();
}

// ==================== MODAL ESPORTE ====================
const esportesInfo = {
    'handebol-masc': {
        titulo: 'Handebol Masculino',
        icon: '<i class="fas fa-hand-back-fist"></i>',
        historia: 'O Handebol foi criado em 1919 pelo professor alemão Karl Schelenz. Inicialmente praticado em campos abertos com 11 jogadores por equipe, o esporte evoluiu para a versão indoor com 7 jogadores que conhecemos hoje. Tornou-se esporte olímpico em 1972 (masculino) nos Jogos de Munique. O Brasil tem tradição no handebol, com a seleção masculina conquistando importantes títulos sul-americanos e participações em mundiais.',
        regras: [
            'Cada equipe tem 7 jogadores em quadra (6 de linha + 1 goleiro)',
            'O jogo é dividido em dois tempos de 30 minutos (adaptado no escolar)',
            'O jogador pode dar no máximo 3 passos com a bola na mão',
            'A bola pode ser segurada por no máximo 3 segundos',
            'Apenas o goleiro pode entrar na área do gol (6 metros)',
            'Faltas podem resultar em tiro livre direto ou exclusão de 2 minutos',
            'O gol é válido quando a bola ultrapassa completamente a linha do gol',
            'O arremesso de 7 metros é equivalente ao pênalti no futebol'
        ],
        interclasse: 'No Interclasse 2026, o Handebol Masculino é disputado pelos alunos do gênero masculino. As turmas formam suas equipes e competem em formato de semifinais e final, com jogos adaptados ao tempo escolar. É uma das modalidades mais emocionantes do torneio!'
    },
    'handebol-fem': {
        titulo: 'Handebol Feminino',
        icon: '<i class="fas fa-hand-back-fist"></i>',
        historia: 'O Handebol feminino começou a ganhar destaque internacional a partir da década de 1960. Tornou-se modalidade olímpica em 1976 nos Jogos de Montreal. A seleção brasileira feminina é uma das mais fortes do mundo, tendo conquistado o título mundial em 2013, na Sérvia, um marco histórico para o esporte brasileiro. O handebol feminino escolar é fundamental para revelar novos talentos e incentivar a prática esportiva entre as jovens.',
        regras: [
            'Cada equipe tem 7 jogadoras em quadra (6 de linha + 1 goleira)',
            'O jogo é dividido em dois tempos de 30 minutos (adaptado no escolar)',
            'A jogadora pode dar no máximo 3 passos com a bola na mão',
            'A bola pode ser segurada por no máximo 3 segundos',
            'Apenas a goleira pode entrar na área do gol (6 metros)',
            'Faltas podem resultar em tiro livre direto ou exclusão de 2 minutos',
            'O gol é válido quando a bola ultrapassa completamente a linha do gol',
            'Substituições são ilimitadas e podem ser feitas a qualquer momento'
        ],
        interclasse: 'No Interclasse 2026, o Handebol Feminino é disputado pelas alunas do gênero feminino. As turmas formam suas equipes e competem em formato de semifinais e final. É uma oportunidade para as alunas mostrarem suas habilidades e trabalho em equipe!'
    },
    'volei': {
        titulo: 'Vôlei Misto',
        icon: '<i class="fas fa-volleyball"></i>',
        historia: 'O Vôlei foi inventado em 1895 por William G. Morgan nos Estados Unidos, como uma alternativa menos intensa ao basquete. Esta versão adaptada é muito popular em escolas e atividades recreativas. Nesta modalidade, o jogador pode segurar a bola antes de passá-la ou enviá-la para o outro lado, tornando o jogo mais acessível. A versão mista promove a integração entre meninos e meninas, valorizando a inclusão e o espírito esportivo.',
        regras: [
            'Equipes mistas com jogadores de ambos os gêneros',
            'O jogador pode segurar a bola por até 3 segundos antes de passá-la',
            'A bola deve ser lançada (não golpeada) por cima da rede',
            'Cada equipe pode dar até 3 passes antes de enviar a bola ao outro lado',
            'O rodízio de posições segue o sentido horário',
            'A quadra tem as mesmas dimensões do vôlei tradicional',
            'Os sets são jogados até 25 pontos (adaptado conforme o tempo)',
            'A bola não pode ser carregada ou arremessada com as duas mãos acima da cabeça'
        ],
        interclasse: 'No Interclasse 2026, o Vôlei Misto é aberto para todos os gêneros. É a modalidade mais inclusiva do torneio, incentivando a participação de todos os alunos. As turmas montam equipes mistas para competir em semifinais e final!'
    }
};

function abrirModalEsporte(tipo) {
    const info = esportesInfo[tipo];
    if (!info) return;

    document.getElementById('modalEsporteTitulo').textContent = info.titulo;
    document.getElementById('modalEsporteIcon').innerHTML = info.icon;
    document.getElementById('modalEsporteHistoria').textContent = info.historia;
    document.getElementById('modalEsporteInterclasse').textContent = info.interclasse;

    const regrasUl = document.getElementById('modalEsporteRegras');
    regrasUl.innerHTML = '';
    info.regras.forEach(regra => {
        const li = document.createElement('li');
        li.textContent = regra;
        regrasUl.appendChild(li);
    });

    document.getElementById('modalEsporte').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function fecharModalEsporte() {
    document.getElementById('modalEsporte').classList.remove('active');
    document.body.style.overflow = '';
}

document.addEventListener('click', function(e) {
    if (e.target.id === 'modalEsporte') {
        fecharModalEsporte();
    }
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        fecharModalEsporte();
        fecharModalEscalacao();
    }
});

// ==================== ESCALAÇÃO MODAL ====================
let partidasDataPublic = [];

function abrirModalEscalacao(partidaId, equipe1, equipe2, modalidade) {
    const modal = document.getElementById('modalEscalacao');
    const subtitulo = document.getElementById('escalacaoSubtitulo');
    const body = document.getElementById('escalacaoBody');

    subtitulo.textContent = `${equipe1 || '-'} vs ${equipe2 || '-'} • ${modalidade || ''}`;
    body.innerHTML = '<div class="escalacao-empty"><i class="fas fa-spinner fa-spin"></i><br>Carregando escalação...</div>';

    modal.classList.add('active');
    document.body.style.overflow = 'hidden';

    fetch(`${API_BASE}/escalacoes.php?partida_id=${partidaId}`)
        .then(res => res.json())
        .then(data => {
            if (!data.sucesso || !data.agrupado || Object.keys(data.agrupado).length === 0) {
                body.innerHTML = '<div class="escalacao-empty"><i class="fas fa-users-slash"></i><br>Nenhuma escalação cadastrada para esta partida.</div>';
                return;
            }
            renderEscalacaoModal(data.agrupado, body);
        })
        .catch(() => {
            body.innerHTML = '<div class="escalacao-empty"><i class="fas fa-exclamation-triangle"></i><br>Erro ao carregar escalação.</div>';
        });
}

function renderEscalacaoModal(agrupado, container) {
    let html = '';
    Object.keys(agrupado).forEach(equipe => {
        const grupo = agrupado[equipe];
        html += `<div class="escalacao-team">`;
        html += `<div class="escalacao-team-name"><i class="fas fa-shield-halved"></i> ${equipe}</div>`;

        if (grupo.titulares && grupo.titulares.length > 0) {
            html += `<span class="escalacao-group-title titular">Titulares</span>`;
            grupo.titulares.forEach(j => {
                html += `
                    <div class="escalacao-player">
                        <div class="escalacao-player-number">${j.numero_camisa || '-'}</div>
                        <div class="escalacao-player-name">${j.jogador_nome}</div>
                        <div class="escalacao-player-pos">${j.posicao || '-'}</div>
                    </div>`;
            });
        }

        if (grupo.reservas && grupo.reservas.length > 0) {
            html += `<span class="escalacao-group-title reserva">Reservas</span>`;
            grupo.reservas.forEach(j => {
                html += `
                    <div class="escalacao-player">
                        <div class="escalacao-player-number">${j.numero_camisa || '-'}</div>
                        <div class="escalacao-player-name">${j.jogador_nome}</div>
                        <div class="escalacao-player-pos">${j.posicao || '-'}</div>
                    </div>`;
            });
        }

        if ((!grupo.titulares || grupo.titulares.length === 0) && (!grupo.reservas || grupo.reservas.length === 0)) {
            html += '<div class="escalacao-empty" style="padding:10px;"><i class="fas fa-info-circle"></i> Sem jogadores cadastrados</div>';
        }

        html += `</div>`;
    });
    container.innerHTML = html;
}

function fecharModalEscalacao() {
    const modal = document.getElementById('modalEscalacao');
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

document.addEventListener('click', function(e) {
    if (e.target.id === 'modalEscalacao') {
        fecharModalEscalacao();
    }
});

// ==================== CLASSIFICAÇÃO ====================
function initClassificacao() {
    const mainEl = document.getElementById('classificacaoMain');
    const proximasEl = document.getElementById('proximasPartidasList');
    if (!mainEl) return;

    fetch(`${API_BASE}/classificacao.php`)
        .then(res => res.json())
        .then(data => {
            if (!data.sucesso) {
                mainEl.innerHTML = '<p class="classificacao-loading">Erro ao carregar classificação</p>';
                return;
            }
            renderClassificacao(data.classificacao, mainEl);
            renderProximasPartidas(data.proximas_partidas, proximasEl);
        })
        .catch(() => {
            mainEl.innerHTML = '<p class="classificacao-loading">Erro ao carregar classificação</p>';
        });
}

function renderClassificacao(classificacao, container) {
    if (!classificacao || classificacao.length === 0) {
        container.innerHTML = '<p class="classificacao-loading">Nenhuma classificação disponível ainda</p>';
        return;
    }

    let html = '';
    classificacao.forEach(grupo => {
        const moduloLabel = grupo.modulo == 1 ? 'Módulo I' : 'Módulo II';
        html += `
            <div class="standings-card">
                <div class="standings-header">
                    <h3><i class="fas fa-trophy"></i> ${grupo.modalidade}</h3>
                    <span class="standings-badge">${moduloLabel} • ${grupo.total_times} times</span>
                </div>
                <table class="standings-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>TIME</th>
                            <th>P</th>
                            <th>V</th>
                            <th>E</th>
                            <th>D</th>
                            <th>SG</th>
                        </tr>
                    </thead>
                    <tbody>`;

        grupo.times.forEach((time, idx) => {
            const rank = idx + 1;
            const rankClass = rank === 1 ? 'rank-1' : (rank === 2 ? 'rank-2' : 'rank-other');
            const sgClass = time.sg > 0 ? 'standings-sg-pos' : (time.sg < 0 ? 'standings-sg-neg' : '');
            const sgDisplay = time.sg > 0 ? `+${time.sg}` : time.sg;

            html += `
                        <tr>
                            <td><span class="standings-rank ${rankClass}">${rank}</span></td>
                            <td>${time.nome}</td>
                            <td class="standings-p">${time.p}</td>
                            <td class="standings-v">${time.v}</td>
                            <td>${time.e}</td>
                            <td class="standings-d">${time.d}</td>
                            <td class="${sgClass}">${sgDisplay}</td>
                        </tr>`;
        });

        html += `
                    </tbody>
                </table>
            </div>`;
    });

    container.innerHTML = html;
}

function renderProximasPartidas(proximas, container) {
    if (!container) return;

    if (!proximas || proximas.length === 0) {
        container.innerHTML = '<div class="proxima-empty"><i class="fas fa-calendar-check"></i><br>Nenhuma partida agendada</div>';
        return;
    }

    let html = '';
    proximas.forEach(p => {
        const dataFormatada = p.data_jogo ? formatarData(p.data_jogo) : '';
        const statusIcon = p.status === 'ao_vivo' ? '<span style="color:#10b981;font-weight:700;"> 🔴 AO VIVO</span>' : '';
        html += `
            <div class="proxima-item">
                <div class="proxima-teams">${p.equipe1} vs ${p.equipe2}${statusIcon}</div>
                <div class="proxima-meta">
                    <span class="proxima-modalidade">${p.modalidade}</span>
                    <span class="proxima-horario">${dataFormatada} ${p.horario}</span>
                </div>
            </div>`;
    });

    container.innerHTML = html;
}

function formatarData(dateStr) {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
        return `${parts[2]}/${parts[1]}`;
    }
    return dateStr;
}

// ==================== REGULAMENTO ====================
const regDocs = {
    condutas: {
        titulo: 'Condutas do Esporte',
        subtitulo: 'Código de Conduta — CE 240 Ferraz de Vasconcelos',
        icone: 'fas fa-shield-halved',
        iconeBg: 'rgba(220,38,38,0.15)',
        iconeColor: '#fca5a5',
        tipo: 'pdf',
        arquivo: 'assets/docs/condutas-esporte.pdf',
        resumo: [
            {
                titulo: 'O que é este documento?',
                texto: 'O Código de Condutas do Esporte estabelece normas claras para garantir a prática esportiva, aulas de educação física e competições interclasses, promovendo respeito, segurança e espírito esportivo entre todos os participantes da comunidade escolar.'
            },
            {
                titulo: 'Condutas dos Professores e Juízes',
                itens: [
                    'Aplicar normas com imparcialidade, respeitando todas as equipes e participantes.',
                    'Intervir imediatamente em situações de conflito para proteger a integridade dos alunos.',
                    'Paralisar o jogo imediatamente em caso de acidente ou lesão.',
                    'Tomar decisões claras e comunicar de forma transparente aos participantes.'
                ]
            },
            {
                titulo: 'Condutas dos Alunos nas Atividades Esportivas',
                itens: [
                    'Respeitar professores, juízes, colegas e adversários em todos os momentos.',
                    'Cumprir as regras da modalidade esportiva com honestidade e ética.',
                    'Informar imediatamente qualquer problema de saúde ou segurança.',
                    'Incentivar o espírito de equipe e apoiar os companheiros.'
                ]
            },
            {
                titulo: 'Fair Play — Jogo Limpo',
                texto: 'O Fair Play representa o verdadeiro espírito do jogo limpo: honestidade, respeito, solidariedade e ética. Valoriza o esforço e o cumprimento das regras acima do resultado final, combatendo discriminação e promovendo um ambiente seguro e acolhedor.'
            }
        ]
    },
    protagonismo: {
        titulo: 'Protagonismo Estudantil',
        subtitulo: 'Regimento Interno para Estudantes — SESI CE 240',
        icone: 'fas fa-star',
        iconeBg: 'rgba(59,130,246,0.15)',
        iconeColor: '#93c5fd',
        tipo: 'imagem',
        arquivo: 'assets/docs/protagonismo-estudantil.jpg',
        resumo: [
            {
                titulo: 'Objetivo do Regimento',
                texto: 'Orientar os estudantes quanto à postura adequada durante a participação nas atividades propostas, promovendo um ambiente de respeito, organização e aprendizado dentro da comunidade escolar SESI.'
            },
            {
                titulo: 'Normas de Conduta (Art. 1º)',
                itens: [
                    'Respeitar colegas, professores, estagiários e demais colaboradores com cordialidade e educação.',
                    'Manter comportamento adequado, sem brincadeiras inadequadas, agressões ou qualquer forma de violência.',
                    'Participar das atividades de forma responsável, colaborativa e comprometida.',
                    'Contribuir para um ambiente seguro, acolhedor e harmonioso, promovendo o diálogo e a resolução pacífica de conflitos.'
                ]
            },
            {
                titulo: 'O que NÃO é permitido (Art. 2º)',
                itens: [
                    'Utilizar linguagem ofensiva, desrespeitosa ou discriminatória.',
                    'Interromper ou abandonar as atividades sem autorização prévia.',
                    'Usar celular ou dispositivos eletrônicos durante atividades sem finalidade pedagógica.',
                    'Comparecer às atividades com vestimentas fora do uniforme escolar estabelecido.'
                ]
            },
            {
                titulo: 'Deveres do Estudante (Art. 3º)',
                itens: [
                    'Manter o caderno em dia e entregar trabalhos nas datas estabelecidas.',
                    'Cumprir os horários de entrada, intervalo e saída.',
                    'Zelar pelo material escolar e pelos espaços coletivos.',
                    'Respeitar os espaços escolares, mantendo-os limpos e organizados.'
                ]
            }
        ]
    },
    jogos: {
        titulo: 'Jogos Interclasse',
        subtitulo: 'Regulamento Oficial — Interclasse 2026 "Para a Vida Toda"',
        icone: 'fas fa-trophy',
        iconeBg: 'rgba(245,158,11,0.15)',
        iconeColor: '#fcd34d',
        tipo: 'pdf',
        arquivo: 'assets/docs/jogos-interclasses.pdf',
        resumo: [
            {
                titulo: 'Sobre o Evento',
                texto: 'Os Jogos Interclasses 2026 têm como tema "Para a Vida Toda" e integram o Projeto SESI-SP Pedagogia do Exemplo. O torneio promove o protagonismo juvenil, os valores do Olimpismo e a interação social entre alunos de diferentes séries do CE 240 de Ferraz de Vasconcelos.'
            },
            {
                titulo: 'Modalidades e Módulos',
                itens: [
                    'Módulo I: turmas de 6º e 7º anos (jogos em 20/05/2026 às 7h30).',
                    'Módulo II: turmas de 8º e 9º anos (jogos em 19/05/2026 às 7h30).',
                    'Modalidades: Handebol Feminino, Handebol Masculino e Voleibol Misto (Câmbio para 6º/7º).',
                    'Sistema: eliminatória simples — Semifinal e Final. Máximo de 12 atletas por equipe.'
                ]
            },
            {
                titulo: 'Regras Principais',
                itens: [
                    'Aluno suspenso automaticamente da próxima partida ao receber 1 cartão vermelho ou 2 amarelos.',
                    'Todos os participantes devem estar uniformizados; a escola fornece coletes de identificação.',
                    'Cada aluno pode participar de apenas uma modalidade, com inscrição prévia obrigatória.',
                    'Handebol: 2 tempos de 15 min. Voleibol: melhor de 2 sets de 15 pontos (tie-break em 15 pts).'
                ]
            },
            {
                titulo: 'Comissão Organizadora',
                texto: 'A comissão disciplinadora é presidida pela diretora Luciana e coordenadora Elaine, apoiados pela equipe de professores e inspetores. Atitudes antidesportivas podem resultar em aviso verbal, desconto de pontos na classificação ou desclassificação da sala.'
            }
        ]
    }
};

function abrirRegulamento() {
    const modal = document.getElementById('modalRegulamento');
    if (!modal) return;
    document.getElementById('regCards').style.display = 'grid';
    document.getElementById('regDetalhe').style.display = 'none';
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function fecharRegulamento(e) {
    if (e && e.target !== document.getElementById('modalRegulamento')) return;
    const modal = document.getElementById('modalRegulamento');
    if (!modal) return;
    modal.classList.remove('active');
    document.body.style.overflow = '';
}

function abrirDocRegulamento(chave) {
    const doc = regDocs[chave];
    if (!doc) return;

    document.getElementById('regCards').style.display = 'none';
    const detalhe = document.getElementById('regDetalhe');
    detalhe.style.display = 'block';

    let resumoHTML = '';
    doc.resumo.forEach(bloco => {
        resumoHTML += `<div class="reg-resumo">
            <h4><i class="fas fa-chevron-right" style="margin-right:6px;"></i>${bloco.titulo}</h4>`;
        if (bloco.texto) {
            resumoHTML += `<p>${bloco.texto}</p>`;
        }
        if (bloco.itens) {
            resumoHTML += '<ul>';
            bloco.itens.forEach(item => {
                resumoHTML += `<li><i class="fas fa-circle"></i><span>${item}</span></li>`;
            });
            resumoHTML += '</ul>';
        }
        resumoHTML += '</div>';
    });

    let docHTML = '';
    if (doc.tipo === 'imagem') {
        docHTML = `
            <div class="reg-imagem-preview">
                <img src="${doc.arquivo}" alt="${doc.titulo}">
            </div>
            <div class="reg-doc-actions">
                <a href="${doc.arquivo}" target="_blank" class="reg-btn-view">
                    <i class="fas fa-expand"></i> Ver em tela cheia
                </a>
                <a href="${doc.arquivo}" download class="reg-btn-download">
                    <i class="fas fa-download"></i> Baixar imagem
                </a>
            </div>`;
    } else {
        docHTML = `
            <div class="reg-doc-actions">
                <a href="${doc.arquivo}" target="_blank" class="reg-btn-view">
                    <i class="fas fa-file-pdf"></i> Abrir PDF
                </a>
                <a href="${doc.arquivo}" download class="reg-btn-download">
                    <i class="fas fa-download"></i> Baixar PDF
                </a>
            </div>`;
    }

    document.getElementById('regDetalheContent').innerHTML = `
        <div class="reg-detalhe-inner">
            <div class="reg-detalhe-top">
                <div class="reg-card-icon" style="background:${doc.iconeBg}; color:${doc.iconeColor};">
                    <i class="${doc.icone}"></i>
                </div>
                <div>
                    <h3>${doc.titulo}</h3>
                    <p>${doc.subtitulo}</p>
                </div>
            </div>
            ${resumoHTML}
            ${docHTML}
        </div>`;

    detalhe.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function voltarRegCards() {
    document.getElementById('regCards').style.display = 'grid';
    document.getElementById('regDetalhe').style.display = 'none';
    document.getElementById('regDetalheContent').innerHTML = '';
}

// ==================== TOAST ====================
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const icons = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        info: 'fas fa-info-circle'
    };

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <i class="${icons[type] || icons.info}"></i>
        <span>${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}
