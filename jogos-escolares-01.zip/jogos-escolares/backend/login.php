<?php
/**
 * Login Administrativo - API Endpoint
 * Método: POST
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['erro' => 'Método não permitido']);
    exit;
}

$dados = json_decode(file_get_contents('php://input'), true);

$usuario = trim($dados['usuario'] ?? '');
$senha = trim($dados['senha'] ?? '');

if (empty($usuario) || empty($senha)) {
    http_response_code(400);
    echo json_encode(['erro' => 'Usuário e senha são obrigatórios']);
    exit;
}

try {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM administradores WHERE usuario = :usuario");
    $stmt->execute([':usuario' => $usuario]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($senha, $admin['senha'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_nome'] = $admin['nome'];
        $_SESSION['logado'] = true;

        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Login realizado com sucesso!',
            'nome' => $admin['nome']
        ]);
    } else {
        http_response_code(401);
        echo json_encode(['erro' => 'Usuário ou senha inválidos']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro no login: ' . $e->getMessage()]);
}
