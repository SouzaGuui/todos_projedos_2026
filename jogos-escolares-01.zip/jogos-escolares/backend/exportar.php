<?php
/**
 * Exportar Dados - CSV/Excel
 * Método: GET
 * Parâmetros: formato (csv)
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['erro' => 'Método não permitido']);
    exit;
}

try {
    $pdo = getConnection();
    
    $where = [];
    $params = [];

    if (!empty($_GET['serie'])) {
        $where[] = "serie = :serie";
        $params[':serie'] = $_GET['serie'];
    }

    if (!empty($_GET['modalidade'])) {
        $where[] = "modalidade = :modalidade";
        $params[':modalidade'] = $_GET['modalidade'];
    }

    $sql = "SELECT id, nome, idade, serie, turma, genero, modalidade, dia_jogo, data_cadastro FROM alunos";
    if (!empty($where)) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }
    $sql .= " ORDER BY nome ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $alunos = $stmt->fetchAll();

    // Exportar como CSV
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="alunos_jogos_escolares_' . date('Y-m-d') . '.csv"');

    $output = fopen('php://output', 'w');
    
    // BOM para Excel reconhecer UTF-8
    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));
    
    // Cabeçalho
    fputcsv($output, ['ID', 'Nome', 'Idade', 'Série', 'Turma', 'Gênero', 'Modalidade', 'Dia do Jogo', 'Data Cadastro'], ';');

    // Dados
    foreach ($alunos as $aluno) {
        fputcsv($output, $aluno, ';');
    }

    fclose($output);
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['erro' => 'Erro ao exportar: ' . $e->getMessage()]);
}
