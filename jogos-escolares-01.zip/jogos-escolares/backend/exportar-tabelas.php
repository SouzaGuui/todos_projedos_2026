<?php
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="tabelas-jogos-' . date('Y-m-d') . '.csv"');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

try {
    $stmt = $pdo->query("SELECT * FROM partidas ORDER BY modulo, modalidade, fase, numero_jogo");
    $partidas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $output = fopen('php://output', 'w');
    
    // Cabeçalho CSV
    fputcsv($output, ['ID', 'Módulo', 'Modalidade', 'Fase', 'Número do Jogo', 'Horário', 'Data', 'Equipe 1', 'Equipe 2', 'Placar 1', 'Placar 2', 'Campeão']);
    
    // Dados das partidas
    foreach ($partidas as $partida) {
        fputcsv($output, [
            $partida['id'],
            $partida['modulo'] == 1 ? 'Módulo I' : 'Módulo II',
            $partida['modalidade'],
            $partida['fase'],
            $partida['numero_jogo'],
            $partida['horario'],
            $partida['data_jogo'],
            $partida['equipe1'],
            $partida['equipe2'],
            $partida['placar1'],
            $partida['placar2'],
            $partida['campeao']
        ]);
    }
    
    fclose($output);
    
} catch (Exception $e) {
    http_response_code(500);
    echo "Erro ao exportar tabelas: " . $e->getMessage();
}
?>
