<?php
/**
 * Dashboard - Estatísticas e Contadores
 * Método: GET
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['erro' => 'Método não permitido']);
    exit;
}

try {
    $pdo = getConnection();

    // Total de alunos
    $total = $pdo->query("SELECT COUNT(*) as total FROM alunos")->fetch()['total'];

    // Total de equipes
    $total_equipes = $pdo->query("SELECT COUNT(*) as total FROM equipes")->fetch()['total'];

    // Por modalidade
    $stmt = $pdo->query("SELECT modalidade, COUNT(*) as total FROM alunos GROUP BY modalidade");
    $por_modalidade = $stmt->fetchAll();

    // Por série
    $stmt = $pdo->query("SELECT serie, COUNT(*) as total FROM alunos GROUP BY serie ORDER BY serie");
    $por_serie = $stmt->fetchAll();

    // Por turma
    $stmt = $pdo->query("SELECT turma, COUNT(*) as total FROM alunos GROUP BY turma");
    $por_turma = $stmt->fetchAll();

    // Por gênero
    $stmt = $pdo->query("SELECT genero, COUNT(*) as total FROM alunos GROUP BY genero");
    $por_genero = $stmt->fetchAll();

    // Por dia de jogo
    $stmt = $pdo->query("SELECT dia_jogo, COUNT(*) as total FROM alunos GROUP BY dia_jogo");
    $por_dia = $stmt->fetchAll();

    // Últimos cadastros
    $stmt = $pdo->query("SELECT * FROM alunos ORDER BY data_cadastro DESC LIMIT 5");
    $ultimos = $stmt->fetchAll();

    echo json_encode([
        'sucesso' => true,
        'total' => intval($total),
        'total_equipes' => intval($total_equipes),
        'por_modalidade' => $por_modalidade,
        'por_serie' => $por_serie,
        'por_turma' => $por_turma,
        'por_genero' => $por_genero,
        'por_dia_jogo' => $por_dia,
        'recentes' => $ultimos
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro ao buscar estatísticas: ' . $e->getMessage()]);
}
