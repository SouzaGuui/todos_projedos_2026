<?php
/**
 * Gerenciar Equipes - API Endpoint
 * Métodos: GET, POST, DELETE
 */

require_once __DIR__ . '/../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];

try {
    $pdo = getConnection();

    switch ($method) {
        case 'GET':
            $sql = "SELECT e.*, COUNT(ae.aluno_id) as total_membros 
                    FROM equipes e 
                    LEFT JOIN aluno_equipe ae ON e.id = ae.equipe_id 
                    GROUP BY e.id 
                    ORDER BY e.criado_em DESC";
            $stmt = $pdo->query($sql);
            $equipes = $stmt->fetchAll();

            echo json_encode(['sucesso' => true, 'equipes' => $equipes]);
            break;

        case 'POST':
            $dados = json_decode(file_get_contents('php://input'), true);
            $nome = trim($dados['nome'] ?? '');
            $modalidade = trim($dados['modalidade'] ?? '');
            $serie = trim($dados['serie'] ?? '');
            $turma = trim($dados['turma'] ?? '');
            $alunos_ids = $dados['alunos_ids'] ?? [];

            if (empty($nome) || empty($modalidade)) {
                http_response_code(400);
                echo json_encode(['erro' => 'Nome e modalidade são obrigatórios']);
                exit;
            }

            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO equipes (nome, modalidade, serie, turma) VALUES (:nome, :modalidade, :serie, :turma)");
            $stmt->execute([
                ':nome' => $nome,
                ':modalidade' => $modalidade,
                ':serie' => $serie,
                ':turma' => $turma
            ]);
            $equipe_id = $pdo->lastInsertId();

            if (!empty($alunos_ids)) {
                $stmt = $pdo->prepare("INSERT INTO aluno_equipe (aluno_id, equipe_id) VALUES (:aluno_id, :equipe_id)");
                foreach ($alunos_ids as $aluno_id) {
                    $stmt->execute([':aluno_id' => intval($aluno_id), ':equipe_id' => $equipe_id]);
                }
            }

            $pdo->commit();

            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Equipe criada com sucesso!',
                'id' => $equipe_id
            ]);
            break;

        case 'DELETE':
            $dados = json_decode(file_get_contents('php://input'), true);
            $id = intval($dados['id'] ?? 0);

            if ($id <= 0) {
                http_response_code(400);
                echo json_encode(['erro' => 'ID inválido']);
                exit;
            }

            $stmt = $pdo->prepare("DELETE FROM equipes WHERE id = :id");
            $stmt->execute([':id' => $id]);

            echo json_encode(['sucesso' => true, 'mensagem' => 'Equipe excluída com sucesso!']);
            break;

        default:
            http_response_code(405);
            echo json_encode(['erro' => 'Método não permitido']);
    }
} catch (PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['erro' => 'Erro: ' . $e->getMessage()]);
}
