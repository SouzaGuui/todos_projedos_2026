<?php
/**
 * Listar Alunos - API Endpoint
 * Método: GET
 * Parâmetros: serie, busca, modalidade, turma
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['erro' => 'Método não permitido']);
    exit;
}

try {
    $pdo = getConnection();
    
    $where = [];
    $params = [];

    // Filtro por série
    if (!empty($_GET['serie'])) {
        $where[] = "serie = :serie";
        $params[':serie'] = $_GET['serie'];
    }

    // Filtro por turma
    if (!empty($_GET['turma'])) {
        $where[] = "turma = :turma";
        $params[':turma'] = $_GET['turma'];
    }

    // Filtro por modalidade
    if (!empty($_GET['modalidade'])) {
        $where[] = "modalidade = :modalidade";
        $params[':modalidade'] = $_GET['modalidade'];
    }

    // Filtro por gênero
    if (!empty($_GET['genero'])) {
        $where[] = "genero = :genero";
        $params[':genero'] = $_GET['genero'];
    }

    // Busca por nome
    if (!empty($_GET['busca'])) {
        $where[] = "nome LIKE :busca";
        $params[':busca'] = '%' . $_GET['busca'] . '%';
    }

    $sql = "SELECT * FROM alunos";
    if (!empty($where)) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }
    $sql .= " ORDER BY data_cadastro DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $alunos = $stmt->fetchAll();

    echo json_encode([
        'sucesso' => true,
        'total' => count($alunos),
        'alunos' => $alunos
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro ao listar: ' . $e->getMessage()]);
}
