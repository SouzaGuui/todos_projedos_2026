<?php
/**
 * Editar Aluno - API Endpoint
 * Método: PUT
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(['erro' => 'Método não permitido']);
    exit;
}

$dados = json_decode(file_get_contents('php://input'), true);

$id = intval($dados['id'] ?? 0);
$nome = trim($dados['nome'] ?? '');
$idade = intval($dados['idade'] ?? 0);
$serie = trim($dados['serie'] ?? '');
$turma = trim($dados['turma'] ?? '');
$genero = trim($dados['genero'] ?? '');
$modalidade = trim($dados['modalidade'] ?? '');

// Validações
$erros = [];

if ($id <= 0) {
    $erros[] = 'ID inválido';
}

if (empty($nome) || strlen($nome) < 3) {
    $erros[] = 'Nome completo é obrigatório (mínimo 3 caracteres)';
}

if ($idade < 9 || $idade > 18) {
    $erros[] = 'Idade deve estar entre 9 e 18 anos';
}

$series_validas = ['6º Ano', '7º Ano', '8º Ano', '9º Ano'];
if (!in_array($serie, $series_validas)) {
    $erros[] = 'Série inválida';
}

$turmas_validas = ['A', 'B'];
if (!in_array($turma, $turmas_validas)) {
    $erros[] = 'Turma inválida';
}

$generos_validos = ['Masculino', 'Feminino'];
if (!in_array($genero, $generos_validos)) {
    $erros[] = 'Gênero inválido';
}

$modalidades_validas = ['Handebol Masculino', 'Handebol Feminino', 'Vôlei Misto'];
if (!in_array($modalidade, $modalidades_validas)) {
    $erros[] = 'Modalidade inválida';
}

if ($genero === 'Masculino' && $modalidade === 'Handebol Feminino') {
    $erros[] = 'Modalidade incompatível com o gênero';
}
if ($genero === 'Feminino' && $modalidade === 'Handebol Masculino') {
    $erros[] = 'Modalidade incompatível com o gênero';
}

if (!empty($erros)) {
    http_response_code(400);
    echo json_encode(['erro' => implode('; ', $erros)]);
    exit;
}

// Determinar dia do jogo
if (in_array($serie, ['8º Ano', '9º Ano'])) {
    $dia_jogo = '19/05/2026';
} else {
    $dia_jogo = '20/05/2026';
}

try {
    $pdo = getConnection();
    
    // Verificar se aluno existe
    $check = $pdo->prepare("SELECT id FROM alunos WHERE id = :id");
    $check->execute([':id' => $id]);
    if (!$check->fetch()) {
        http_response_code(404);
        echo json_encode(['erro' => 'Aluno não encontrado']);
        exit;
    }

    $sql = "UPDATE alunos SET nome = :nome, idade = :idade, serie = :serie, 
            turma = :turma, genero = :genero, modalidade = :modalidade, dia_jogo = :dia_jogo 
            WHERE id = :id";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nome' => $nome,
        ':idade' => $idade,
        ':serie' => $serie,
        ':turma' => $turma,
        ':genero' => $genero,
        ':modalidade' => $modalidade,
        ':dia_jogo' => $dia_jogo,
        ':id' => $id
    ]);

    echo json_encode([
        'sucesso' => true,
        'mensagem' => 'Aluno atualizado com sucesso!'
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro ao atualizar: ' . $e->getMessage()]);
}
