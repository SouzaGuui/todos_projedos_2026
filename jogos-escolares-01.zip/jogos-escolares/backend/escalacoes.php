<?php
/**
 * Escalações - API Endpoint
 * GET: listar escalação de uma partida
 * POST: adicionar jogador à escalação
 * PUT: atualizar jogador na escalação
 * DELETE: remover jogador da escalação
 */

require_once __DIR__ . '/../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        listarEscalacao();
        break;
    case 'POST':
        adicionarJogador();
        break;
    case 'PUT':
        atualizarJogador();
        break;
    case 'DELETE':
        removerJogador();
        break;
    default:
        http_response_code(405);
        echo json_encode(['erro' => 'Método não permitido']);
}

function listarEscalacao() {
    try {
        $pdo = getConnection();

        $partida_id = intval($_GET['partida_id'] ?? 0);

        if ($partida_id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM escalacoes WHERE partida_id = :pid ORDER BY equipe, tipo, numero_camisa, jogador_nome");
            $stmt->execute([':pid' => $partida_id]);
        } else {
            $stmt = $pdo->query("SELECT * FROM escalacoes ORDER BY partida_id, equipe, tipo, numero_camisa, jogador_nome");
        }

        $escalacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Agrupar por equipe
        $agrupado = [];
        foreach ($escalacoes as $e) {
            $key = $e['equipe'];
            if (!isset($agrupado[$key])) {
                $agrupado[$key] = ['titulares' => [], 'reservas' => []];
            }
            if ($e['tipo'] === 'titular') {
                $agrupado[$key]['titulares'][] = $e;
            } else {
                $agrupado[$key]['reservas'][] = $e;
            }
        }

        echo json_encode([
            'sucesso' => true,
            'escalacoes' => $escalacoes,
            'agrupado' => $agrupado
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao listar escalação: ' . $e->getMessage()]);
    }
}

function adicionarJogador() {
    if (!isset($_SESSION['admin_id'])) {
        http_response_code(401);
        echo json_encode(['erro' => 'Acesso não autorizado']);
        return;
    }

    $dados = json_decode(file_get_contents('php://input'), true);

    $partida_id = intval($dados['partida_id'] ?? 0);
    $equipe = trim($dados['equipe'] ?? '');
    $jogador_nome = trim($dados['jogador_nome'] ?? '');
    $posicao = trim($dados['posicao'] ?? '');
    $tipo = trim($dados['tipo'] ?? 'titular');
    $numero_camisa = isset($dados['numero_camisa']) && $dados['numero_camisa'] !== '' ? intval($dados['numero_camisa']) : null;

    if ($partida_id <= 0 || $equipe === '' || $jogador_nome === '') {
        http_response_code(400);
        echo json_encode(['erro' => 'Partida, equipe e nome do jogador são obrigatórios']);
        return;
    }

    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("INSERT INTO escalacoes (partida_id, equipe, jogador_nome, posicao, tipo, numero_camisa) VALUES (:pid, :eq, :nome, :pos, :tipo, :num)");
        $stmt->execute([
            ':pid' => $partida_id,
            ':eq' => $equipe,
            ':nome' => $jogador_nome,
            ':pos' => $posicao,
            ':tipo' => $tipo,
            ':num' => $numero_camisa
        ]);

        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Jogador adicionado à escalação!',
            'id' => $pdo->lastInsertId()
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao adicionar jogador: ' . $e->getMessage()]);
    }
}

function atualizarJogador() {
    if (!isset($_SESSION['admin_id'])) {
        http_response_code(401);
        echo json_encode(['erro' => 'Acesso não autorizado']);
        return;
    }

    $dados = json_decode(file_get_contents('php://input'), true);
    $id = intval($dados['id'] ?? 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['erro' => 'ID inválido']);
        return;
    }

    try {
        $pdo = getConnection();

        $campos = [];
        $params = [':id' => $id];

        if (isset($dados['jogador_nome'])) {
            $campos[] = "jogador_nome = :nome";
            $params[':nome'] = trim($dados['jogador_nome']);
        }
        if (isset($dados['posicao'])) {
            $campos[] = "posicao = :pos";
            $params[':pos'] = trim($dados['posicao']);
        }
        if (isset($dados['tipo'])) {
            $campos[] = "tipo = :tipo";
            $params[':tipo'] = trim($dados['tipo']);
        }
        if (isset($dados['numero_camisa'])) {
            $campos[] = "numero_camisa = :num";
            $params[':num'] = $dados['numero_camisa'] !== '' ? intval($dados['numero_camisa']) : null;
        }

        if (empty($campos)) {
            http_response_code(400);
            echo json_encode(['erro' => 'Nenhum campo para atualizar']);
            return;
        }

        $sql = "UPDATE escalacoes SET " . implode(', ', $campos) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        echo json_encode(['sucesso' => true, 'mensagem' => 'Jogador atualizado!']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao atualizar: ' . $e->getMessage()]);
    }
}

function removerJogador() {
    if (!isset($_SESSION['admin_id'])) {
        http_response_code(401);
        echo json_encode(['erro' => 'Acesso não autorizado']);
        return;
    }

    $dados = json_decode(file_get_contents('php://input'), true);
    $id = intval($dados['id'] ?? 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['erro' => 'ID inválido']);
        return;
    }

    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("DELETE FROM escalacoes WHERE id = :id");
        $stmt->execute([':id' => $id]);

        echo json_encode(['sucesso' => true, 'mensagem' => 'Jogador removido da escalação!']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao remover: ' . $e->getMessage()]);
    }
}
