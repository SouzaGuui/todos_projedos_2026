<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

try {
    // Limpar tabela de escalacoes
    $stmt = $pdo->prepare("DELETE FROM escalacoes");
    $stmt->execute();
    
    echo json_encode(['sucesso' => true, 'mensagem' => 'Escalações limpas com sucesso!']);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['sucesso' => false, 'erro' => 'Erro ao limpar escalações: ' . $e->getMessage()]);
}
?>
