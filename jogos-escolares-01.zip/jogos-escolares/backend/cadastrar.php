<?php
/**
 * Cadastrar Aluno - API Endpoint
 * Método: POST
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['erro' => 'Método não permitido']);
    exit;
}

$dados = json_decode(file_get_contents('php://input'), true);

$nome = trim($dados['nome'] ?? '');
$email = trim($dados['email'] ?? '');
$idade = intval($dados['idade'] ?? 0);
$serie = trim($dados['serie'] ?? '');
$turma = trim($dados['turma'] ?? '');
$genero = trim($dados['genero'] ?? '');
$modalidade = trim($dados['modalidade'] ?? '');

// Validações
$erros = [];

if (empty($nome) || strlen($nome) < 3) {
    $erros[] = 'Nome completo é obrigatório (mínimo 3 caracteres)';
}

if (empty($email)) {
    $erros[] = 'E-mail educacional SESI é obrigatório';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $erros[] = 'Formato de e-mail inválido';
} elseif (stripos($email, 'sesi') === false) {
    $erros[] = 'Utilize seu e-mail educacional SESI (deve conter "sesi")';
}

if ($idade < 9 || $idade > 18) {
    $erros[] = 'Idade deve estar entre 9 e 18 anos';
}

$series_validas = ['6º Ano', '7º Ano', '8º Ano', '9º Ano'];
if (!in_array($serie, $series_validas)) {
    $erros[] = 'Série inválida';
}

$turmas_validas = ['A', 'B'];
if (!in_array($turma, $turmas_validas)) {
    $erros[] = 'Turma inválida';
}

$generos_validos = ['Masculino', 'Feminino'];
if (!in_array($genero, $generos_validos)) {
    $erros[] = 'Gênero inválido';
}

$modalidades_validas = ['Handebol Masculino', 'Handebol Feminino', 'Vôlei Misto', 'Os dois esportes'];
if (!in_array($modalidade, $modalidades_validas)) {
    $erros[] = 'Modalidade inválida';
}

// Validar modalidade conforme gênero
if ($genero === 'Masculino' && $modalidade === 'Handebol Feminino') {
    $erros[] = 'Modalidade incompatível com o gênero selecionado';
}
if ($genero === 'Feminino' && $modalidade === 'Handebol Masculino') {
    $erros[] = 'Modalidade incompatível com o gênero selecionado';
}

if (!empty($erros)) {
    http_response_code(400);
    echo json_encode(['erro' => implode('; ', $erros)]);
    exit;
}

// Determinar dia do jogo
if (in_array($serie, ['8º Ano', '9º Ano'])) {
    $dia_jogo = '19/05/2026';
} else {
    $dia_jogo = '20/05/2026';
}

try {
    $pdo = getConnection();

    // Adiciona a coluna email automaticamente se ainda não existir
    try {
        $pdo->exec("ALTER TABLE alunos ADD COLUMN email VARCHAR(255) NOT NULL DEFAULT '' AFTER nome");
    } catch (PDOException $e) {
        // Coluna já existe — ignorar
    }

    $sql = "INSERT INTO alunos (nome, email, idade, serie, turma, genero, modalidade, dia_jogo) 
            VALUES (:nome, :email, :idade, :serie, :turma, :genero, :modalidade, :dia_jogo)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nome'       => $nome,
        ':email'      => $email,
        ':idade'      => $idade,
        ':serie'      => $serie,
        ':turma'      => $turma,
        ':genero'     => $genero,
        ':modalidade' => $modalidade,
        ':dia_jogo'   => $dia_jogo
    ]);

    $id = $pdo->lastInsertId();

    echo json_encode([
        'sucesso'   => true,
        'mensagem'  => 'Aluno cadastrado com sucesso!',
        'id'        => $id,
        'dia_jogo'  => $dia_jogo
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro ao cadastrar: ' . $e->getMessage()]);
}
