<?php
/**
 * Classificação - Standings & Próximas Partidas
 * Método: GET
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['erro' => 'Método não permitido']);
    exit;
}

try {
    $pdo = getConnection();

    // Buscar todas as partidas
    $stmt = $pdo->query("SELECT * FROM partidas ORDER BY modulo, modalidade, numero_jogo");
    $partidas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Computar classificação por modalidade
    $classificacao = [];
    foreach ($partidas as $p) {
        $mod = $p['modalidade'];
        if (!isset($classificacao[$mod])) {
            $classificacao[$mod] = ['times' => [], 'modulo' => $p['modulo']];
        }

        // Só conta jogos encerrados (com placar preenchido)
        if ($p['placar1'] !== '' && $p['placar2'] !== '' && $p['equipe1'] !== '' && $p['equipe2'] !== '') {
            $p1 = intval($p['placar1']);
            $p2 = intval($p['placar2']);

            // Equipe 1
            if (!isset($classificacao[$mod]['times'][$p['equipe1']])) {
                $classificacao[$mod]['times'][$p['equipe1']] = ['p' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'sg' => 0, 'gp' => 0, 'gc' => 0];
            }
            // Equipe 2
            if (!isset($classificacao[$mod]['times'][$p['equipe2']])) {
                $classificacao[$mod]['times'][$p['equipe2']] = ['p' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'sg' => 0, 'gp' => 0, 'gc' => 0];
            }

            $classificacao[$mod]['times'][$p['equipe1']]['gp'] += $p1;
            $classificacao[$mod]['times'][$p['equipe1']]['gc'] += $p2;
            $classificacao[$mod]['times'][$p['equipe2']]['gp'] += $p2;
            $classificacao[$mod]['times'][$p['equipe2']]['gc'] += $p1;

            if ($p1 > $p2) {
                $classificacao[$mod]['times'][$p['equipe1']]['v']++;
                $classificacao[$mod]['times'][$p['equipe1']]['p'] += 3;
                $classificacao[$mod]['times'][$p['equipe2']]['d']++;
            } elseif ($p2 > $p1) {
                $classificacao[$mod]['times'][$p['equipe2']]['v']++;
                $classificacao[$mod]['times'][$p['equipe2']]['p'] += 3;
                $classificacao[$mod]['times'][$p['equipe1']]['d']++;
            } else {
                $classificacao[$mod]['times'][$p['equipe1']]['e']++;
                $classificacao[$mod]['times'][$p['equipe1']]['p'] += 1;
                $classificacao[$mod]['times'][$p['equipe2']]['e']++;
                $classificacao[$mod]['times'][$p['equipe2']]['p'] += 1;
            }

            $classificacao[$mod]['times'][$p['equipe1']]['sg'] = $classificacao[$mod]['times'][$p['equipe1']]['gp'] - $classificacao[$mod]['times'][$p['equipe1']]['gc'];
            $classificacao[$mod]['times'][$p['equipe2']]['sg'] = $classificacao[$mod]['times'][$p['equipe2']]['gp'] - $classificacao[$mod]['times'][$p['equipe2']]['gc'];
        } else {
            // Adicionar equipes sem resultados também
            if ($p['equipe1'] !== '' && !isset($classificacao[$mod]['times'][$p['equipe1']])) {
                $classificacao[$mod]['times'][$p['equipe1']] = ['p' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'sg' => 0, 'gp' => 0, 'gc' => 0];
            }
            if ($p['equipe2'] !== '' && !isset($classificacao[$mod]['times'][$p['equipe2']])) {
                $classificacao[$mod]['times'][$p['equipe2']] = ['p' => 0, 'v' => 0, 'e' => 0, 'd' => 0, 'sg' => 0, 'gp' => 0, 'gc' => 0];
            }
        }
    }

    // Ordenar times por pontos, depois por SG
    $resultado = [];
    foreach ($classificacao as $mod => $data) {
        $times = [];
        foreach ($data['times'] as $nome => $stats) {
            $stats['nome'] = $nome;
            $times[] = $stats;
        }
        usort($times, function($a, $b) {
            if ($b['p'] !== $a['p']) return $b['p'] - $a['p'];
            return $b['sg'] - $a['sg'];
        });
        $resultado[] = [
            'modalidade' => $mod,
            'modulo' => $data['modulo'],
            'total_times' => count($times),
            'times' => $times
        ];
    }

    // Próximas partidas (sem placar preenchido)
    $proximas = [];
    foreach ($partidas as $p) {
        $status = $p['status'] ?? 'agendado';
        if ($status !== 'encerrado' && $p['equipe1'] !== '' && $p['equipe2'] !== '') {
            $proximas[] = [
                'equipe1' => $p['equipe1'],
                'equipe2' => $p['equipe2'],
                'modalidade' => $p['modalidade'],
                'horario' => $p['horario'],
                'data_jogo' => $p['data_jogo'] ?? '',
                'status' => $status
            ];
        }
    }

    // Resultados recentes (com placar)
    $resultados = [];
    foreach ($partidas as $p) {
        if ($p['placar1'] !== '' && $p['placar2'] !== '' && $p['equipe1'] !== '' && $p['equipe2'] !== '') {
            $resultados[] = [
                'equipe1' => $p['equipe1'],
                'equipe2' => $p['equipe2'],
                'placar1' => $p['placar1'],
                'placar2' => $p['placar2'],
                'modalidade' => $p['modalidade'],
                'horario' => $p['horario'],
                'data_jogo' => $p['data_jogo'] ?? '',
                'vencedor' => $p['vencedor']
            ];
        }
    }

    // Estatísticas do campeonato
    $total_alunos = $pdo->query("SELECT COUNT(*) as total FROM alunos")->fetch()['total'];

    $stmt_modal = $pdo->query("SELECT modalidade, COUNT(*) as total FROM alunos GROUP BY modalidade ORDER BY total DESC LIMIT 1");
    $modalidade_popular = $stmt_modal->fetch();

    $stmt_turma = $pdo->query("SELECT CONCAT(serie, ' ', turma) as turma_nome, COUNT(*) as total FROM alunos GROUP BY serie, turma ORDER BY total DESC LIMIT 1");
    $turma_destaque = $stmt_turma->fetch();

    $jogos_encerrados = 0;
    $jogos_agendados = 0;
    $jogos_ao_vivo = 0;
    foreach ($partidas as $p) {
        $st = $p['status'] ?? 'agendado';
        if ($p['placar1'] !== '' && $p['placar2'] !== '') {
            $jogos_encerrados++;
        } elseif ($st === 'ao_vivo') {
            $jogos_ao_vivo++;
        } else {
            $jogos_agendados++;
        }
    }

    echo json_encode([
        'sucesso' => true,
        'classificacao' => $resultado,
        'proximas_partidas' => array_slice($proximas, 0, 5),
        'resultados_recentes' => array_slice($resultados, 0, 5),
        'estatisticas' => [
            'total_inscritos' => intval($total_alunos),
            'modalidade_popular' => $modalidade_popular ? $modalidade_popular['modalidade'] : '-',
            'modalidade_popular_total' => $modalidade_popular ? intval($modalidade_popular['total']) : 0,
            'turma_destaque' => $turma_destaque ? $turma_destaque['turma_nome'] : '-',
            'turma_destaque_total' => $turma_destaque ? intval($turma_destaque['total']) : 0,
            'jogos_encerrados' => $jogos_encerrados,
            'jogos_agendados' => $jogos_agendados,
            'jogos_ao_vivo' => $jogos_ao_vivo
        ]
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro ao buscar classificação: ' . $e->getMessage()]);
}
