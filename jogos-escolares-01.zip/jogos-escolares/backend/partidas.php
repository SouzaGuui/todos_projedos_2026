<?php
/**
 * Partidas/Jogos - API Endpoint
 * Métodos: GET (listar), POST (criar), PUT (atualizar resultado), DELETE (remover)
 */

require_once __DIR__ . '/../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        listarPartidas();
        break;
    case 'POST':
        criarPartida();
        break;
    case 'PUT':
        atualizarPartida();
        break;
    case 'DELETE':
        deletarPartida();
        break;
    default:
        http_response_code(405);
        echo json_encode(['erro' => 'Método não permitido']);
}

function listarPartidas() {
    try {
        $pdo = getConnection();

        $where = [];
        $params = [];

        if (!empty($_GET['modulo'])) {
            $where[] = "modulo = :modulo";
            $params[':modulo'] = intval($_GET['modulo']);
        }

        if (!empty($_GET['modalidade'])) {
            $where[] = "modalidade = :modalidade";
            $params[':modalidade'] = $_GET['modalidade'];
        }

        $sql = "SELECT * FROM partidas";
        if (!empty($where)) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }
        $sql .= " ORDER BY modulo, id";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $partidas = $stmt->fetchAll();

        echo json_encode([
            'sucesso' => true,
            'partidas' => $partidas
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao listar partidas: ' . $e->getMessage()]);
    }
}

function criarPartida() {
    if (!isset($_SESSION['admin_id'])) {
        http_response_code(401);
        echo json_encode(['erro' => 'Acesso não autorizado']);
        return;
    }

    $dados = json_decode(file_get_contents('php://input'), true);

    $modulo = intval($dados['modulo'] ?? 0);
    $modalidade = trim($dados['modalidade'] ?? '');
    $fase = trim($dados['fase'] ?? 'semifinal');
    $numero_jogo = intval($dados['numero_jogo'] ?? 0);
    $horario = trim($dados['horario'] ?? '');
    $data_jogo = trim($dados['data_jogo'] ?? '');
    $equipe1 = trim($dados['equipe1'] ?? '');
    $equipe2 = trim($dados['equipe2'] ?? '');
    $status = trim($dados['status'] ?? 'agendado');

    if ($modulo <= 0 || $modalidade === '') {
        http_response_code(400);
        echo json_encode(['erro' => 'Módulo e modalidade são obrigatórios']);
        return;
    }

    try {
        $pdo = getConnection();

        if ($numero_jogo === 0) {
            $stmt = $pdo->prepare("SELECT MAX(numero_jogo) as max_num FROM partidas WHERE modulo = :mod AND modalidade = :modal");
            $stmt->execute([':mod' => $modulo, ':modal' => $modalidade]);
            $row = $stmt->fetch();
            $numero_jogo = ($row['max_num'] ?? 0) + 1;
        }

        $stmt = $pdo->prepare("INSERT INTO partidas (modulo, modalidade, fase, numero_jogo, horario, data_jogo, equipe1, equipe2, status) VALUES (:mod, :modal, :fase, :num, :hor, :data, :eq1, :eq2, :status)");
        $stmt->execute([
            ':mod' => $modulo,
            ':modal' => $modalidade,
            ':fase' => $fase,
            ':num' => $numero_jogo,
            ':hor' => $horario ?: '',
            ':data' => $data_jogo ?: null,
            ':eq1' => $equipe1,
            ':eq2' => $equipe2,
            ':status' => $status
        ]);

        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Partida criada com sucesso!',
            'id' => $pdo->lastInsertId()
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao criar partida: ' . $e->getMessage()]);
    }
}

function atualizarPartida() {
    // Verificar sessão admin
    if (!isset($_SESSION['admin_id'])) {
        http_response_code(401);
        echo json_encode(['erro' => 'Acesso não autorizado']);
        return;
    }

    $dados = json_decode(file_get_contents('php://input'), true);

    $id = intval($dados['id'] ?? 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['erro' => 'ID da partida inválido']);
        return;
    }

    try {
        $pdo = getConnection();

        // Verificar se partida existe
        $check = $pdo->prepare("SELECT id FROM partidas WHERE id = :id");
        $check->execute([':id' => $id]);
        if (!$check->fetch()) {
            http_response_code(404);
            echo json_encode(['erro' => 'Partida não encontrada']);
            return;
        }

        // Campos que podem ser atualizados
        $campos = [];
        $params = [':id' => $id];

        if (isset($dados['equipe1'])) {
            $campos[] = "equipe1 = :equipe1";
            $params[':equipe1'] = trim($dados['equipe1']);
        }
        if (isset($dados['equipe2'])) {
            $campos[] = "equipe2 = :equipe2";
            $params[':equipe2'] = trim($dados['equipe2']);
        }
        if (isset($dados['placar1'])) {
            $campos[] = "placar1 = :placar1";
            $params[':placar1'] = trim($dados['placar1']);
        }
        if (isset($dados['placar2'])) {
            $campos[] = "placar2 = :placar2";
            $params[':placar2'] = trim($dados['placar2']);
        }
        if (isset($dados['vencedor'])) {
            $campos[] = "vencedor = :vencedor";
            $params[':vencedor'] = trim($dados['vencedor']);
        }
        if (isset($dados['campeao'])) {
            $campos[] = "campeao = :campeao";
            $params[':campeao'] = trim($dados['campeao']);
        }
        if (isset($dados['status'])) {
            $campos[] = "status = :status";
            $params[':status'] = trim($dados['status']);
        }

        if (empty($campos)) {
            http_response_code(400);
            echo json_encode(['erro' => 'Nenhum campo para atualizar']);
            return;
        }

        $sql = "UPDATE partidas SET " . implode(', ', $campos) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Partida atualizada com sucesso!'
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao atualizar: ' . $e->getMessage()]);
    }
}

function deletarPartida() {
    if (!isset($_SESSION['admin_id'])) {
        http_response_code(401);
        echo json_encode(['erro' => 'Acesso não autorizado']);
        return;
    }

    $dados = json_decode(file_get_contents('php://input'), true);
    $id = intval($dados['id'] ?? 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['erro' => 'ID da partida inválido']);
        return;
    }

    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("DELETE FROM partidas WHERE id = :id");
        $stmt->execute([':id' => $id]);

        if ($stmt->rowCount() === 0) {
            http_response_code(404);
            echo json_encode(['erro' => 'Partida não encontrada']);
            return;
        }

        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Partida removida com sucesso!'
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro ao remover: ' . $e->getMessage()]);
    }
}
