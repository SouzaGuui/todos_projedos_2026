<?php
/**
 * Excluir Aluno - API Endpoint
 * Método: DELETE
 */

require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['erro' => 'Método não permitido']);
    exit;
}

$dados = json_decode(file_get_contents('php://input'), true);
$id = intval($dados['id'] ?? 0);

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['erro' => 'ID inválido']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Verificar se aluno existe
    $check = $pdo->prepare("SELECT id FROM alunos WHERE id = :id");
    $check->execute([':id' => $id]);
    if (!$check->fetch()) {
        http_response_code(404);
        echo json_encode(['erro' => 'Aluno não encontrado']);
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM alunos WHERE id = :id");
    $stmt->execute([':id' => $id]);

    echo json_encode([
        'sucesso' => true,
        'mensagem' => 'Aluno excluído com sucesso!'
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro ao excluir: ' . $e->getMessage()]);
}
