<?php
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="escalacoes-' . date('Y-m-d') . '.csv"');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

try {
    // Buscar escalações com informações das partidas
    $stmt = $pdo->query("
        SELECT e.*, p.modalidade, p.data_jogo, p.horario, 
               p.equipe1, p.equipe2, p.modulo
        FROM escalacoes e
        LEFT JOIN partidas p ON e.partida_id = p.id
        ORDER BY p.data_jogo, p.horario, e.equipe, e.tipo
    ");
    $escalacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $output = fopen('php://output', 'w');
    
    // Cabeçalho CSV
    fputcsv($output, ['ID', 'Partida ID', 'Módulo', 'Modalidade', 'Data', 'Horário', 'Equipe da Partida', 'Jogador', 'Número Camisa', 'Posição', 'Tipo (Titular/Reserva)']);
    
    // Dados das escalações
    foreach ($escalacoes as $escalacao) {
        fputcsv($output, [
            $escalacao['id'],
            $escalacao['partida_id'],
            $escalacao['modulo'] == 1 ? 'Módulo I' : 'Módulo II',
            $escalacao['modalidade'],
            $escalacao['data_jogo'],
            $escalacao['horario'],
            $escalacao['equipe1'] ?: $escalacao['equipe2'],
            $escalacao['jogador_nome'],
            $escalacao['numero_camisa'],
            $escalacao['posicao'],
            $escalacao['tipo']
        ]);
    }
    
    fclose($output);
    
} catch (Exception $e) {
    http_response_code(500);
    echo "Erro ao exportar escalações: " . $e->getMessage();
}
?>
