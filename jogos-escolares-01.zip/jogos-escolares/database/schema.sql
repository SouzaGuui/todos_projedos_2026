-- =====================================================
-- Sistema de Cadastro - Jogos Escolares Esportivos
-- Banco de Dados MySQL - Compatível com XAMPP
-- =====================================================

CREATE DATABASE IF NOT EXISTS jogos_escolares
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE jogos_escolares;

-- Tabela de administradores
CREATE TABLE IF NOT EXISTS administradores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabela de alunos
CREATE TABLE IF NOT EXISTS alunos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    idade INT NOT NULL,
    serie VARCHAR(10) NOT NULL,
    turma CHAR(1) NOT NULL,
    genero VARCHAR(10) NOT NULL,
    modalidade VARCHAR(50) NOT NULL,
    dia_jogo VARCHAR(20) NOT NULL,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabela de equipes
CREATE TABLE IF NOT EXISTS equipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    modalidade VARCHAR(50) NOT NULL,
    serie VARCHAR(10) NOT NULL,
    turma CHAR(1) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabela de relação aluno-equipe
CREATE TABLE IF NOT EXISTS aluno_equipe (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aluno_id INT NOT NULL,
    equipe_id INT NOT NULL,
    FOREIGN KEY (aluno_id) REFERENCES alunos(id) ON DELETE CASCADE,
    FOREIGN KEY (equipe_id) REFERENCES equipes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tabela de partidas do torneio
CREATE TABLE IF NOT EXISTS partidas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    modulo INT NOT NULL,
    modalidade VARCHAR(50) NOT NULL,
    fase VARCHAR(20) NOT NULL,
    numero_jogo INT NOT NULL,
    horario VARCHAR(30) NOT NULL,
    data_jogo DATE DEFAULT NULL,
    equipe1 VARCHAR(100) DEFAULT '',
    equipe2 VARCHAR(100) DEFAULT '',
    placar1 VARCHAR(10) DEFAULT '',
    placar2 VARCHAR(10) DEFAULT '',
    vencedor VARCHAR(100) DEFAULT '',
    campeao VARCHAR(100) DEFAULT '',
    status ENUM('agendado','ao_vivo','encerrado') DEFAULT 'agendado',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabela de escalações (jogadores por partida)
CREATE TABLE IF NOT EXISTS escalacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    partida_id INT NOT NULL,
    equipe VARCHAR(100) NOT NULL,
    jogador_nome VARCHAR(150) NOT NULL,
    posicao VARCHAR(50) DEFAULT '',
    tipo ENUM('titular','reserva') DEFAULT 'titular',
    numero_camisa INT DEFAULT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (partida_id) REFERENCES partidas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Inserir administrador padrão (senha: admin123)
INSERT INTO administradores (usuario, senha, nome) VALUES
('admin', '$2y$10$oJgysZcGKlIYZNoC2SiUC..A0v80F0xTollZH8ALEcooOOgHgZrJW', 'Administrador');

-- Inserir partidas pré-definidas
-- MÓDULO I - 6º x 7º Anos (Terça - 19/05)
INSERT INTO partidas (modulo, modalidade, fase, numero_jogo, horario, data_jogo) VALUES
(1, 'Vôlei Misto', 'semifinal', 1, 'Terça - 19/05 - 07h00', '2026-05-19'),
(1, 'Vôlei Misto', 'semifinal', 2, 'Terça - 19/05 - 07h30', '2026-05-19'),
(1, 'Vôlei Misto', 'final', 0, 'Terça - 19/05 - 08h00', '2026-05-19'),
(1, 'Handebol Feminino', 'semifinal', 3, 'Terça - 19/05 - 08h40', '2026-05-19'),
(1, 'Handebol Feminino', 'semifinal', 4, 'Terça - 19/05 - 09h10', '2026-05-19'),
(1, 'Handebol Feminino', 'final', 0, 'Terça - 19/05 - 09h50', '2026-05-19'),
(1, 'Handebol Masculino', 'semifinal', 5, 'Terça - 19/05 - 10h20', '2026-05-19'),
(1, 'Handebol Masculino', 'semifinal', 6, 'Terça - 19/05 - 10h50', '2026-05-19'),
(1, 'Handebol Masculino', 'final', 0, 'Terça - 19/05 - 11h30', '2026-05-19');

-- MÓDULO II - 8º x 9º Anos (Quarta - 20/05)
INSERT INTO partidas (modulo, modalidade, fase, numero_jogo, horario, data_jogo) VALUES
(2, 'Vôlei Misto', 'semifinal', 1, 'Quarta - 20/05 - 07h00', '2026-05-20'),
(2, 'Vôlei Misto', 'semifinal', 2, 'Quarta - 20/05 - 07h30', '2026-05-20'),
(2, 'Vôlei Misto', 'final', 0, 'Quarta - 20/05 - 08h00', '2026-05-20'),
(2, 'Handebol Feminino', 'semifinal', 3, 'Quarta - 20/05 - 08h40', '2026-05-20'),
(2, 'Handebol Feminino', 'semifinal', 4, 'Quarta - 20/05 - 09h10', '2026-05-20'),
(2, 'Handebol Feminino', 'final', 0, 'Quarta - 20/05 - 09h50', '2026-05-20'),
(2, 'Handebol Masculino', 'semifinal', 5, 'Quarta - 20/05 - 10h20', '2026-05-20'),
(2, 'Handebol Masculino', 'semifinal', 6, 'Quarta - 20/05 - 10h50', '2026-05-20'),
(2, 'Handebol Masculino', 'final', 0, 'Quarta - 20/05 - 11h30', '2026-05-20');
