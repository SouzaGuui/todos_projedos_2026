# Interclasse 2026 - Sistema de Jogos Escolares

Sistema moderno e responsivo para cadastro de alunos do Ensino Fundamental II (6º ao 9º ano) voltado para jogos escolares esportivos. Design inspirado no padrão SESI Esporte com tema escuro, vermelho e branco.

## Tecnologias Utilizadas

- **HTML5** - Estrutura semântica
- **CSS3** - Design responsivo, glassmorphism, variáveis CSS, gradientes
- **JavaScript** (Vanilla) - Lógica dinâmica, SPA admin, validação
- **PHP 7.4+** - Backend com PDO e prepared statements
- **MySQL** - Banco de dados relacional
- **Font Awesome 6** - Ícones esportivos
- **Google Fonts** - Inter + Bebas Neue

## Requisitos

- XAMPP (Apache + MySQL + PHP)
- PHP 7.4 ou superior
- MySQL 5.7 ou superior
- Navegador moderno

## Instalação no XAMPP

### 1. Copiar o Projeto

Copie a pasta `jogos-escolares` para o diretório do XAMPP:

```
C:\xampp\htdocs\jogos-escolares\
```

### 2. Criar o Banco de Dados

1. Inicie o Apache e MySQL no painel do XAMPP
2. Acesse `http://localhost/phpmyadmin`
3. Importe o arquivo `database/schema.sql` ou execute o SQL manualmente
4. O banco `jogos_escolares` será criado automaticamente

### 3. Configurar Conexão

O arquivo `config/database.php` já está configurado para o XAMPP padrão:
- Host: `localhost`
- Usuário: `root`
- Senha: `` (vazio)
- Banco: `jogos_escolares`

### 4. Acessar o Sistema

- **Site Público**: `http://localhost/jogos-escolares/`
- **Painel Admin**: `http://localhost/jogos-escolares/admin/`

## Estrutura de Pastas

```
jogos-escolares/
├── index.php                   # Site público (inscrição + apresentação)
├── .htaccess                   # Configurações Apache + segurança
├── assets/
│   ├── css/
│   │   └── style.css          # Estilos do site público
│   └── js/
│       └── main.js            # JavaScript do site público
├── admin/
│   ├── index.php              # Painel administrativo (login + dashboard)
│   └── assets/
│       ├── css/
│       │   └── admin.css      # Estilos do painel admin
│       └── js/
│           └── admin.js       # JavaScript do painel admin
├── backend/
│   ├── cadastrar.php          # API: Cadastrar aluno
│   ├── listar.php             # API: Listar alunos
│   ├── editar.php             # API: Editar aluno
│   ├── excluir.php            # API: Excluir aluno
│   ├── login.php              # API: Login admin
│   ├── logout.php             # API: Logout
│   ├── dashboard.php          # API: Estatísticas
│   ├── exportar.php           # API: Exportar CSV
│   └── equipes.php            # API: Gerenciar equipes
├── config/
│   └── database.php           # Conexão com MySQL
├── database/
│   └── schema.sql             # Script de criação do banco
└── README.md                  # Documentação
```

## Funcionalidades

### Cadastro de Alunos
- Formulário completo com validação
- Lógica dinâmica de modalidade por gênero
- Cálculo automático do dia dos jogos por série
- Mensagens de sucesso/erro

### Lógica de Modalidades
- **Masculino**: Handebol Masculino, Vôlei Misto
- **Feminino**: Handebol Feminino, Vôlei Misto

### Dia dos Jogos
- **8º e 9º Ano**: 19/05/2026
- **6º e 7º Ano**: 20/05/2026

### Listagem de Alunos
- Tabela com todos os dados
- Filtro por série, modalidade, gênero
- Busca por nome
- Editar e excluir alunos
- Exportar para CSV/Excel
- Contador de alunos

### Dashboard Administrativo
- Total de alunos inscritos
- Contadores por modalidade
- Gráficos interativos (Chart.js)
- Estatísticas por série, gênero e dia

### Extras
- Login administrativo (admin / admin123)
- Sistema de equipes
- QR Code do participante
- Design responsivo (mobile e desktop)
- Animações suaves
- Ícones esportivos
- Exportação CSV

## Banco de Dados

### Tabela `alunos`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | INT (PK) | ID auto-incremento |
| nome | VARCHAR(150) | Nome completo |
| idade | INT | Idade do aluno |
| serie | VARCHAR(10) | 6º ao 9º Ano |
| turma | CHAR(1) | A ou B |
| genero | VARCHAR(10) | Masculino/Feminino |
| modalidade | VARCHAR(50) | Modalidade esportiva |
| dia_jogo | VARCHAR(20) | Data do jogo |
| data_cadastro | TIMESTAMP | Data/hora do cadastro |

### Tabela `administradores`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | INT (PK) | ID auto-incremento |
| usuario | VARCHAR(50) | Nome de usuário |
| senha | VARCHAR(255) | Senha (bcrypt) |
| nome | VARCHAR(100) | Nome do admin |

### Tabela `equipes`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | INT (PK) | ID auto-incremento |
| nome | VARCHAR(100) | Nome da equipe |
| modalidade | VARCHAR(50) | Modalidade |
| serie | VARCHAR(10) | Série |
| turma | CHAR(1) | Turma |

## Login Administrativo

- **Usuário**: admin
- **Senha**: admin123

## API Endpoints

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/backend/cadastrar.php` | Cadastrar aluno |
| GET | `/backend/listar.php` | Listar alunos |
| PUT | `/backend/editar.php` | Editar aluno |
| DELETE | `/backend/excluir.php` | Excluir aluno |
| POST | `/backend/login.php` | Login admin |
| GET | `/backend/dashboard.php` | Estatísticas |
| GET | `/backend/exportar.php` | Exportar CSV |
| GET/POST/DELETE | `/backend/equipes.php` | Gerenciar equipes |

## Licença

Projeto desenvolvido para fins educacionais - Jogos Escolares Esportivos.
