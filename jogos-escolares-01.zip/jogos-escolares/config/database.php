<?php
/**
 * Configuração de Conexão com Banco de Dados MySQL
 * Compatível com XAMPP
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'jogos_escolares');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

function getConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]);
        return $pdo;
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['erro' => 'Erro na conexão: ' . $e->getMessage()]);
        exit;
    }
}

session_start();

header('Content-Type: application/json; charset=utf-8');
