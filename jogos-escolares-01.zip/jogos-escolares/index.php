<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interclasse 2026 - Jogos Escolares</title>
    <link rel="icon" type="image/png" href="assets/img/sesi-logo.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Bebas+Neue&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container navbar-content">
            <div class="navbar-brand">
                <img src="assets/img/sesi-logo.png" alt="SESI Esporte" class="brand-logo">
                <span class="brand-text">INTERCLASSE <strong>2026</strong></span>
            </div>
            <div class="navbar-links" id="navLinks">
                <a href="#inicio">Início</a>
                <a href="#sobre">Sobre</a>
                <a href="#tabela">Tabela</a>
                <a href="#classificacao">Classificação</a>
                <a href="#inscricao">Inscrição</a>
                <a href="#modalidades">Modalidades</a>
                <a href="#" onclick="abrirRegulamento(); return false;" class="btn-regulamento-link">
                    <i class="fas fa-file-alt"></i> Regulamento
                </a>
                <a href="admin/index.php" class="btn-admin-link">
                    <i class="fas fa-lock"></i> Painel Admin
                </a>
            </div>
            <button class="navbar-toggle" id="navToggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>

    <!-- Hero Carousel -->
    <section class="hero-carousel" id="inicio">
        <div class="carousel-container">
            <div class="carousel-slide active" style="background: linear-gradient(135deg, rgba(30,0,0,0.85), rgba(80,0,0,0.7)), url('https://images.unsplash.com/photo-1461896836934-bd45ba8fcb98?w=1600') center/cover;">
                <div class="container hero-content">
                    <div class="hero-badge"><i class="fas fa-fire"></i> EVENTO ESPORTIVO OFICIAL</div>
                    <h1 class="hero-title">INTERCLASSE <span>2026</span></h1>
                    <p class="hero-subtitle">Sistema oficial dos jogos escolares</p>
                    <p class="hero-desc">Ensino Fundamental II - 6º ao 9º Ano</p>
                    <div class="countdown-container">
                        <h3 class="countdown-title"><i class="fas fa-clock"></i> Contagem Regressiva para os Jogos</h3>
                        <div class="countdown" id="countdown">
                            <div class="countdown-item">
                                <span class="countdown-number" id="dias">00</span>
                                <span class="countdown-label">Dias</span>
                            </div>
                            <div class="countdown-item">
                                <span class="countdown-number" id="horas">00</span>
                                <span class="countdown-label">Horas</span>
                            </div>
                            <div class="countdown-item">
                                <span class="countdown-number" id="minutos">00</span>
                                <span class="countdown-label">Minutos</span>
                            </div>
                            <div class="countdown-item">
                                <span class="countdown-number" id="segundos">00</span>
                                <span class="countdown-label">Segundos</span>
                            </div>
                        </div>
                    </div>
                    <a href="#inscricao" class="btn-hero">
                        <i class="fas fa-pen-to-square"></i> Inscreva-se Agora
                    </a>
                </div>
            </div>
            <div class="carousel-slide" style="background: linear-gradient(135deg, rgba(30,0,0,0.85), rgba(80,0,0,0.7)), url('https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=1600') center/cover;">
                <div class="container hero-content">
                    <div class="hero-badge"><i class="fas fa-volleyball"></i> VÔLEI MISTO</div>
                    <h1 class="hero-title">VÔLEI <span>MISTO</span></h1>
                    <p class="hero-subtitle">Aberto para todos os gêneros</p>
                    <p class="hero-desc">Representantes de cada turma competindo pela vitória!</p>
                    <a href="#inscricao" class="btn-hero">
                        <i class="fas fa-pen-to-square"></i> Inscreva-se Agora
                    </a>
                </div>
            </div>
            <div class="carousel-slide" style="background: linear-gradient(135deg, rgba(30,0,0,0.85), rgba(80,0,0,0.7)), url('https://images.unsplash.com/photo-1515523110800-9415d13b84a8?w=1600') center/cover;">
                <div class="container hero-content">
                    <div class="hero-badge"><i class="fas fa-hand-back-fist"></i> HANDEBOL</div>
                    <h1 class="hero-title">HANDEBOL <span>ESCOLAR</span></h1>
                    <p class="hero-subtitle">Masculino e Feminino</p>
                    <p class="hero-desc">Garra, trabalho em equipe e espírito esportivo!</p>
                    <a href="#inscricao" class="btn-hero">
                        <i class="fas fa-pen-to-square"></i> Inscreva-se Agora
                    </a>
                </div>
            </div>
            <button class="carousel-btn prev" id="carouselPrev"><i class="fas fa-chevron-left"></i></button>
            <button class="carousel-btn next" id="carouselNext"><i class="fas fa-chevron-right"></i></button>
            <div class="carousel-dots" id="carouselDots">
                <span class="dot active" data-slide="0"></span>
                <span class="dot" data-slide="1"></span>
                <span class="dot" data-slide="2"></span>
            </div>
        </div>
    </section>

    <!-- Sobre o Evento -->
    <section class="sobre" id="sobre">
        <div class="container">
            <div class="section-title">
                <h2><img src="assets/img/sesi-logo.png" alt="SESI" class="section-logo"> Sobre o Evento</h2>
                <p>Conheça os Jogos Escolares Interclasse 2026</p>
            </div>
            <div class="sobre-grid">
                <div class="sobre-card">
                    <div class="sobre-icon"><i class="fas fa-calendar-days"></i></div>
                    <h3>Datas dos Jogos</h3>
                    <p><strong>8º e 9º Ano:</strong> 19/05/2026</p>
                    <p><strong>6º e 7º Ano:</strong> 20/05/2026</p>
                </div>
                <div class="sobre-card">
                    <div class="sobre-icon"><i class="fas fa-users"></i></div>
                    <h3>Quem Pode Participar</h3>
                    <p>Alunos do Ensino Fundamental II</p>
                    <p>6º ao 9º Ano - Turmas A e B</p>
                </div>
                <div class="sobre-card">
                    <div class="sobre-icon"><i class="fas fa-trophy"></i></div>
                    <h3>Modalidades</h3>
                    <p>Handebol Masculino</p>
                    <p>Handebol Feminino</p>
                    <p>Vôlei Misto</p>
                </div>
                <div class="sobre-card">
                    <div class="sobre-icon"><i class="fas fa-shield-halved"></i></div>
                    <h3>Organização</h3>
                    <p>Competição organizada por turmas</p>
                    <p>Fair Play e espírito esportivo</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Modalidades -->
    <section class="modalidades" id="modalidades">
        <div class="container">
            <div class="section-title">
                <h2><img src="assets/img/sesi-logo.png" alt="SESI" class="section-logo"> Modalidades Esportivas</h2>
                <p>Escolha sua modalidade e represente sua turma!</p>
            </div>
            <div class="modalidades-grid">
                <div class="modalidade-card" onclick="abrirModalEsporte('handebol-masc')" style="cursor:pointer;">
                    <div class="modalidade-icon"><i class="fas fa-hand-back-fist"></i></div>
                    <h3>Handebol Masculino</h3>
                    <p>Para alunos do gênero masculino</p>
                    <span class="modalidade-badge">Masculino</span>
                    <span class="card-hint"><i class="fas fa-info-circle"></i> Clique para saber mais</span>
                </div>
                <div class="modalidade-card" onclick="abrirModalEsporte('handebol-fem')" style="cursor:pointer;">
                    <div class="modalidade-icon"><i class="fas fa-hand-back-fist"></i></div>
                    <h3>Handebol Feminino</h3>
                    <p>Para alunas do gênero feminino</p>
                    <span class="modalidade-badge fem">Feminino</span>
                    <span class="card-hint"><i class="fas fa-info-circle"></i> Clique para saber mais</span>
                </div>
                <div class="modalidade-card" onclick="abrirModalEsporte('volei')" style="cursor:pointer;">
                    <div class="modalidade-icon"><i class="fas fa-volleyball"></i></div>
                    <h3>Vôlei Misto</h3>
                    <p>Aberto para todos os gêneros</p>
                    <span class="modalidade-badge misto">Misto</span>
                    <span class="card-hint"><i class="fas fa-info-circle"></i> Clique para saber mais</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Modal Esporte -->
    <div class="modal-overlay" id="modalEsporte">
        <div class="modal-esporte">
            <button class="modal-close" onclick="fecharModalEsporte()"><i class="fas fa-times"></i></button>
            <div class="modal-esporte-header" id="modalEsporteHeader">
                <div class="modal-esporte-icon" id="modalEsporteIcon"></div>
                <h2 id="modalEsporteTitulo"></h2>
            </div>
            <div class="modal-esporte-body">
                <div class="modal-esporte-section">
                    <h3><i class="fas fa-book"></i> História</h3>
                    <p id="modalEsporteHistoria"></p>
                </div>
                <div class="modal-esporte-section">
                    <h3><i class="fas fa-list-check"></i> Regras Principais</h3>
                    <ul id="modalEsporteRegras"></ul>
                </div>
                <div class="modal-esporte-section">
                    <h3><i class="fas fa-school"></i> No Interclasse 2026</h3>
                    <p id="modalEsporteInterclasse"></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabela dos Jogos -->
    <section class="tabela-jogos" id="tabela">
        <div class="container">
            <div class="section-title">
                <h2><img src="assets/img/sesi-logo.png" alt="SESI" class="section-logo"> Tabela dos Jogos</h2>
                <p>Acompanhe o chaveamento e resultados do Torneio Interclasses 2026</p>
            </div>

            <!-- Tabs Módulos -->
            <div class="tabela-tabs">
                <button class="tab-btn active" data-modulo="1">
                    <i class="fas fa-star"></i> Módulo I - 6º x 7º Anos
                </button>
                <button class="tab-btn" data-modulo="2">
                    <i class="fas fa-star"></i> Módulo II - 8º x 9º Anos
                </button>
            </div>

            <!-- Conteúdo Módulo 1 -->
            <div class="tabela-modulo active" id="modulo1">
                <div class="bracket-section">
                    <div class="bracket-header modulo1">
                        <h3>TORNEIO INTERCLASSES 2026 - 1ª ETAPA</h3>
                        <h4>MÓDULO I - 6º X 7º ANOS - VÔLEI MISTO</h4>
                    </div>
                    <div class="bracket-content">
                        <div class="bracket-fase semifinal">
                            <h5>SEMIFINAL</h5>
                            <div class="bracket-jogo" data-id="m1-volei-semi1">
                                <div class="jogo-label">Jogo 1</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Terça - 19/05 - 07h00</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m1-v-s1-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m1-v-s1-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m1-v-s1-p1">-</span>
                                        <span>x</span>
                                        <span id="m1-v-s1-p2">-</span>
                                    </div>
                                </div>
                            </div>
                            <div class="bracket-jogo" data-id="m1-volei-semi2">
                                <div class="jogo-label">Jogo 2</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Terça - 19/05 - 07h30</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m1-v-s2-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m1-v-s2-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m1-v-s2-p1">-</span>
                                        <span>x</span>
                                        <span id="m1-v-s2-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase final">
                            <h5>FINAL</h5>
                            <div class="bracket-jogo final-jogo">
                                <div class="jogo-info">
                                    <span class="jogo-horario">Terça - 19/05 - 08h00</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m1-v-f-eq1">Vencedor Jogo 1</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m1-v-f-eq2">Vencedor Jogo 2</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m1-v-f-p1">-</span>
                                        <span>x</span>
                                        <span id="m1-v-f-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase campeao">
                            <h5>CAMPEÃO</h5>
                            <div class="campeao-box">
                                <i class="fas fa-trophy"></i>
                                <span id="m1-v-campeao">-</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bracket-section">
                    <div class="bracket-header modulo1">
                        <h3>TORNEIO INTERCLASSES 2026 - 1ª ETAPA</h3>
                        <h4>MÓDULO I - 6º X 7º ANOS - HANDEBOL FEMININO</h4>
                    </div>
                    <div class="bracket-content">
                        <div class="bracket-fase semifinal">
                            <h5>SEMIFINAL</h5>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 3</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Terça - 19/05 - 08h40</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m1-hf-s1-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m1-hf-s1-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m1-hf-s1-p1">-</span>
                                        <span>x</span>
                                        <span id="m1-hf-s1-p2">-</span>
                                    </div>
                                </div>
                            </div>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 4</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Terça - 19/05 - 09h10</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m1-hf-s2-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m1-hf-s2-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m1-hf-s2-p1">-</span>
                                        <span>x</span>
                                        <span id="m1-hf-s2-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase final">
                            <h5>FINAL</h5>
                            <div class="bracket-jogo final-jogo">
                                <div class="jogo-info">
                                    <span class="jogo-horario">Terça - 19/05 - 09h50</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m1-hf-f-eq1">Vencedor Jogo 3</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m1-hf-f-eq2">Vencedor Jogo 4</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m1-hf-f-p1">-</span>
                                        <span>x</span>
                                        <span id="m1-hf-f-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase campeao">
                            <h5>CAMPEÃO</h5>
                            <div class="campeao-box">
                                <i class="fas fa-trophy"></i>
                                <span id="m1-hf-campeao">-</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bracket-section">
                    <div class="bracket-header modulo1">
                        <h3>TORNEIO INTERCLASSES 2026 - 1ª ETAPA</h3>
                        <h4>MÓDULO I - 6º X 7º ANOS - HANDEBOL MASCULINO</h4>
                    </div>
                    <div class="bracket-content">
                        <div class="bracket-fase semifinal">
                            <h5>SEMIFINAL</h5>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 5</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Terça - 19/05 - 10h20</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m1-hm-s1-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m1-hm-s1-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m1-hm-s1-p1">-</span>
                                        <span>x</span>
                                        <span id="m1-hm-s1-p2">-</span>
                                    </div>
                                </div>
                            </div>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 6</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Terça - 19/05 - 10h50</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m1-hm-s2-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m1-hm-s2-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m1-hm-s2-p1">-</span>
                                        <span>x</span>
                                        <span id="m1-hm-s2-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase final">
                            <h5>FINAL</h5>
                            <div class="bracket-jogo final-jogo">
                                <div class="jogo-info">
                                    <span class="jogo-horario">Terça - 19/05 - 11h30</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m1-hm-f-eq1">Vencedor Jogo 5</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m1-hm-f-eq2">Vencedor Jogo 6</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m1-hm-f-p1">-</span>
                                        <span>x</span>
                                        <span id="m1-hm-f-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase campeao">
                            <h5>CAMPEÃO</h5>
                            <div class="campeao-box">
                                <i class="fas fa-trophy"></i>
                                <span id="m1-hm-campeao">-</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Conteúdo Módulo 2 -->
            <div class="tabela-modulo" id="modulo2">
                <div class="bracket-section">
                    <div class="bracket-header modulo2">
                        <h3>TORNEIO INTERCLASSES 2026 - 1ª ETAPA</h3>
                        <h4>MÓDULO II - 8º X 9º ANOS - VÔLEI MISTO</h4>
                    </div>
                    <div class="bracket-content">
                        <div class="bracket-fase semifinal">
                            <h5>SEMIFINAL</h5>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 1</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Quarta - 20/05 - 07h00</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m2-v-s1-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m2-v-s1-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m2-v-s1-p1">-</span>
                                        <span>x</span>
                                        <span id="m2-v-s1-p2">-</span>
                                    </div>
                                </div>
                            </div>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 2</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Quarta - 20/05 - 07h30</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m2-v-s2-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m2-v-s2-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m2-v-s2-p1">-</span>
                                        <span>x</span>
                                        <span id="m2-v-s2-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase final">
                            <h5>FINAL</h5>
                            <div class="bracket-jogo final-jogo">
                                <div class="jogo-info">
                                    <span class="jogo-horario">Quarta - 20/05 - 08h00</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m2-v-f-eq1">Vencedor Jogo 1</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m2-v-f-eq2">Vencedor Jogo 2</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m2-v-f-p1">-</span>
                                        <span>x</span>
                                        <span id="m2-v-f-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase campeao">
                            <h5>CAMPEÃO</h5>
                            <div class="campeao-box">
                                <i class="fas fa-trophy"></i>
                                <span id="m2-v-campeao">-</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bracket-section">
                    <div class="bracket-header modulo2">
                        <h3>TORNEIO INTERCLASSES 2026 - 1ª ETAPA</h3>
                        <h4>MÓDULO II - 8º X 9º ANOS - HANDEBOL FEMININO</h4>
                    </div>
                    <div class="bracket-content">
                        <div class="bracket-fase semifinal">
                            <h5>SEMIFINAL</h5>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 3</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Quarta - 20/05 - 08h40</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m2-hf-s1-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m2-hf-s1-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m2-hf-s1-p1">-</span>
                                        <span>x</span>
                                        <span id="m2-hf-s1-p2">-</span>
                                    </div>
                                </div>
                            </div>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 4</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Quarta - 20/05 - 09h10</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m2-hf-s2-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m2-hf-s2-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m2-hf-s2-p1">-</span>
                                        <span>x</span>
                                        <span id="m2-hf-s2-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase final">
                            <h5>FINAL</h5>
                            <div class="bracket-jogo final-jogo">
                                <div class="jogo-info">
                                    <span class="jogo-horario">Quarta - 20/05 - 09h50</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m2-hf-f-eq1">Vencedor Jogo 3</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m2-hf-f-eq2">Vencedor Jogo 4</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m2-hf-f-p1">-</span>
                                        <span>x</span>
                                        <span id="m2-hf-f-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase campeao">
                            <h5>CAMPEÃO</h5>
                            <div class="campeao-box">
                                <i class="fas fa-trophy"></i>
                                <span id="m2-hf-campeao">-</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bracket-section">
                    <div class="bracket-header modulo2">
                        <h3>TORNEIO INTERCLASSES 2026 - 1ª ETAPA</h3>
                        <h4>MÓDULO II - 8º X 9º ANOS - HANDEBOL MASCULINO</h4>
                    </div>
                    <div class="bracket-content">
                        <div class="bracket-fase semifinal">
                            <h5>SEMIFINAL</h5>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 5</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Quarta - 20/05 - 10h20</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m2-hm-s1-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m2-hm-s1-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m2-hm-s1-p1">-</span>
                                        <span>x</span>
                                        <span id="m2-hm-s1-p2">-</span>
                                    </div>
                                </div>
                            </div>
                            <div class="bracket-jogo">
                                <div class="jogo-label">Jogo 6</div>
                                <div class="jogo-info">
                                    <span class="jogo-horario">Quarta - 20/05 - 10h50</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m2-hm-s2-eq1">-</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m2-hm-s2-eq2">-</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m2-hm-s2-p1">-</span>
                                        <span>x</span>
                                        <span id="m2-hm-s2-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase final">
                            <h5>FINAL</h5>
                            <div class="bracket-jogo final-jogo">
                                <div class="jogo-info">
                                    <span class="jogo-horario">Quarta - 20/05 - 11h30</span>
                                    <div class="jogo-equipes">
                                        <span class="equipe" id="m2-hm-f-eq1">Vencedor Jogo 5</span>
                                        <span class="vs">X</span>
                                        <span class="equipe" id="m2-hm-f-eq2">Vencedor Jogo 6</span>
                                    </div>
                                    <div class="jogo-placar">
                                        <span id="m2-hm-f-p1">-</span>
                                        <span>x</span>
                                        <span id="m2-hm-f-p2">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bracket-fase campeao">
                            <h5>CAMPEÃO</h5>
                            <div class="campeao-box">
                                <i class="fas fa-trophy"></i>
                                <span id="m2-hm-campeao">-</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Classificação -->
    <section class="classificacao-section" id="classificacao">
        <div class="container">
            <div class="section-title">
                <h2><img src="assets/img/sesi-logo.png" alt="SESI" class="section-logo"> Classificação</h2>
                <p>Acompanhe a classificação das equipes por modalidade</p>
            </div>
            <div class="classificacao-layout">
                <div class="classificacao-main" id="classificacaoMain">
                    <div class="classificacao-loading">
                        <i class="fas fa-spinner fa-spin"></i> Carregando classificação...
                    </div>
                </div>
                <div class="classificacao-sidebar">
                    <div class="proximas-card">
                        <h3 class="proximas-title"><i class="fas fa-calendar-alt"></i> Próximas Partidas</h3>
                        <div id="proximasPartidasList">
                            <div class="classificacao-loading">
                                <i class="fas fa-spinner fa-spin"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Formulário de Inscrição -->
    <section class="inscricao" id="inscricao">
        <div class="container">
            <div class="section-title">
                <h2><img src="assets/img/sesi-logo.png" alt="SESI" class="section-logo"> Inscrição do Aluno</h2>
                <p>Preencha o formulário abaixo para se inscrever nos Jogos Escolares</p>
            </div>

            <div class="form-card">
                <form id="formCadastro" class="form-grid">
                    <input type="hidden" id="alunoId" value="">
                    
                    <div class="form-group full-width">
                        <label for="nome">
                            <i class="fas fa-user"></i> Nome Completo do Aluno
                        </label>
                        <input type="text" id="nome" name="nome" placeholder="Digite o nome completo do aluno" required minlength="3">
                        <span class="error-msg" id="erroNome"></span>
                    </div>

                    <div class="form-group full-width">
                        <label for="email">
                            <i class="fas fa-envelope"></i> E-mail Educacional SESI
                        </label>
                        <input type="email" id="email" name="email" placeholder="seu.nome@sesi.org.br" required>
                        <span class="error-msg" id="erroEmail"></span>
                    </div>

                    <div class="form-group">
                        <label for="idade">
                            <i class="fas fa-calendar"></i> Idade
                        </label>
                        <input type="number" id="idade" name="idade" placeholder="Ex: 12" min="9" max="18" required>
                        <span class="error-msg" id="erroIdade"></span>
                    </div>

                    <div class="form-group">
                        <label for="serie">
                            <i class="fas fa-graduation-cap"></i> Série
                        </label>
                        <select id="serie" name="serie" required>
                            <option value="">Selecione a série</option>
                            <option value="6º Ano">6º Ano</option>
                            <option value="7º Ano">7º Ano</option>
                            <option value="8º Ano">8º Ano</option>
                            <option value="9º Ano">9º Ano</option>
                        </select>
                        <span class="error-msg" id="erroSerie"></span>
                    </div>

                    <div class="form-group">
                        <label for="turma">
                            <i class="fas fa-door-open"></i> Sala/Turma
                        </label>
                        <select id="turma" name="turma" required>
                            <option value="">Selecione a turma</option>
                            <option value="A">Turma A</option>
                            <option value="B">Turma B</option>
                        </select>
                        <span class="error-msg" id="erroTurma"></span>
                    </div>

                    <div class="form-group">
                        <label for="genero">
                            <i class="fas fa-venus-mars"></i> Gênero
                        </label>
                        <select id="genero" name="genero" required>
                            <option value="">Selecione o gênero</option>
                            <option value="Masculino">Masculino</option>
                            <option value="Feminino">Feminino</option>
                        </select>
                        <span class="error-msg" id="erroGenero"></span>
                    </div>

                    <div class="form-group">
                        <label for="modalidade">
                            <i class="fas fa-futbol"></i> Modalidade Esportiva
                        </label>
                        <select id="modalidade" name="modalidade" required disabled>
                            <option value="">Selecione o gênero primeiro</option>
                        </select>
                        <span class="error-msg" id="erroModalidade"></span>
                    </div>

                    <!-- Informação do Dia dos Jogos -->
                    <div class="form-group full-width">
                        <div class="info-box" id="infoJogos" style="display: none;">
                            <i class="fas fa-calendar-check"></i>
                            <span id="diaJogosTexto"></span>
                        </div>
                    </div>

                    <div class="form-group full-width form-actions">
                        <button type="submit" class="btn btn-primary" id="btnCadastrar">
                            <i class="fas fa-paper-plane"></i> Realizar Inscrição
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <img src="assets/img/sesi-logo.png" alt="SESI" class="footer-logo">
                    <span>Interclasse 2026</span>
                </div>
                <p>Jogos Escolares Esportivos - Ensino Fundamental II</p>
                <p class="footer-copy">&copy; 2026 - Desenvolvido por Guilherme de Souza e Erick</p>
            </div>
        </div>
    </footer>

    <!-- Modal Escalação -->
    <div class="modal-overlay" id="modalEscalacao">
        <div class="modal-escalacao">
            <button class="modal-close" onclick="fecharModalEscalacao()"><i class="fas fa-times"></i></button>
            <div class="escalacao-header">
                <h2><i class="fas fa-clipboard-list" style="color: var(--primary);"></i> ESCALAÇÃO</h2>
                <p id="escalacaoSubtitulo"></p>
            </div>
            <div class="escalacao-body" id="escalacaoBody">
                <div class="escalacao-empty">
                    <i class="fas fa-spinner fa-spin"></i><br>Carregando escalação...
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Regulamento -->
    <div class="modal-overlay" id="modalRegulamento" onclick="fecharRegulamento(event)">
        <div class="modal-regulamento-container" onclick="event.stopPropagation()">
            <div class="modal-reg-header">
                <div>
                    <h2><i class="fas fa-file-alt" style="color: var(--gold);"></i> REGULAMENTO</h2>
                    <p>Documentos oficiais dos Jogos Escolares Interclasse 2026</p>
                </div>
                <button class="modal-reg-close" onclick="fecharRegulamento()"><i class="fas fa-times"></i></button>
            </div>

            <!-- Cards iniciais -->
            <div id="regCards" class="reg-cards-grid">
                <div class="reg-card" onclick="abrirDocRegulamento('condutas')">
                    <div class="reg-card-icon" style="background: rgba(220,38,38,0.15); color: #fca5a5;">
                        <i class="fas fa-shield-halved"></i>
                    </div>
                    <h3>Condutas do Esporte</h3>
                    <p>Normas de conduta para professores, juízes e alunos durante as atividades esportivas e competições.</p>
                    <span class="reg-card-tag"><i class="fas fa-file-pdf"></i> PDF</span>
                </div>
                <div class="reg-card" onclick="abrirDocRegulamento('protagonismo')">
                    <div class="reg-card-icon" style="background: rgba(59,130,246,0.15); color: #93c5fd;">
                        <i class="fas fa-star"></i>
                    </div>
                    <h3>Protagonismo Estudantil</h3>
                    <p>Regimento interno para estudantes: normas, deveres e direitos durante a participação nas atividades.</p>
                    <span class="reg-card-tag"><i class="fas fa-image"></i> Imagem</span>
                </div>
                <div class="reg-card" onclick="abrirDocRegulamento('jogos')">
                    <div class="reg-card-icon" style="background: rgba(245,158,11,0.15); color: #fcd34d;">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <h3>Jogos Interclasse</h3>
                    <p>Regulamento oficial do torneio: modalidades, regras, cronograma e comissão organizadora 2026.</p>
                    <span class="reg-card-tag"><i class="fas fa-file-pdf"></i> PDF</span>
                </div>
            </div>

            <!-- Detalhe do documento -->
            <div id="regDetalhe" style="display:none;">
                <button class="reg-back-btn" onclick="voltarRegCards()"><i class="fas fa-arrow-left"></i> Voltar</button>
                <div id="regDetalheContent"></div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- Scripts -->
    <script src="assets/js/main.js"></script>
</body>
</html>
