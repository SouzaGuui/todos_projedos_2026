<?php
/**
 * Aplicacao de previsao do tempo com HG Brasil API.
 * Arquivo unico: index.php
 * Requisitos: PHP + HTML5 + Bootstrap 5, GET, urlencode, cards e forecast.
 */

// Configuracao da API (substitua pela sua chave real quando necessario).
$apiKey = "0809673c";

// Captura da cidade por GET com sanitizacao basica.
$cidade = isset($_GET["cidade"]) ? trim($_GET["cidade"]) : "";

// Variaveis de controle para exibicao.
$dadosClima = null;
$erro = "";

/**
 * Mapeia condicao textual para icone Bootstrap Icons.
 */
function obterIconeClima(string $descricao): string
{
    $texto = mb_strtolower($descricao, "UTF-8");

    if (str_contains($texto, "chuva") || str_contains($texto, "tempest")) {
        return "bi-cloud-rain-heavy-fill";
    }
    if (str_contains($texto, "nublado") || str_contains($texto, "nuvem")) {
        return "bi-clouds-fill";
    }
    if (str_contains($texto, "nebl") || str_contains($texto, "nevo")) {
        return "bi-cloud-fog2-fill";
    }
    if (str_contains($texto, "limpo") || str_contains($texto, "sol") || str_contains($texto, "ensolarado")) {
        return "bi-brightness-high-fill";
    }

    return "bi-cloud-sun-fill";
}

if ($cidade !== "") {
    // Uso obrigatorio de urlencode para tratar nomes com espacos e acentos.
    $cidadeCodificada = urlencode($cidade);
    $url = "https://api.hgbrasil.com/weather?key={$apiKey}&city_name={$cidadeCodificada}";

    // Requisicao HTTP simples.
    $resposta = @file_get_contents($url);

    if ($resposta === false) {
        $erro = "Nao foi possivel consultar a API no momento. Tente novamente em instantes.";
    } else {
        $json = json_decode($resposta, true);

        if (!is_array($json) || !isset($json["results"])) {
            $erro = "Resposta invalida da API.";
        } else {
            $dadosClima = $json["results"];
        }
    }
}

// Dados padrao para evitar warnings e facilitar a view.
$nomeCidade = $dadosClima["city"] ?? $cidade;
$temperatura = (int)($dadosClima["temp"] ?? 0);
$umidade = (int)($dadosClima["humidity"] ?? 0);
$vento = (string)($dadosClima["wind_speedy"] ?? "-- km/h");
$descricao = (string)($dadosClima["description"] ?? "Sem dados");
$forecast = is_array($dadosClima["forecast"] ?? null) ? $dadosClima["forecast"] : [];

// Regra de cor dinamica por temperatura.
$classeTemperatura = $temperatura > 30 ? "bg-danger" : "bg-info";
$iconeClimaAtual = obterIconeClima($descricao);
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Clima Brasil - HG API</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        body {
            font-family: "Poppins", sans-serif;
            background: linear-gradient(135deg, #f5f7fa, #e4ebf5);
            min-height: 100vh;
        }
        .card-soft {
            border: 0;
            border-radius: 1rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
        }
        .icon-lg {
            font-size: 2rem;
        }
        .forecast-card {
            min-width: 220px;
        }
    </style>
</head>
<body>
<main class="container py-4 py-md-5">
    <div class="row justify-content-center">
        <div class="col-12 col-lg-10">
            <div class="text-center mb-4">
                <h1 class="fw-bold mb-1"><i class="bi bi-cloud-sun-fill text-primary"></i> Clima Brasil</h1>
                <p class="text-muted mb-0">Consulte o tempo em tempo real para qualquer cidade do Brasil</p>
            </div>

            <!-- Formulario de busca via GET -->
            <div class="card card-soft mb-4">
                <div class="card-body p-4">
                    <form method="GET" action="" class="row g-3 align-items-end">
                        <div class="col-12 col-md-9">
                            <label for="cidade" class="form-label fw-semibold">Cidade</label>
                            <input
                                type="text"
                                class="form-control form-control-lg"
                                id="cidade"
                                name="cidade"
                                placeholder="Ex.: Sao Paulo, Rio de Janeiro, Recife"
                                value="<?php echo htmlspecialchars($cidade); ?>"
                                required
                            >
                        </div>
                        <div class="col-12 col-md-3 d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="bi bi-search"></i> Buscar clima
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <?php if ($erro !== ""): ?>
                <div class="alert alert-danger card-soft" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?php echo htmlspecialchars($erro); ?>
                </div>
            <?php endif; ?>

            <?php if ($dadosClima !== null && $erro === ""): ?>
                <!-- Bloco principal com dados atuais -->
                <div class="card card-soft mb-4">
                    <div class="card-body p-4">
                        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                            <div>
                                <h2 class="h4 fw-bold mb-1"><?php echo htmlspecialchars($nomeCidade); ?></h2>
                                <p class="text-muted mb-0">Clima atualizado agora</p>
                            </div>
                            <div class="text-md-end">
                                <div class="display-6 fw-bold mb-0"><?php echo $temperatura; ?>°C</div>
                                <span class="badge text-bg-light border">
                                    <i class="bi <?php echo $iconeClimaAtual; ?> me-1"></i>
                                    <?php echo htmlspecialchars($descricao); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Dashboard com 4 cards -->
                <div class="row g-3 mb-4">
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="card card-soft h-100 text-white <?php echo $classeTemperatura; ?>">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3 class="h6 mb-0">Temperatura</h3>
                                    <i class="bi bi-thermometer-half icon-lg"></i>
                                </div>
                                <p class="display-6 fw-bold mt-3 mb-0"><?php echo $temperatura; ?>°C</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="card card-soft h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3 class="h6 mb-0">Umidade</h3>
                                    <i class="bi bi-droplet-half text-primary icon-lg"></i>
                                </div>
                                <p class="display-6 fw-bold mt-3 mb-0"><?php echo $umidade; ?>%</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="card card-soft h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3 class="h6 mb-0">Vento</h3>
                                    <i class="bi bi-wind text-info icon-lg"></i>
                                </div>
                                <p class="fs-4 fw-bold mt-3 mb-0"><?php echo htmlspecialchars($vento); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="card card-soft h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3 class="h6 mb-0">Condicao</h3>
                                    <i class="bi <?php echo $iconeClimaAtual; ?> text-warning icon-lg"></i>
                                </div>
                                <p class="fs-5 fw-semibold mt-3 mb-0"><?php echo htmlspecialchars($descricao); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Previsao para 3 dias com foreach -->
                <div class="card card-soft">
                    <div class="card-body p-4">
                        <h3 class="h5 fw-bold mb-3">
                            <i class="bi bi-calendar3 me-2"></i>Previsao para 3 dias
                        </h3>

                        <div class="d-flex flex-column flex-md-row gap-3">
                            <?php
                            $contador = 0;
                            foreach ($forecast as $dia) {
                                if ($contador >= 3) {
                                    break;
                                }
                                $contador++;

                                $descricaoDia = (string)($dia["description"] ?? "");
                                $iconeDia = obterIconeClima($descricaoDia);
                                ?>
                                <div class="card border-0 bg-light forecast-card flex-fill">
                                    <div class="card-body">
                                        <h4 class="h6 fw-bold mb-2">
                                            <i class="bi bi-calendar-event me-1"></i>
                                            <?php echo htmlspecialchars((string)($dia["weekday"] ?? "Dia")); ?>
                                        </h4>
                                        <p class="mb-2">
                                            <i class="bi <?php echo $iconeDia; ?> me-1 text-secondary"></i>
                                            <?php echo htmlspecialchars($descricaoDia !== "" ? $descricaoDia : "Sem descricao"); ?>
                                        </p>
                                        <p class="mb-0">
                                            <span class="badge text-bg-danger me-1">Max: <?php echo (int)($dia["max"] ?? 0); ?>°C</span>
                                            <span class="badge text-bg-primary">Min: <?php echo (int)($dia["min"] ?? 0); ?>°C</span>
                                        </p>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>
</body>
</html>
