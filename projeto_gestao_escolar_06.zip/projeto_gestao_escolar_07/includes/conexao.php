<?php
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "gestao_escolar";

$conn = new mysqli($host, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Configura o charset para evitar problemas com acentuação
$conn->set_charset("utf8mb4");
?>
