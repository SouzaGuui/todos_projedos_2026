<?php
session_start();

function verificar_login() {
    if (!isset($_SESSION['usuario_id'])) {
        header("Location: login.php");
        exit();
    }
}

function verificar_permissao($tipos_permitidos) {
    if (!in_array($_SESSION['usuario_tipo'], $tipos_permitidos)) {
        header("Location: dashboard.php?erro=sem_permissao");
        exit();
    }
}
?>
