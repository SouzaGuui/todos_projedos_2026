# Sistema de Gestão Escolar - Instruções de Instalação

Este projeto foi desenvolvido para ser utilizado com o **XAMPP** no Windows (ou ambientes similares como WAMP/MAMP).

## 📋 Pré-requisitos

- **XAMPP** instalado.
- Apache e MySQL ativos no Painel de Controle do XAMPP.

## 🚀 Passo a Passo para Instalação

### 1. Preparar os Arquivos
1. Localize a pasta de instalação do seu XAMPP (geralmente `C:\xampp`).
2. Abra a pasta `htdocs`.
3. Crie uma nova pasta chamada `gestao_escolar`.
4. Extraia/Cole todos os arquivos deste projeto dentro dessa pasta `C:\xampp\htdocs\gestao_escolar`.

### 2. Configurar o Banco de Dados
1. Abra o seu navegador e acesse: `http://localhost/phpmyadmin`.
2. No menu superior ou lateral, clique em **"Novo"** (ou **"New"**).
3. No campo "Nome do banco de dados", digite: `gestao_escolar`.
4. Clique em **"Criar"**.
5. Com o banco `gestao_escolar` selecionado, clique na aba **"Importar"** (no topo).
6. Clique em **"Escolher arquivo"** e selecione o arquivo `database.sql` que está na pasta do projeto.
7. Role até o fim da página e clique em **"Importar"** (ou **"Executar"**).

### 3. Acessar o Sistema
1. No navegador, acesse: `http://localhost/gestao_escolar`.
2. Você verá a página inicial do sistema.

## 🔐 Dados de Acesso (Teste)

O sistema já vem com um usuário administrador pré-cadastrado para você testar todas as funcionalidades:

- **Email:** `admin@escola.com`
- **Senha:** `admin123`

Você também pode criar novos usuários (Alunos ou Professores) diretamente pela tela de **Cadastro** do sistema.

## 📁 Estrutura do Projeto
- `index.php`: Página inicial.
- `login.php` / `cadastro.php`: Sistema de autenticação.
- `dashboard.php`: Painel principal após o login.
- `avisos.php`: Mural de avisos (Gerenciável por Admin).
- `atividades.php`: Gestão de atividades (Gerenciável por Professor/Admin).
- `usuarios.php`: Gerenciamento de usuários (Apenas Admin).
- `includes/conexao.php`: Configurações de conexão com o banco de dados.
- `css/style.css`: Estilização visual do sistema.

---
Desenvolvido como solução para Gestão Escolar.
