<?php
include 'includes/conexao.php';
session_start();

$erro = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (empty($email) || empty($senha)) {
        $erro = 'Email e senha são obrigatórios.';
    } else {
        $stmt = $conn->prepare("SELECT id, nome, email, tipo, senha FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $usuario = $resultado->fetch_assoc();
            
            if (password_verify($senha, $usuario['senha'])) {
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['usuario_email'] = $usuario['email'];
                $_SESSION['usuario_tipo'] = $usuario['tipo'];
                
                header("Location: dashboard.php");
                exit();
            } else {
                $erro = 'Email ou senha incorretos.';
            }
        } else {
            $erro = 'Email ou senha incorretos.';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Gestão Escolar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1>Sistema de Gestão Escolar</h1>
                <nav class="nav-top">
                    <a href="index.php" class="btn-secondary">Voltar</a>
                </nav>
            </div>
        </header>

        <main class="main-content">
            <div class="auth-form-container">
                <h2>Login</h2>
                
                <?php if ($erro): ?>
                    <div class="alert alert-error">
                        <?php echo htmlspecialchars($erro); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" class="form">
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="form-group">
                        <label for="senha">Senha:</label>
                        <input type="password" id="senha" name="senha" required>
                    </div>

                    <button type="submit" class="btn-primary btn-block">Entrar</button>
                </form>

                <p class="form-footer">
                    Não tem conta? <a href="cadastro.php">Cadastre-se aqui</a>
                </p>

                <div class="demo-info">
                    <h4>Dados de Demonstração:</h4>
                    <p><strong>Email:</strong> admin@escola.com</p>
                    <p><strong>Senha:</strong> admin123</p>
                </div>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Sistema de Gestão Escolar. Todos os direitos reservados.</p>
        </footer>
    </div>
</body>
</html>
