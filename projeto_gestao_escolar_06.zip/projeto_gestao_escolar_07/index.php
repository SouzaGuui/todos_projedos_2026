<?php
include 'includes/sessao.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão Escolar - Página Inicial</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1>Sistema de Gestão Escolar</h1>
                <nav class="nav-top">
                    <?php if (isset($_SESSION['usuario_id'])): ?>
                        <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                        <a href="logout.php" class="btn-logout">Sair</a>
                    <?php else: ?>
                        <a href="login.php" class="btn-primary">Login</a>
                        <a href="cadastro.php" class="btn-secondary">Cadastro</a>
                    <?php endif; ?>
                </nav>
            </div>
        </header>

        <main class="main-content">
            <?php if (isset($_SESSION['usuario_id'])): ?>
                <section class="welcome-section">
                    <h2>Bem-vindo ao Sistema de Gestão Escolar</h2>
                    <p>Acesse as funcionalidades através do menu de navegação.</p>
                    
                    <nav class="main-menu">
                        <a href="dashboard.php" class="menu-item">
                            <h3>📊 Dashboard</h3>
                            <p>Visualize seu painel principal</p>
                        </a>
                        <a href="avisos.php" class="menu-item">
                            <h3>📢 Avisos</h3>
                            <p>Confira os avisos da escola</p>
                        </a>
                        <a href="atividades.php" class="menu-item">
                            <h3>✅ Atividades</h3>
                            <p>Acompanhe as atividades acadêmicas</p>
                        </a>
                    </nav>
                </section>
            <?php else: ?>
                <section class="welcome-section">
                    <h2>Bem-vindo ao Sistema de Gestão Escolar</h2>
                    <p>Faça login ou crie uma conta para acessar o sistema.</p>
                    
                    <div class="auth-buttons">
                        <a href="login.php" class="btn-primary btn-large">Fazer Login</a>
                        <a href="cadastro.php" class="btn-secondary btn-large">Criar Conta</a>
                    </div>

                    <section class="info-section">
                        <h3>Sobre o Sistema</h3>
                        <p>Este sistema centraliza informações importantes da escola, permitindo que alunos, professores e administradores acompanhem avisos, atividades e prazos de forma organizada.</p>
                    </section>
                </section>
            <?php endif; ?>
        </main>

        <footer>
            <p>&copy; 2024 Sistema de Gestão Escolar. Todos os direitos reservados.</p>
        </footer>
    </div>
</body>
</html>
