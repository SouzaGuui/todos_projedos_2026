<?php
include 'includes/conexao.php';
include 'includes/sessao.php';

verificar_login();
verificar_permissao(['administrador']);

$erro = '';
$sucesso = '';

// Processar ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? '';
    
    if ($acao === 'deletar') {
        $id = $_POST['id'] ?? '';
        
        if (empty($id)) {
            $erro = 'ID inválido.';
        } else {
            $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                $sucesso = 'Usuário deletado com sucesso!';
            } else {
                $erro = 'Erro ao deletar usuário.';
            }
            $stmt->close();
        }
    }
}

// Buscar todos os usuários
$stmt = $conn->prepare("SELECT id, nome, email, tipo FROM usuarios ORDER BY nome");
$stmt->execute();
$usuarios = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuários - Gestão Escolar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1>Sistema de Gestão Escolar</h1>
                <nav class="nav-top">
                    <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                    <a href="logout.php" class="btn-logout">Sair</a>
                </nav>
            </div>
        </header>

        <nav class="main-nav">
            <a href="dashboard.php" class="nav-item">Dashboard</a>
            <a href="avisos.php" class="nav-item">Avisos</a>
            <a href="atividades.php" class="nav-item">Atividades</a>
            <a href="usuarios.php" class="nav-item active">Usuários</a>
        </nav>

        <main class="main-content">
            <section class="page-section">
                <div class="page-header">
                    <h2>Gerenciar Usuários</h2>
                </div>

                <?php if ($erro): ?>
                    <div class="alert alert-error"><?php echo htmlspecialchars($erro); ?></div>
                <?php endif; ?>

                <?php if ($sucesso): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($sucesso); ?></div>
                <?php endif; ?>

                <!-- Tabela de usuários -->
                <div class="table-container">
                    <table class="users-table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Email</th>
                                <th>Tipo</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($usuarios->num_rows > 0): ?>
                                <?php while ($usuario = $usuarios->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($usuario['nome']); ?></td>
                                        <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $usuario['tipo']; ?>">
                                                <?php echo ucfirst($usuario['tipo']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($usuario['id'] !== $_SESSION['usuario_id']): ?>
                                                <form method="POST" style="display:inline;">
                                                    <input type="hidden" name="acao" value="deletar">
                                                    <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
                                                    <button type="submit" class="btn-small btn-danger" onclick="return confirm('Tem certeza? Esta ação não pode ser desfeita.')">Deletar</button>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-muted">(Você)</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="no-data">Nenhum usuário cadastrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>

        <footer>
            <p>&copy; 2024 Sistema de Gestão Escolar. Todos os direitos reservados.</p>
        </footer>
    </div>
</body>
</html>
