<?php
include 'includes/conexao.php';
include 'includes/sessao.php';

verificar_login();

$usuario_tipo = $_SESSION['usuario_tipo'];
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? '';
$erro = '';
$sucesso = '';

// Processar ações de professor
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($usuario_tipo !== 'professor' && $usuario_tipo !== 'administrador') {
        $erro = 'Você não tem permissão para realizar esta ação.';
    } else {
        $acao_post = $_POST['acao'] ?? '';
        
        if ($acao_post === 'nova') {
            $titulo = trim($_POST['titulo'] ?? '');
            $descricao = trim($_POST['descricao'] ?? '');
            $prazo = $_POST['prazo'] ?? '';
            $turma = trim($_POST['turma'] ?? '');
            
            if (empty($titulo) || empty($descricao) || empty($prazo) || empty($turma)) {
                $erro = 'Todos os campos são obrigatórios.';
            } else {
                $stmt = $conn->prepare("INSERT INTO atividades (titulo, descricao, prazo, turma) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $titulo, $descricao, $prazo, $turma);
                
                if ($stmt->execute()) {
                    $sucesso = 'Atividade criada com sucesso!';
                    $acao = '';
                } else {
                    $erro = 'Erro ao criar atividade.';
                }
                $stmt->close();
            }
        } elseif ($acao_post === 'editar') {
            $id = $_POST['id'] ?? '';
            $titulo = trim($_POST['titulo'] ?? '');
            $descricao = trim($_POST['descricao'] ?? '');
            $prazo = $_POST['prazo'] ?? '';
            $turma = trim($_POST['turma'] ?? '');
            
            if (empty($id) || empty($titulo) || empty($descricao) || empty($prazo) || empty($turma)) {
                $erro = 'Todos os campos são obrigatórios.';
            } else {
                $stmt = $conn->prepare("UPDATE atividades SET titulo = ?, descricao = ?, prazo = ?, turma = ? WHERE id = ?");
                $stmt->bind_param("ssssi", $titulo, $descricao, $prazo, $turma, $id);
                
                if ($stmt->execute()) {
                    $sucesso = 'Atividade atualizada com sucesso!';
                    $acao = '';
                } else {
                    $erro = 'Erro ao atualizar atividade.';
                }
                $stmt->close();
            }
        } elseif ($acao_post === 'deletar') {
            $id = $_POST['id'] ?? '';
            
            if (empty($id)) {
                $erro = 'ID inválido.';
            } else {
                $stmt = $conn->prepare("DELETE FROM atividades WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $sucesso = 'Atividade deletada com sucesso!';
                    $acao = '';
                } else {
                    $erro = 'Erro ao deletar atividade.';
                }
                $stmt->close();
            }
        }
    }
}

// Buscar atividade para edição
$atividade_editar = null;
if ($acao === 'editar' && !empty($id)) {
    $stmt = $conn->prepare("SELECT * FROM atividades WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $atividade_editar = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Buscar todas as atividades
$stmt = $conn->prepare("SELECT * FROM atividades ORDER BY prazo ASC");
$stmt->execute();
$atividades = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividades - Gestão Escolar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1>Sistema de Gestão Escolar</h1>
                <nav class="nav-top">
                    <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                    <a href="logout.php" class="btn-logout">Sair</a>
                </nav>
            </div>
        </header>

        <nav class="main-nav">
            <a href="dashboard.php" class="nav-item">Dashboard</a>
            <a href="avisos.php" class="nav-item">Avisos</a>
            <a href="atividades.php" class="nav-item active">Atividades</a>
            <?php if ($usuario_tipo === 'administrador'): ?>
                <a href="usuarios.php" class="nav-item">Usuários</a>
            <?php endif; ?>
        </nav>

        <main class="main-content">
            <section class="page-section">
                <div class="page-header">
                    <h2>Atividades</h2>
                    <?php if ($usuario_tipo === 'professor' || $usuario_tipo === 'administrador'): ?>
                        <a href="?acao=nova" class="btn-primary">+ Nova Atividade</a>
                    <?php endif; ?>
                </div>

                <?php if ($erro): ?>
                    <div class="alert alert-error"><?php echo htmlspecialchars($erro); ?></div>
                <?php endif; ?>

                <?php if ($sucesso): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($sucesso); ?></div>
                <?php endif; ?>

                <!-- Formulário de nova/editar atividade -->
                <?php if ($acao === 'nova' || $acao === 'editar'): ?>
                    <?php if ($usuario_tipo === 'professor' || $usuario_tipo === 'administrador'): ?>
                        <div class="form-container">
                            <h3><?php echo $acao === 'nova' ? 'Nova Atividade' : 'Editar Atividade'; ?></h3>
                            <form method="POST" class="form">
                                <input type="hidden" name="acao" value="<?php echo $acao; ?>">
                                <?php if ($acao === 'editar'): ?>
                                    <input type="hidden" name="id" value="<?php echo $atividade_editar['id']; ?>">
                                <?php endif; ?>

                                <div class="form-group">
                                    <label for="titulo">Título:</label>
                                    <input type="text" id="titulo" name="titulo" required value="<?php echo $atividade_editar['titulo'] ?? ''; ?>">
                                </div>

                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <textarea id="descricao" name="descricao" rows="5" required><?php echo $atividade_editar['descricao'] ?? ''; ?></textarea>
                                </div>

                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="prazo">Prazo:</label>
                                        <input type="date" id="prazo" name="prazo" required value="<?php echo $atividade_editar['prazo'] ?? ''; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="turma">Turma:</label>
                                        <input type="text" id="turma" name="turma" required value="<?php echo $atividade_editar['turma'] ?? ''; ?>">
                                    </div>
                                </div>

                                <div class="form-actions">
                                    <button type="submit" class="btn-primary">Salvar</button>
                                    <a href="atividades.php" class="btn-secondary">Cancelar</a>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <!-- Lista de atividades -->
                <div class="atividades-list">
                    <?php if ($atividades->num_rows > 0): ?>
                        <?php while ($atividade = $atividades->fetch_assoc()): ?>
                            <div class="atividade-card">
                                <div class="atividade-header">
                                    <h3><?php echo htmlspecialchars($atividade['titulo']); ?></h3>
                                    <span class="atividade-turma">Turma: <?php echo htmlspecialchars($atividade['turma']); ?></span>
                                </div>
                                <p class="atividade-descricao"><?php echo nl2br(htmlspecialchars($atividade['descricao'])); ?></p>
                                
                                <div class="atividade-footer">
                                    <span class="atividade-prazo">
                                        📅 Prazo: <?php echo date('d/m/Y', strtotime($atividade['prazo'])); ?>
                                    </span>
                                    
                                    <?php if ($usuario_tipo === 'professor' || $usuario_tipo === 'administrador'): ?>
                                        <div class="atividade-actions">
                                            <a href="?acao=editar&id=<?php echo $atividade['id']; ?>" class="btn-small btn-primary">Editar</a>
                                            <form method="POST" style="display:inline;">
                                                <input type="hidden" name="acao" value="deletar">
                                                <input type="hidden" name="id" value="<?php echo $atividade['id']; ?>">
                                                <button type="submit" class="btn-small btn-danger" onclick="return confirm('Tem certeza?')">Deletar</button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="no-data">Nenhuma atividade cadastrada.</p>
                    <?php endif; ?>
                </div>
            </section>
        </main>

        <footer>
            <p>&copy; 2024 Sistema de Gestão Escolar. Todos os direitos reservados.</p>
        </footer>
    </div>
</body>
</html>
