<?php
include 'includes/conexao.php';
session_start();

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirma_senha = $_POST['confirma_senha'] ?? '';
    $tipo = $_POST['tipo'] ?? 'aluno';

    if (empty($nome) || empty($email) || empty($senha) || empty($confirma_senha)) {
        $erro = 'Todos os campos são obrigatórios.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha deve ter no mínimo 6 caracteres.';
    } elseif ($senha !== $confirma_senha) {
        $erro = 'As senhas não coincidem.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'Email inválido.';
    } else {
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $erro = 'Este email já está cadastrado.';
        } else {
            $senha_hash = password_hash($senha, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nome, $email, $senha_hash, $tipo);

            if ($stmt->execute()) {
                $sucesso = 'Cadastro realizado com sucesso! Você pode fazer login agora.';
            } else {
                $erro = 'Erro ao cadastrar. Tente novamente.';
            }
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - Gestão Escolar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1>Sistema de Gestão Escolar</h1>
                <nav class="nav-top">
                    <a href="index.php" class="btn-secondary">Voltar</a>
                </nav>
            </div>
        </header>

        <main class="main-content">
            <div class="auth-form-container">
                <h2>Cadastro de Usuário</h2>
                
                <?php if ($erro): ?>
                    <div class="alert alert-error">
                        <?php echo htmlspecialchars($erro); ?>
                    </div>
                <?php endif; ?>

                <?php if ($sucesso): ?>
                    <div class="alert alert-success">
                        <?php echo htmlspecialchars($sucesso); ?>
                        <p><a href="login.php">Ir para login</a></p>
                    </div>
                <?php endif; ?>

                <form method="POST" class="form">
                    <div class="form-group">
                        <label for="nome">Nome Completo:</label>
                        <input type="text" id="nome" name="nome" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="form-group">
                        <label for="tipo">Tipo de Usuário:</label>
                        <select id="tipo" name="tipo" required>
                            <option value="aluno">Aluno</option>
                            <option value="professor">Professor</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="senha">Senha:</label>
                        <input type="password" id="senha" name="senha" required>
                    </div>

                    <div class="form-group">
                        <label for="confirma_senha">Confirmar Senha:</label>
                        <input type="password" id="confirma_senha" name="confirma_senha" required>
                    </div>

                    <button type="submit" class="btn-primary btn-block">Cadastrar</button>
                </form>

                <p class="form-footer">
                    Já tem conta? <a href="login.php">Faça login aqui</a>
                </p>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Sistema de Gestão Escolar. Todos os direitos reservados.</p>
        </footer>
    </div>
</body>
</html>
