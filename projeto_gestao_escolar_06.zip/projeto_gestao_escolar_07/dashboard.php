<?php
include 'includes/conexao.php';
include 'includes/sessao.php';

verificar_login();

$usuario_nome = htmlspecialchars($_SESSION['usuario_nome']);
$usuario_tipo = $_SESSION['usuario_tipo'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM avisos");
$stmt->execute();
$avisos_result = $stmt->get_result()->fetch_assoc();
$total_avisos = $avisos_result['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM atividades");
$stmt->execute();
$atividades_result = $stmt->get_result()->fetch_assoc();
$total_atividades = $atividades_result['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM usuarios");
$stmt->execute();
$usuarios_result = $stmt->get_result()->fetch_assoc();
$total_usuarios = $usuarios_result['total'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Gestão Escolar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1>Sistema de Gestão Escolar</h1>
                <nav class="nav-top">
                    <span>Bem-vindo, <?php echo $usuario_nome; ?> (<?php echo ucfirst($usuario_tipo); ?>)</span>
                    <a href="logout.php" class="btn-logout">Sair</a>
                </nav>
            </div>
        </header>

        <nav class="main-nav">
            <a href="dashboard.php" class="nav-item active">Dashboard</a>
            <a href="avisos.php" class="nav-item">Avisos</a>
            <a href="atividades.php" class="nav-item">Atividades</a>
            <?php if ($usuario_tipo === 'administrador'): ?>
                <a href="usuarios.php" class="nav-item">Usuários</a>
            <?php endif; ?>
        </nav>

        <main class="main-content">
            <section class="dashboard-section">
                <h2>Bem-vindo ao Dashboard</h2>
                <p>Aqui você pode acompanhar as principais informações do sistema.</p>

                <div class="stats-grid">
                    <div class="stat-card">
                        <h3>📢 Avisos</h3>
                        <p class="stat-number"><?php echo $total_avisos; ?></p>
                        <a href="avisos.php" class="stat-link">Ver Avisos</a>
                    </div>

                    <div class="stat-card">
                        <h3>✅ Atividades</h3>
                        <p class="stat-number"><?php echo $total_atividades; ?></p>
                        <a href="atividades.php" class="stat-link">Ver Atividades</a>
                    </div>

                    <div class="stat-card">
                        <h3>👥 Usuários</h3>
                        <p class="stat-number"><?php echo $total_usuarios; ?></p>
                        <a href="<?php echo $usuario_tipo === 'administrador' ? 'usuarios.php' : '#'; ?>" class="stat-link">
                            <?php echo $usuario_tipo === 'administrador' ? 'Gerenciar' : 'Ver'; ?>
                        </a>
                    </div>
                </div>

                <section class="quick-actions">
                    <h3>Ações Rápidas</h3>
                    <div class="actions-grid">
                        <a href="avisos.php" class="action-btn">
                            <span>📢</span>
                            <span>Visualizar Avisos</span>
                        </a>
                        <a href="atividades.php" class="action-btn">
                            <span>✅</span>
                            <span>Visualizar Atividades</span>
                        </a>
                        <?php if ($usuario_tipo === 'administrador'): ?>
                            <a href="avisos.php?acao=novo" class="action-btn">
                                <span>➕</span>
                                <span>Novo Aviso</span>
                            </a>
                        <?php endif; ?>
                        <?php if ($usuario_tipo === 'professor'): ?>
                            <a href="atividades.php?acao=nova" class="action-btn">
                                <span>➕</span>
                                <span>Nova Atividade</span>
                            </a>
                        <?php endif; ?>
                    </div>
                </section>

                <?php if (isset($_GET['erro']) && $_GET['erro'] === 'sem_permissao'): ?>
                    <div class="alert alert-error">
                        Você não tem permissão para acessar este recurso.
                    </div>
                <?php endif; ?>
            </section>
        </main>

        <footer>
            <p>&copy; 2024 Sistema de Gestão Escolar. Todos os direitos reservados.</p>
        </footer>
    </div>
</body>
</html>
