<?php
include 'includes/conexao.php';
include 'includes/sessao.php';

verificar_login();

$usuario_tipo = $_SESSION['usuario_tipo'];
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? '';
$erro = '';
$sucesso = '';

// Processar ações de administrador
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($usuario_tipo !== 'administrador') {
        $erro = 'Você não tem permissão para realizar esta ação.';
    } else {
        $acao_post = $_POST['acao'] ?? '';
        
        if ($acao_post === 'novo') {
            $titulo = trim($_POST['titulo'] ?? '');
            $descricao = trim($_POST['descricao'] ?? '');
            
            if (empty($titulo) || empty($descricao)) {
                $erro = 'Título e descrição são obrigatórios.';
            } else {
                $stmt = $conn->prepare("INSERT INTO avisos (titulo, descricao) VALUES (?, ?)");
                $stmt->bind_param("ss", $titulo, $descricao);
                
                if ($stmt->execute()) {
                    $sucesso = 'Aviso criado com sucesso!';
                    $acao = '';
                } else {
                    $erro = 'Erro ao criar aviso.';
                }
                $stmt->close();
            }
        } elseif ($acao_post === 'editar') {
            $id = $_POST['id'] ?? '';
            $titulo = trim($_POST['titulo'] ?? '');
            $descricao = trim($_POST['descricao'] ?? '');
            
            if (empty($id) || empty($titulo) || empty($descricao)) {
                $erro = 'Todos os campos são obrigatórios.';
            } else {
                $stmt = $conn->prepare("UPDATE avisos SET titulo = ?, descricao = ? WHERE id = ?");
                $stmt->bind_param("ssi", $titulo, $descricao, $id);
                
                if ($stmt->execute()) {
                    $sucesso = 'Aviso atualizado com sucesso!';
                    $acao = '';
                } else {
                    $erro = 'Erro ao atualizar aviso.';
                }
                $stmt->close();
            }
        } elseif ($acao_post === 'deletar') {
            $id = $_POST['id'] ?? '';
            
            if (empty($id)) {
                $erro = 'ID inválido.';
            } else {
                $stmt = $conn->prepare("DELETE FROM avisos WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $sucesso = 'Aviso deletado com sucesso!';
                    $acao = '';
                } else {
                    $erro = 'Erro ao deletar aviso.';
                }
                $stmt->close();
            }
        }
    }
}

// Buscar aviso para edição
$aviso_editar = null;
if ($acao === 'editar' && !empty($id)) {
    $stmt = $conn->prepare("SELECT * FROM avisos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $aviso_editar = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Buscar todos os avisos
$stmt = $conn->prepare("SELECT * FROM avisos ORDER BY data_publicacao DESC");
$stmt->execute();
$avisos = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avisos - Gestão Escolar</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1>Sistema de Gestão Escolar</h1>
                <nav class="nav-top">
                    <span>Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                    <a href="logout.php" class="btn-logout">Sair</a>
                </nav>
            </div>
        </header>

        <nav class="main-nav">
            <a href="dashboard.php" class="nav-item">Dashboard</a>
            <a href="avisos.php" class="nav-item active">Avisos</a>
            <a href="atividades.php" class="nav-item">Atividades</a>
            <?php if ($usuario_tipo === 'administrador'): ?>
                <a href="usuarios.php" class="nav-item">Usuários</a>
            <?php endif; ?>
        </nav>

        <main class="main-content">
            <section class="page-section">
                <div class="page-header">
                    <h2>Avisos</h2>
                    <?php if ($usuario_tipo === 'administrador'): ?>
                        <a href="?acao=novo" class="btn-primary">+ Novo Aviso</a>
                    <?php endif; ?>
                </div>

                <?php if ($erro): ?>
                    <div class="alert alert-error"><?php echo htmlspecialchars($erro); ?></div>
                <?php endif; ?>

                <?php if ($sucesso): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($sucesso); ?></div>
                <?php endif; ?>

                <!-- Formulário de novo/editar aviso -->
                <?php if ($acao === 'novo' || $acao === 'editar'): ?>
                    <?php if ($usuario_tipo === 'administrador'): ?>
                        <div class="form-container">
                            <h3><?php echo $acao === 'novo' ? 'Novo Aviso' : 'Editar Aviso'; ?></h3>
                            <form method="POST" class="form">
                                <input type="hidden" name="acao" value="<?php echo $acao; ?>">
                                <?php if ($acao === 'editar'): ?>
                                    <input type="hidden" name="id" value="<?php echo $aviso_editar['id']; ?>">
                                <?php endif; ?>

                                <div class="form-group">
                                    <label for="titulo">Título:</label>
                                    <input type="text" id="titulo" name="titulo" required value="<?php echo $aviso_editar['titulo'] ?? ''; ?>">
                                </div>

                                <div class="form-group">
                                    <label for="descricao">Descrição:</label>
                                    <textarea id="descricao" name="descricao" rows="5" required><?php echo $aviso_editar['descricao'] ?? ''; ?></textarea>
                                </div>

                                <div class="form-actions">
                                    <button type="submit" class="btn-primary">Salvar</button>
                                    <a href="avisos.php" class="btn-secondary">Cancelar</a>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <!-- Lista de avisos -->
                <div class="avisos-list">
                    <?php if ($avisos->num_rows > 0): ?>
                        <?php while ($aviso = $avisos->fetch_assoc()): ?>
                            <div class="aviso-card">
                                <div class="aviso-header">
                                    <h3><?php echo htmlspecialchars($aviso['titulo']); ?></h3>
                                    <span class="aviso-data"><?php echo date('d/m/Y H:i', strtotime($aviso['data_publicacao'])); ?></span>
                                </div>
                                <p class="aviso-descricao"><?php echo nl2br(htmlspecialchars($aviso['descricao'])); ?></p>
                                
                                <?php if ($usuario_tipo === 'administrador'): ?>
                                    <div class="aviso-actions">
                                        <a href="?acao=editar&id=<?php echo $aviso['id']; ?>" class="btn-small btn-primary">Editar</a>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="acao" value="deletar">
                                            <input type="hidden" name="id" value="<?php echo $aviso['id']; ?>">
                                            <button type="submit" class="btn-small btn-danger" onclick="return confirm('Tem certeza?')">Deletar</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="no-data">Nenhum aviso cadastrado.</p>
                    <?php endif; ?>
                </div>
            </section>
        </main>

        <footer>
            <p>&copy; 2024 Sistema de Gestão Escolar. Todos os direitos reservados.</p>
        </footer>
    </div>
</body>
</html>
