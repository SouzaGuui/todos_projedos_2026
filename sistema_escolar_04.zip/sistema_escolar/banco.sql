CREATE DATABASE IF NOT EXISTS sistema_escolar
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sistema_escolar;

CREATE TABLE IF NOT EXISTS enderecos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cep VARCHAR(9) NOT NULL,
    logradouro VARCHAR(255) NOT NULL,
    bairro VARCHAR(150) NOT NULL,
    localidade VARCHAR(150) NOT NULL,
    uf VARCHAR(2) NOT NULL,
    numero VARCHAR(20) NOT NULL
);
