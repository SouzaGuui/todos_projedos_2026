<?php
declare(strict_types=1);

session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$cep = preg_replace('/\D/', '', (string) ($_POST['cep'] ?? ''));
$logradouro = trim((string) ($_POST['logradouro'] ?? ''));
$bairro = trim((string) ($_POST['bairro'] ?? ''));
$localidade = trim((string) ($_POST['localidade'] ?? ''));
$uf = strtoupper(trim((string) ($_POST['uf'] ?? '')));
$numero = trim((string) ($_POST['numero'] ?? ''));

if (
    strlen($cep) !== 8 ||
    $logradouro === '' ||
    $bairro === '' ||
    $localidade === '' ||
    $uf === '' ||
    $numero === ''
) {
    $_SESSION['erro'] = 'Preencha todos os campos corretamente antes de salvar.';
    header('Location: index.php');
    exit;
}

$dsn = 'mysql:host=localhost;dbname=sistema_escolar;charset=utf8mb4';
$usuario = 'root';
$senha = '';

try {
    $pdo = new PDO($dsn, $usuario, $senha, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $sql = 'INSERT INTO enderecos (cep, logradouro, bairro, localidade, uf, numero)
            VALUES (:cep, :logradouro, :bairro, :localidade, :uf, :numero)';

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':cep', $cep);
    $stmt->bindValue(':logradouro', $logradouro);
    $stmt->bindValue(':bairro', $bairro);
    $stmt->bindValue(':localidade', $localidade);
    $stmt->bindValue(':uf', $uf);
    $stmt->bindValue(':numero', $numero);
    $stmt->execute();

    $_SESSION['sucesso'] = 'Cadastro realizado com sucesso!';
} catch (PDOException $e) {
    $_SESSION['erro'] = 'Erro ao salvar cadastro. Verifique a conexao com o banco.';
}

header('Location: index.php');
exit;
