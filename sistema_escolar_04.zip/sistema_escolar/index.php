<?php
declare(strict_types=1);

session_start();

$mensagemSucesso = $_SESSION['sucesso'] ?? null;
$mensagemErro = $_SESSION['erro'] ?? null;

unset($_SESSION['sucesso'], $_SESSION['erro']);
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cadastro de Enderecos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-dark: #4338ca;
            --secondary: #0ea5e9;
            --bg-start: #eef2ff;
            --bg-end: #f8fafc;
            --text-main: #0f172a;
            --text-muted: #475569;
            --border-color: #dbe5f0;
            --readonly-bg: #f1f5f9;
            --success-bg: #ecfdf5;
            --success-border: #10b981;
            --danger-bg: #fef2f2;
            --danger-border: #ef4444;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: var(--text-main);
            min-height: 100vh;
            background: linear-gradient(135deg, var(--bg-start), var(--bg-end));
        }

        .main-wrapper {
            padding-top: 3rem;
            padding-bottom: 3rem;
        }

        .form-card {
            border: 1px solid rgba(79, 70, 229, 0.08);
            border-radius: 1.1rem;
            box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
        }

        .form-card .card-body {
            padding: 2rem;
        }

        .titulo-cadastro {
            font-weight: 700;
            letter-spacing: 0.2px;
            margin-bottom: 1.5rem;
        }

        .titulo-cadastro i {
            color: var(--primary);
            margin-right: 0.45rem;
        }

        .form-label {
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 0.45rem;
        }

        .form-control {
            border-radius: 0.75rem;
            border: 1px solid var(--border-color);
            padding: 0.7rem 0.9rem;
            transition: all 0.3s ease;
            box-shadow: none;
        }

        .form-control:focus {
            border-color: rgba(79, 70, 229, 0.45);
            box-shadow: 0 0 0 0.22rem rgba(79, 70, 229, 0.16);
        }

        .form-control[readonly] {
            background-color: var(--readonly-bg);
            border-color: #d7deeb;
            color: #334155;
        }

        .form-text {
            color: #64748b;
            margin-top: 0.35rem;
        }

        .alert {
            border: 1px solid transparent;
            border-radius: 0.85rem;
            box-shadow: 0 8px 20px rgba(15, 23, 42, 0.06);
            animation: fadeInDown 0.35s ease;
        }

        .alert-success {
            background-color: var(--success-bg);
            border-color: rgba(16, 185, 129, 0.45);
            color: #065f46;
        }

        .alert-danger {
            background-color: var(--danger-bg);
            border-color: rgba(239, 68, 68, 0.42);
            color: #991b1b;
        }

        .btn-salvar {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border: none;
            border-radius: 0.8rem;
            color: #fff;
            font-weight: 600;
            padding: 0.72rem 1.35rem;
            transition: all 0.3s ease;
            box-shadow: 0 10px 18px rgba(79, 70, 229, 0.22);
        }

        .btn-salvar:hover,
        .btn-salvar:focus {
            transform: translateY(-1px);
            filter: brightness(1.04);
            box-shadow: 0 14px 22px rgba(79, 70, 229, 0.3);
            color: #fff;
        }

        .btn-salvar i {
            margin-right: 0.45rem;
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-6px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 767.98px) {
            .main-wrapper {
                padding-top: 1.6rem;
                padding-bottom: 1.6rem;
            }

            .form-card .card-body {
                padding: 1.3rem;
            }

            .titulo-cadastro {
                font-size: 1.35rem;
                margin-bottom: 1.15rem;
            }

            .btn-salvar {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <main class="container main-wrapper">
        <div class="row justify-content-center">
            <div class="col-12 col-md-10 col-lg-8">
                <div class="card form-card">
                    <div class="card-body p-4 p-md-5">
                        <h1 class="h3 titulo-cadastro"><i class="bi bi-person-vcard-fill"></i>Cadastro de Clientes</h1>

                        <?php if ($mensagemSucesso): ?>
                            <div class="alert alert-success" role="alert">
                                <?= htmlspecialchars($mensagemSucesso, ENT_QUOTES, 'UTF-8'); ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($mensagemErro): ?>
                            <div class="alert alert-danger" role="alert">
                                <?= htmlspecialchars($mensagemErro, ENT_QUOTES, 'UTF-8'); ?>
                            </div>
                        <?php endif; ?>

                        <form action="salvar.php" method="post" id="formEndereco" novalidate>
                            <div class="row g-3">
                                <div class="col-12 col-md-4">
                                    <label for="cep" class="form-label">CEP</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="cep"
                                        name="cep"
                                        maxlength="9"
                                        placeholder="00000-000"
                                        required
                                    >
                                    <div class="form-text">Digite o CEP e saia do campo.</div>
                                </div>

                                <div class="col-12">
                                    <label for="logradouro" class="form-label">Rua</label>
                                    <input type="text" class="form-control" id="logradouro" name="logradouro" readonly required>
                                </div>

                                <div class="col-12 col-md-6">
                                    <label for="bairro" class="form-label">Bairro</label>
                                    <input type="text" class="form-control" id="bairro" name="bairro" readonly required>
                                </div>

                                <div class="col-12 col-md-4">
                                    <label for="localidade" class="form-label">Cidade</label>
                                    <input type="text" class="form-control" id="localidade" name="localidade" readonly required>
                                </div>

                                <div class="col-12 col-md-2">
                                    <label for="uf" class="form-label">Estado</label>
                                    <input type="text" class="form-control text-uppercase" id="uf" name="uf" readonly required>
                                </div>

                                <div class="col-12 col-md-4">
                                    <label for="numero" class="form-label">Numero</label>
                                    <input type="text" class="form-control" id="numero" name="numero" maxlength="20" required>
                                </div>
                            </div>

                            <div class="mt-4 d-grid d-md-flex justify-content-md-end">
                                <button type="submit" class="btn btn-salvar px-4">
                                    <i class="bi bi-check2-circle"></i>Salvar cadastro
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        const cepInput = document.getElementById('cep');
        const logradouroInput = document.getElementById('logradouro');
        const bairroInput = document.getElementById('bairro');
        const localidadeInput = document.getElementById('localidade');
        const ufInput = document.getElementById('uf');
        const form = document.getElementById('formEndereco');

        function limparCamposEndereco() {
            logradouroInput.value = '';
            bairroInput.value = '';
            localidadeInput.value = '';
            ufInput.value = '';
        }

        function preencherCamposEndereco(dados) {
            logradouroInput.value = dados.logradouro ?? '';
            bairroInput.value = dados.bairro ?? '';
            localidadeInput.value = dados.localidade ?? '';
            ufInput.value = (dados.uf ?? '').toUpperCase();
        }

        function exibirErro(mensagem) {
            alert(mensagem);
        }

        async function buscarCep() {
            const cepLimpo = cepInput.value.replace(/\D/g, '');

            if (cepLimpo.length === 0) {
                limparCamposEndereco();
                return;
            }

            if (cepLimpo.length !== 8) {
                limparCamposEndereco();
                exibirErro('CEP invalido. Informe 8 digitos.');
                return;
            }

            try {
                const resposta = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`);

                if (!resposta.ok) {
                    throw new Error('Falha na comunicacao com o ViaCEP.');
                }

                const dados = await resposta.json();

                if (dados.erro) {
                    limparCamposEndereco();
                    exibirErro('CEP nao encontrado.');
                    return;
                }

                preencherCamposEndereco(dados);
            } catch (erro) {
                limparCamposEndereco();
                exibirErro('Nao foi possivel buscar o CEP. Tente novamente.');
            }
        }

        cepInput.addEventListener('input', () => {
            const cepLimpo = cepInput.value.replace(/\D/g, '').slice(0, 8);
            if (cepLimpo.length > 5) {
                cepInput.value = `${cepLimpo.slice(0, 5)}-${cepLimpo.slice(5)}`;
            } else {
                cepInput.value = cepLimpo;
            }
        });

        cepInput.addEventListener('blur', buscarCep);

        form.addEventListener('submit', (evento) => {
            const cepLimpo = cepInput.value.replace(/\D/g, '');
            if (cepLimpo.length !== 8) {
                evento.preventDefault();
                exibirErro('Informe um CEP valido antes de salvar.');
            }
        });
    </script>
</body>
</html>
